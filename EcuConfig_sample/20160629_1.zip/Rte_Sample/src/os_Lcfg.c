#include "os.h"

const EventMaskType OsEvent1	= (1UL << 1);
const EventMaskType OsEvent2	= (1UL << 2);
const EventMaskType OsEvent3	= (1UL << 3);
const EventMaskType OsEvent4	= (1UL << 4);
const EventMaskType OsEvent5	= (1UL << 5);
const EventMaskType OsEvent6	= (1UL << 6);
const EventMaskType OsEvent7	= (1UL << 7);
const EventMaskType OsEvent8	= (1UL << 8);
const EventMaskType OsEvent9	= (1UL << 9);
const EventMaskType OsEvent10	= (1UL << 10);
const EventMaskType OsEvent11	= (1UL << 11);
const EventMaskType OsEvent12	= (1UL << 12);
