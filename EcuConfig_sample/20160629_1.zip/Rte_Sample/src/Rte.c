
#define RTE_CORE
/* PRQA S 777,779 ++
   Variable names are (partly) defined by user in SWC configuration.
*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Rte_Main.h"
#include "Rte_Cbk.h"
#include "Rte_Cfg.h"
#include "Rte_Hook.h"
#include "Os.h"

/* INCLUDE DIRECTIVES FOR SW-C */
#include "Rte_ControllerComp.h"
#include "Rte_BlinkerSensorComp.h"
#include "Rte_BlinkerActuatorComp.h"
#include "Rte_DiagnoseComp.h"

/* INCLUDE DIRECTIVES FOR BSW */
#include "SchM_Com.h"

/* Version controls for all Rte header files */

#define EXPECTED_SW_MAJOR_VERSION (3u)
#define EXPECTED_SW_MINOR_VERSION (5u)
#define EXPECTED_SW_PATCH_VERSION (0u)
TASK(TaskActuator);
TASK(TaskController);
TASK(TaskDiagnose);
TASK(TaskSensor);

DeclareTask(TaskActuator);
DeclareTask(TaskController);
DeclareTask(TaskDiagnose);
DeclareTask(TaskSensor);
#if ( (RTE_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte.h file does not match the expected version."
#endif

#if ( (RTE_MAIN_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_MAIN_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_MAIN_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_Main.h file does not match the expected version."
#endif

#if ( (RTE_TYPE_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_TYPE_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_TYPE_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_Type.h file does not match the expected version."
#endif

#if ( (RTE_CBK_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_CBK_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_CBK_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_Cbk.h file does not match the expected version."
#endif

#if ( (RTE_CFG_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_CFG_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_CFG_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_Cfg.h file does not match the expected version."
#endif

#if ( (RTE_HOOK_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_HOOK_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_HOOK_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_Hook.h file does not match the expected version."
#endif

#if ( (RTE_DATAHANDLETYPE_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_DATAHANDLETYPE_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_DATAHANDLETYPE_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_DataHandleType.h file does not match the expected version."
#endif

#if ( (RTE_CONTROLLERCOMP_TYPE_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_CONTROLLERCOMP_TYPE_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_CONTROLLERCOMP_TYPE_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_ControllerComp_Type.h file does not match the expected version."
#endif

#if ( (RTE_CONTROLLERCOMP_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_CONTROLLERCOMP_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_CONTROLLERCOMP_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_ControllerComp.h file does not match the expected version."
#endif

#if ( (RTE_BLINKERSENSORCOMP_TYPE_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_BLINKERSENSORCOMP_TYPE_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_BLINKERSENSORCOMP_TYPE_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_BlinkerSensorComp_Type.h file does not match the expected version."
#endif

#if ( (RTE_BLINKERSENSORCOMP_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_BLINKERSENSORCOMP_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_BLINKERSENSORCOMP_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_BlinkerSensorComp.h file does not match the expected version."
#endif

#if ( (RTE_BLINKERACTUATORCOMP_TYPE_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_BLINKERACTUATORCOMP_TYPE_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_BLINKERACTUATORCOMP_TYPE_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_BlinkerActuatorComp_Type.h file does not match the expected version."
#endif

#if ( (RTE_BLINKERACTUATORCOMP_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_BLINKERACTUATORCOMP_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_BLINKERACTUATORCOMP_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_BlinkerActuatorComp.h file does not match the expected version."
#endif

#if ( (RTE_DIAGNOSECOMP_TYPE_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_DIAGNOSECOMP_TYPE_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_DIAGNOSECOMP_TYPE_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_DiagnoseComp_Type.h file does not match the expected version."
#endif

#if ( (RTE_DIAGNOSECOMP_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (RTE_DIAGNOSECOMP_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (RTE_DIAGNOSECOMP_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the Rte_DiagnoseComp.h file does not match the expected version."
#endif


/* Version controls for all SchM header files */
#if ( (SCHM_COM_TYPE_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (SCHM_COM_TYPE_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (SCHM_COM_TYPE_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the SchM_Com_Type.h file does not match the expected version."
#endif

#if ( (SCHM_COM_SW_MAJOR_VERSION != EXPECTED_SW_MAJOR_VERSION) || \
      (SCHM_COM_SW_MINOR_VERSION != EXPECTED_SW_MINOR_VERSION) || \
      (SCHM_COM_SW_PATCH_VERSION != EXPECTED_SW_PATCH_VERSION) )
   #error "The software version of the SchM_Com.h file does not match the expected version."
#endif


/* Version controls for all interfacing modules */
#if (STD_ON == RTE_VERSION_CHECK_FOREIGN_MODULE)
   #if ( (OS_AR_RELEASE_MAJOR_VERSION != RTE_AR_RELEASE_MAJOR_VERSION) || \
         (OS_AR_RELEASE_MINOR_VERSION != RTE_AR_RELEASE_MINOR_VERSION) )
/*      #error "The AUTOSAR release version of the Os module does not match the expected version."*/
   #endif
#endif

#if (STD_ON == RTE_VERSION_CHECK_FOREIGN_MODULE)
   #if ( (COM_AR_RELEASE_MAJOR_VERSION != RTE_AR_RELEASE_MAJOR_VERSION) || \
         (COM_AR_RELEASE_MINOR_VERSION != RTE_AR_RELEASE_MINOR_VERSION) )
 /*     #error "The AUTOSAR release version of the Com module does not match the expected version."*/
   #endif
#endif

/* PRIVATE MACROS ------------------------------------------------------------*/
#define Rte_Queue_Init(q, max_queue_size)               \
do                                                      \
{                                                       \
   (q).max_size=(max_queue_size);                       \
   (q).overflow=FALSE;                                  \
   Rte_Queue_Erase(q);                                  \
} while (0)

/* PRQA S 3453 ++
   MISRA-C:2004 RULE 19.7 VIOLATION:
   To get a consistent queue handling, it is preferred to use a macro here.
*/
#define Rte_Queue_Empty(q)   ((0 == (q).size) ? TRUE : FALSE)
/* PRQA S 3453 -- */
/* PRQA S 3453 ++
   MISRA-C:2004 RULE 19.7 VIOLATION:
   To get a consistent queue handling, it is preferred to use a macro here.
*/
#define Rte_Queue_Full(q)   (((q).size >= (q).max_size) ? TRUE : FALSE)
/* PRQA S 3453 -- */

#define Rte_Queue_Get_Overflow(q, retVal)               \
do                                                      \
{                                                       \
   (retVal) = (q).overflow;                             \
   (q).overflow = FALSE;                                \
} while (0)

#define Rte_Queue_Set_Overflow(q)                       \
do                                                      \
{                                                       \
   (q).overflow = TRUE;                                 \
} while (0)

/* PRQA S 3453 ++
   MISRA-C:2004 RULE 19.7 VIOLATION:
   To get a consistent queue handling, it is preferred to use a macro here.
*/
#define Rte_Queue_Size(q)   ((q).size)
/* PRQA S 3453 -- */

#define Rte_Queue_Erase(q)                              \
do                                                      \
{                                                       \
   (q).size = 0;                                        \
   (q).push_idx = 0;                                    \
   (q).pop_idx = 0;                                     \
} while (0)

#define Rte_Queue_Push(q, d)                            \
do                                                      \
{                                                       \
   (q).buffer[(q).push_idx] = (d);                      \
   (q).push_idx++;                                      \
   if((q).push_idx >= (q).max_size)                     \
   {                                                    \
      (q).push_idx = 0;                                 \
   }                                                    \
   (q).size++;                                          \
} while (0)

#define Rte_Queue_Array_Push(q, s, dptr)                \
do                                                      \
{                                                       \
   Rte_Memcpy((q).buffer[(q).push_idx], (dptr), ((s)*sizeof((dptr)[0])));\
   (q).push_idx++;                                      \
   if((q).push_idx >= (q).max_size)                     \
   {                                                    \
      (q).push_idx = 0;                                 \
   }                                                    \
   (q).size++;                                          \
} while (0)

#define Rte_Queue_VarArray_Push(q, s, dptr)             \
do                                                      \
{                                                       \
   Rte_Memcpy((q).buffer[(q).push_idx], (dptr), ((s)*sizeof((dptr)[0])));\
   (q).buffer_length[(q).push_idx] = (s);                             \
   (q).push_idx++;                                      \
   if((q).push_idx >= (q).max_size)                     \
   {                                                    \
      (q).push_idx = 0;                                 \
   }                                                    \
   (q).size++;                                          \
} while (0)

#define Rte_Queue_Pop(q, retVal)                        \
do                                                      \
{                                                       \
   (retVal) = (q).buffer[(q).pop_idx];                  \
   (q).pop_idx++;                                       \
   if((q).pop_idx >= (q).max_size)                      \
   {                                                    \
      (q).pop_idx = 0;                                  \
   }                                                    \
   (q).size--;                                          \
} while (0)

#define Rte_Queue_Array_Pop(q, s, dptr)                 \
do                                                      \
{                                                       \
   Rte_Memcpy((dptr), (q).buffer[(q).pop_idx], ((s)*sizeof(*((q).buffer[(q).pop_idx]))));\
   (q).pop_idx++;                                       \
   if((q).pop_idx >= (q).max_size)                      \
   {                                                    \
      (q).pop_idx = 0;                                  \
   }                                                    \
   (q).size--;                                          \
} while (0)

#define Rte_Queue_VarArray_Pop(q, s, dptr)              \
do                                                      \
{                                                       \
   Rte_Memcpy((dptr), (q).buffer[(q).pop_idx], ((q).buffer_length[(q).pop_idx]*sizeof(*((q).buffer[(q).pop_idx]))));\
   (s) = (q).buffer_length[(q).pop_idx];                             \
   (q).pop_idx++;                                       \
   if((q).pop_idx >= (q).max_size)                      \
   {                                                    \
      (q).pop_idx = 0;                                  \
   }                                                    \
   (q).size--;                                          \
} while (0)

#define Rte_Queue_Has_Been_Pushed(q, retVal)            \
do                                                      \
{                                                       \
   (retVal) = (q).beenPushed;                           \
} while (0)

#define Rte_Queue_Get_Old_Value(q, retVal)                                    \
do                                                                            \
{                                                                             \
   (retVal) = (q).buffer[(((q).push_idx + (q).max_size) - 1) % (q).max_size]; \
} while (0)

#define Rte_Set_Event(event)                \
do                                          \
{                                           \
   DisableAllInterrupts();                  \
   Rte_Events.E_##event = 1;                \
   EnableAllInterrupts();                   \
} while (0)

#define Rte_Clr_Event(event)                \
do                                          \
{                                           \
   DisableAllInterrupts();                  \
   Rte_Events.E_##event = 0;                \
   EnableAllInterrupts();                   \
} while (0)

#define Rte_Get_Event(event)   (Rte_Events.E_##event)


/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/

/* EXTERNAL GLOBAL FUNCTIONS -------------------------------------------------*/

/*============================================================================*
 * LOCAL TYPEDEF DECLARATIONS                                                 *
 *============================================================================*/

typedef struct
{
   Std_ReturnType appErr;
   struct
   {
      BlinkerMode ARG_DiagnoseBlinkerState;
   } args;
   boolean outstandingRequest;
   boolean timeoutFlag;
} Rte_ServerResult_ControllerComp_IF_Diagnose_GetBlinkerStateType;

typedef struct
{
   /* SwC instance: ControllerComp */
   unsigned int E_TEv_ControllerComp_ControllerComp :1;
   unsigned int E_DiagnoseGetStateEvent_ControllerComp :1;
   /* SwC instance: BlinkerSensorComp */
   unsigned int E_TEv_BlinkerSensorComp_BlinkerSensorComp :1;
   /* SwC instance: BlinkerActuatorComp */
   unsigned int E_TEv_BlinkerActuatorComp_BlinkerActuatorComp :1;
   /* SwC instance: DiagnoseComp */
   unsigned int E_TEv_DiagnoseComp_DiagnoseComp :1;
   /* Bsw instance: Com */
}Rte_Events_T;


/*============================================================================*
 * LOCAL FUNCTION PROTOTYPES                                                  *
 *============================================================================*/
#define RTE_START_SEC_CODE
#include "MemMap.h"

static FUNC(void, RTE_CODE) Rte_Memset(P2VAR(void, AUTOMATIC, RTE_APPL_DATA) dest,
                                         uint8 val, uint16_least count);


#define RTE_STOP_SEC_CODE
#include "MemMap.h"

/*============================================================================*
 * OBJECT DEFINITIONS                                                         *
 *============================================================================*/
/* LOCAL VARIABLES -----------------------------------------------------------*/

#define RTE_START_SEC_VAR_UNSPECIFIED
#include "MemMap.h"
/* RWAccesses: */
/* 1: /RP_Components/ControllerComp/IB_ControllerComp/RE_ControllerComp/DRP_ControllerComp */
/* 2: /RP_Components/BlinkerSensorComp/IB_BlinkerSensorComp/RE_BlinkerSensor/DSP_BlinkerSensor */
static VAR(struct { BlinkerMode value; Std_ReturnType status; boolean flag[1]; }, RTE_VAR) Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode;

/* RWAccesses: */
/* 1: /RP_Components/BlinkerActuatorComp/IB_BlinkerActuatorComp/RE_BlinkerActuator/DRP_BlinkerActuatorLeft */
/* 2: /RP_Components/ControllerComp/IB_ControllerComp/RE_ControllerComp/DSP_ControllerCompLeft */
static VAR(struct { Boolean value; }, RTE_VAR) Rte_RecBuf_BlinkerActuatorComp_00_R_BlinkerActuator_LeftBlinkerOn;

/* RWAccesses: */
/* 1: /RP_Components/BlinkerActuatorComp/IB_BlinkerActuatorComp/RE_BlinkerActuator/DRP_BlinkerActuatorRight */
/* 2: /RP_Components/ControllerComp/IB_ControllerComp/RE_ControllerComp/DSP_ControllerCompRight */
static VAR(struct { Boolean value; }, RTE_VAR) Rte_RecBuf_BlinkerActuatorComp_00_R_BlinkerActuator_RightBlinkerOn;

#define RTE_STOP_SEC_VAR_UNSPECIFIED
#include "MemMap.h"

#define RTE_START_SEC_VAR_UNSPECIFIED
#include "MemMap.h"
static VAR(BlinkerMode, RTE_VAR) Rte_Irv_ControllerComp_VAR_BlinkerState;
#define RTE_STOP_SEC_VAR_UNSPECIFIED
#include "MemMap.h"


#define RTE_START_SEC_VAR_UNSPECIFIED
#include "MemMap.h"

static VAR(boolean, RTE_VAR) SchM_IsStarted = FALSE;
static VAR(boolean, RTE_VAR) Rte_IsStarted = FALSE;

/* PRQA S 3218 ++
   MISRA-C:2004 RULE 8.7 VIOLATION:
   Specified by AUTOSAR.
*/
static VAR(Rte_Events_T, RTE_VAR) Rte_Events;
/* PRQA S 3218 -- */

#define RTE_STOP_SEC_VAR_UNSPECIFIED
#include "MemMap.h"

/* LOCAL CONSTANTS -----------------------------------------------------------*/
#define RTE_START_SEC_CONST_UNSPECIFIED
#include "MemMap.h"


#define RTE_STOP_SEC_CONST_UNSPECIFIED
#include "MemMap.h"


/* EXPORTED OBJECTS ----------------------------------------------------------*/

#define RTE_START_SEC_CONST_UNSPECIFIED
#include "MemMap.h"

/* PRQA S 3408 ++
   MISRA-C:2004 RULE 8.8 VIOLATION:
   CDS is needed globally.
*/
CONST(Rte_CDS_ControllerComp, RTE_CONST) Rte_Instance_ControllerComp =
{
   /* Data Handles section. -----------------------*/
   /* Per-instance Memory Handles section. --------*/
   /* Inter-runnable Variable Handles section. ----*/
   /* Calibration Parameter Handles section. ------*/
   /* Exclusive-area API section. -----------------*/
   /* Port API section. ---------------------------*/
   /* Inter Runnable Variable API section. --------*/
   /* Vendor specific section. --------------------*/
   0
};

CONSTP2CONST(Rte_CDS_ControllerComp, RTE_CONST, RTE_APPL_CONST) Rte_Inst_ControllerComp = &Rte_Instance_ControllerComp;

CONST(Rte_CDS_BlinkerSensorComp, RTE_CONST) Rte_Instance_BlinkerSensorComp =
{
   /* Data Handles section. -----------------------*/
   /* Per-instance Memory Handles section. --------*/
   /* Inter-runnable Variable Handles section. ----*/
   /* Calibration Parameter Handles section. ------*/
   /* Exclusive-area API section. -----------------*/
   /* Port API section. ---------------------------*/
   /* Inter Runnable Variable API section. --------*/
   /* Vendor specific section. --------------------*/
   0
};

CONSTP2CONST(Rte_CDS_BlinkerSensorComp, RTE_CONST, RTE_APPL_CONST) Rte_Inst_BlinkerSensorComp = &Rte_Instance_BlinkerSensorComp;

CONST(Rte_CDS_BlinkerActuatorComp, RTE_CONST) Rte_Instance_BlinkerActuatorComp =
{
   /* Data Handles section. -----------------------*/
   /* Per-instance Memory Handles section. --------*/
   /* Inter-runnable Variable Handles section. ----*/
   /* Calibration Parameter Handles section. ------*/
   /* Exclusive-area API section. -----------------*/
   /* Port API section. ---------------------------*/
   /* Inter Runnable Variable API section. --------*/
   /* Vendor specific section. --------------------*/
   0
};

CONSTP2CONST(Rte_CDS_BlinkerActuatorComp, RTE_CONST, RTE_APPL_CONST) Rte_Inst_BlinkerActuatorComp = &Rte_Instance_BlinkerActuatorComp;

CONST(Rte_CDS_DiagnoseComp, RTE_CONST) Rte_Instance_DiagnoseComp =
{
   /* Data Handles section. -----------------------*/
   /* Per-instance Memory Handles section. --------*/
   /* Inter-runnable Variable Handles section. ----*/
   /* Calibration Parameter Handles section. ------*/
   /* Exclusive-area API section. -----------------*/
   /* Port API section. ---------------------------*/
   /* Inter Runnable Variable API section. --------*/
   /* Vendor specific section. --------------------*/
   0
};

CONSTP2CONST(Rte_CDS_DiagnoseComp, RTE_CONST, RTE_APPL_CONST) Rte_Inst_DiagnoseComp = &Rte_Instance_DiagnoseComp;

/* PRQA S 3408 -- */

#define RTE_STOP_SEC_CONST_UNSPECIFIED
#include "MemMap.h"

/*============================================================================*
 * LOCAL FUNCTIONS                                                            *
 *============================================================================*/
#define RTE_START_SEC_CODE
#include "MemMap.h"

/* PRQA S 3112 ++
MISRA-C:2004 RULE 14.2 VIOLATION:
Message is thrown when hook functions are unconnected.
According to AUTOSAR requirement rte_sws_1238 these function calls are required.
*/
/* PRQA S 3673 ++
MISRA-C:2004 RULE 16.7 VIOLATION:
AUTOSAR spec defines the API (rte_sws_1020).
*/
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_ControllerComp_P_BlinkerActuator_LeftBlinkerOn(Boolean data)
/* PRQA S 3673 -- */
{
   Std_ReturnType retVal = RTE_E_OK;
   Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Start(data);
   Rte_RecBuf_BlinkerActuatorComp_00_R_BlinkerActuator_LeftBlinkerOn.value = data;
   Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Return(data);
   return retVal;
}

/* PRQA S 3673 ++
MISRA-C:2004 RULE 16.7 VIOLATION:
AUTOSAR spec defines the API (rte_sws_1020).
*/
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_ControllerComp_P_BlinkerActuator_RightBlinkerOn(Boolean data)
/* PRQA S 3673 -- */
{
   Std_ReturnType retVal = RTE_E_OK;
   Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Start(data);
   Rte_RecBuf_BlinkerActuatorComp_00_R_BlinkerActuator_RightBlinkerOn.value = data;
   Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Return(data);
   return retVal;
}

/* PRQA S 3673 ++
MISRA-C:2004 RULE 16.7 VIOLATION:
AUTOSAR spec defines the API (rte_sws_1020).
*/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_ControllerComp_R_BlinkerSensor_BlinkerMode(P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) data)
/* PRQA S 3673 -- */
{
   Std_ReturnType retVal = RTE_E_OK;
   Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start(data);
   *data = Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.value;
   retVal = Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.status;
   Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.flag[0] = FALSE;
   Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return(data);
   return retVal;
}

/* PRQA S 3673 ++
MISRA-C:2004 RULE 16.7 VIOLATION:
AUTOSAR spec defines the API (rte_sws_1020).
*/
FUNC(boolean, RTE_CODE) Rte_IsUpdated_ControllerComp_R_BlinkerSensor_BlinkerMode(void)
/* PRQA S 3673 -- */
{
   Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start();
   Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return();
   return Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.flag[0];
}

FUNC(BlinkerMode, RTE_CODE) Rte_IrvRead_ControllerComp_RE_ControllerDiagnose_VAR_BlinkerState(void)
{
   BlinkerMode retVal;
   Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Start();
   retVal = Rte_Irv_ControllerComp_VAR_BlinkerState;
   Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Return();
   return retVal;
}

FUNC(void, RTE_CODE) Rte_IrvWrite_ControllerComp_RE_ControllerComp_VAR_BlinkerState(BlinkerMode data)
{
   Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Start();
   Rte_Irv_ControllerComp_VAR_BlinkerState = data;
   Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Return();
}

/* PRQA S 3673 ++
MISRA-C:2004 RULE 16.7 VIOLATION:
AUTOSAR spec defines the API (rte_sws_1020).
*/
FUNC(Std_ReturnType, RTE_CODE) Rte_Write_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode(BlinkerMode data)
/* PRQA S 3673 -- */
{
   Std_ReturnType retVal = RTE_E_OK;
   Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Start(data);
   Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.value = data;
   Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.status = RTE_E_OK;
   Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.flag[0] = TRUE;
   Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Return(data);
   return retVal;
}

/* PRQA S 3673 ++
MISRA-C:2004 RULE 16.7 VIOLATION:
AUTOSAR spec defines the API (rte_sws_1020).
*/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn(P2VAR(Boolean, AUTOMATIC, RTE_APPL_DATA) data)
/* PRQA S 3673 -- */
{
   Std_ReturnType retVal = RTE_E_OK;
   Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Start(data);
   *data = Rte_RecBuf_BlinkerActuatorComp_00_R_BlinkerActuator_LeftBlinkerOn.value;
   Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Return(data);
   return retVal;
}

/* PRQA S 3673 ++
MISRA-C:2004 RULE 16.7 VIOLATION:
AUTOSAR spec defines the API (rte_sws_1020).
*/
FUNC(Std_ReturnType, RTE_CODE) Rte_Read_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn(P2VAR(Boolean, AUTOMATIC, RTE_APPL_DATA) data)
/* PRQA S 3673 -- */
{
   Std_ReturnType retVal = RTE_E_OK;
   Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Start(data);
   *data = Rte_RecBuf_BlinkerActuatorComp_00_R_BlinkerActuator_RightBlinkerOn.value;
   Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Return(data);
   return retVal;
}

FUNC(Std_ReturnType, RTE_CODE) Rte_Call_DiagnoseComp_R_Diagnose_GetBlinkerState (P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) ARG_DiagnoseBlinkerState)
{
   Std_ReturnType retVal;
   Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Start(ARG_DiagnoseBlinkerState);
   Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Start();
   retVal = RTE_E_OK;
   ControllerDiagRunnable(ARG_DiagnoseBlinkerState);
   Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Return();
   Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Return(ARG_DiagnoseBlinkerState);
   return retVal;
}

static FUNC(void, RTE_CODE) Rte_Memset(P2VAR(void, AUTOMATIC, RTE_APPL_DATA) dest,
                                         uint8 val, uint16_least count)
{
   P2VAR(uint8, AUTOMATIC, RTE_APPL_DATA) d = dest;
   while (0 != count)
   {
      *d = val;
/* PRQA S 489 ++
   MISRA-C:2004 RULE 17.4 VIOLATION:
   To get an efficient implementation, it is preferred to use a pointer arithmetic here.
*/
      d++;
/* PRQA S 489 -- */
      count--;
   }
}


/*============================================================================*
 * EXPORTED FUNCTIONS                                                         *
 *============================================================================*/

/* SchM API functions --------------------------------------------------------*/

/* Life cycle API ------------------------------------------------------------*/

#define Rte_Al_TaskActuator 0
#define Rte_Al_TaskController 0
#define Rte_Al_TaskDiagnose 0
#define Rte_Al_TaskSensor 0

FUNC(void, RTE_CODE) SchM_Init(void)
{

   /* Activate all tasks */
   (void)SetRelAlarm(Rte_Al_TaskActuator, 1U, 10000U); /* Activates task: TaskActuator */
   (void)SetRelAlarm(Rte_Al_TaskController, 1U, 100000U); /* Activates task: TaskController */
   (void)SetRelAlarm(Rte_Al_TaskDiagnose, 1U, 10000U); /* Activates task: TaskDiagnose */
   (void)SetRelAlarm(Rte_Al_TaskSensor, 1U, 10000U); /* Activates task: TaskSensor */


   SchM_IsStarted = TRUE;
}

FUNC(void, RTE_CODE) SchM_Deinit(void)
{
   SchM_IsStarted = FALSE;

   (void)CancelAlarm(Rte_Al_TaskActuator);
   (void)CancelAlarm(Rte_Al_TaskController);
   (void)CancelAlarm(Rte_Al_TaskDiagnose);
   (void)CancelAlarm(Rte_Al_TaskSensor);
}

FUNC(Std_ReturnType, RTE_CODE) Rte_Start(void)
{
   Std_ReturnType retVal = RTE_E_OK;
   /* Initialize receive buffers */
   Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.value = 0U;
   Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.status = RTE_E_NEVER_RECEIVED;
   Rte_RecBuf_ControllerComp_00_R_BlinkerSensor_BlinkerMode.flag[0] = FALSE;
   Rte_RecBuf_BlinkerActuatorComp_00_R_BlinkerActuator_LeftBlinkerOn.value = FALSE;
   Rte_RecBuf_BlinkerActuatorComp_00_R_BlinkerActuator_RightBlinkerOn.value = FALSE;

   /* Initialization related to component instance 'ControllerComp' */
   Rte_Irv_ControllerComp_VAR_BlinkerState = 0U;

   /* Initialization related to component instance 'BlinkerSensorComp' */

   /* Initialization related to component instance 'BlinkerActuatorComp' */

   /* Initialization related to component instance 'DiagnoseComp' */

   Rte_Memset(&Rte_Events, 0, sizeof(Rte_Events_T));


   Rte_IsStarted = TRUE;
   return retVal;
}

FUNC(Std_ReturnType, RTE_CODE) Rte_Stop(void)
{
   Std_ReturnType retVal = RTE_E_OK;
   Rte_IsStarted = FALSE;

   return retVal;
}

/* Os Tasks ------------------------------------------------------------------*/

/*
 * OS-Task: TaskActuator, Priority: 0, Preemptive: Yes
 * Mapping scenario: 1
 * Greatest Common Divisor for TimingEvents: 10000 ticks
*/
TASK(TaskActuator)
{
   Rte_Task_Dispatch(TaskActuator);
   if(TRUE == Rte_IsStarted)
   {
      /*----------------------------------------------------------------------------
       * Prologue for Runnable entity 'RE_BlinkerActuator'
       *----------------------------------------------------------------------------*/
      /*----------------------------------------------------------------------------*/
      Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Start();
      RE_BlinkerActuator();
      Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Return();
      /*----------------------------------------------------------------------------
       * Epilogue for runnable 'RE_BlinkerActuator'
       *----------------------------------------------------------------------------*/
      /*----------------------------------------------------------------------------*/
   }


   (void)TerminateTask();
}

/*
 * OS-Task: TaskController, Priority: 0, Preemptive: Yes
 * Mapping scenario: 1
 * Greatest Common Divisor for TimingEvents: 100000 ticks
*/
TASK(TaskController)
{
   Rte_Task_Dispatch(TaskController);
   if(TRUE == Rte_IsStarted)
   {
      /*----------------------------------------------------------------------------
       * Prologue for Runnable entity 'RE_ControllerComp'
       *----------------------------------------------------------------------------*/
      /*----------------------------------------------------------------------------*/
      Rte_Runnable_ControllerComp_RE_ControllerComp_Start();
      ControllerCompMainRunnable();
      Rte_Runnable_ControllerComp_RE_ControllerComp_Return();
      /*----------------------------------------------------------------------------
       * Epilogue for runnable 'RE_ControllerComp'
       *----------------------------------------------------------------------------*/
      /*----------------------------------------------------------------------------*/
   }


   (void)TerminateTask();
}

/*
 * OS-Task: TaskDiagnose, Priority: 0, Preemptive: Yes
 * Mapping scenario: 1
 * Greatest Common Divisor for TimingEvents: 10000 ticks
*/
TASK(TaskDiagnose)
{
   Rte_Task_Dispatch(TaskDiagnose);
   if(TRUE == Rte_IsStarted)
   {
      /*----------------------------------------------------------------------------
       * Prologue for Runnable entity 'RE_DiagnoseComp'
       *----------------------------------------------------------------------------*/
      /*----------------------------------------------------------------------------*/
      //Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Start();
     // DiagnoseCompMainRunnable();
      //Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Return();
      /*----------------------------------------------------------------------------
       * Epilogue for runnable 'RE_DiagnoseComp'
       *----------------------------------------------------------------------------*/
      /*----------------------------------------------------------------------------*/
   }


   (void)TerminateTask();
}

/*
 * OS-Task: TaskSensor, Priority: 0, Preemptive: Yes
 * Mapping scenario: 1
 * Greatest Common Divisor for TimingEvents: 10000 ticks
*/
TASK(TaskSensor)
{
   Rte_Task_Dispatch(TaskSensor);
   if(TRUE == Rte_IsStarted)
   {
      /*----------------------------------------------------------------------------
       * Prologue for Runnable entity 'RE_BlinkerSensor'
       *----------------------------------------------------------------------------*/
      /*----------------------------------------------------------------------------*/
      Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Start();
      RE_BlinkerSensor();
      Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Return();
      /*----------------------------------------------------------------------------
       * Epilogue for runnable 'RE_BlinkerSensor'
       *----------------------------------------------------------------------------*/
      /*----------------------------------------------------------------------------*/
   }


   (void)TerminateTask();
}

/* Callback functions --------------------------------------------------------*/

/* PRQA S 777,779,3112 -- */

#define RTE_STOP_SEC_CODE
#include "MemMap.h"

