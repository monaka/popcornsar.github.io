
#include "Rte_BlinkerActuatorComp.h"

FUNC(void, BlinkerActuatorComp_CODE) RE_BlinkerActuator(void)
{
    Boolean bLBlinkerOn = FALSE;
    Boolean bRBlinkerOn = FALSE;
/*
    Rte_Read_R_BlinkerActuator_LeftBlinkerOn(&bLBlinkerOn);
    Rte_Read_R_BlinkerActuator_RightBlinkerOn(&bRBlinkerOn);*/

    /* TO DO : */
    
}

