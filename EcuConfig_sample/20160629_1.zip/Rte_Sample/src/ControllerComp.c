
#include "Rte_ControllerComp.h"

FUNC(void, ControllerComp_CODE) ControllerCompMainRunnable(void)
{
    BlinkerMode BlkMode = BlinkerModeType_LowerLimit;

    if(True == Rte_IsUpdated_R_BlinkerSensor_BlinkerMode())
    {
        Rte_Read_R_BlinkerSensor_BlinkerMode(&BlkMode);
        
        if(BlinkerModeType_UpperLimit == BlkMode)
        {
            Rte_Write_P_BlinkerActuator_LeftBlinkerOn(BooleanType_UpperLimit);
            Rte_Write_P_BlinkerActuator_RightBlinkerOn(BooleanType_UpperLimit);
        }
        else
        {
            Rte_Write_P_BlinkerActuator_LeftBlinkerOn(BooleanType_LowerLimit);
            Rte_Write_P_BlinkerActuator_RightBlinkerOn(BooleanType_LowerLimit);                
        }

        Rte_IrvWrite_RE_ControllerComp_VAR_BlinkerState(BlkMode);            
    }    
}

FUNC(void, ControllerComp_CODE) ControllerDiagRunnable(P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) ARG_DiagnoseBlinkerState)
{
    BlinkerMode BlkMode = BlinkerModeType_LowerLimit;
/*
    Rte_IrvRead_RE_ControllerDiagnose_VAR_BlinkerState(&BlkMode);
    *ARG_DiagnoseBlinkerState = BlkMode;
	*/
}

