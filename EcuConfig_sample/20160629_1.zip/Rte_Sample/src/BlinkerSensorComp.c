
#include "Rte_BlinkerSensorComp.h"

FUNC(void, BlinkerSensorComp_CODE) RE_BlinkerSensor(void)
{
    BlinkerMode BlkMode = BlinkerModeType_LowerLimit;

    /* TO DO: */
    

    Rte_Write_P_BlinkerSensor_BlinkerMode(BlkMode);
}

