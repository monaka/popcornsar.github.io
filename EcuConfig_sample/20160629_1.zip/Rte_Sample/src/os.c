#include <Std_Types.h>
#include <os.h>

StatusType ActivateTask(TaskType tskid)
{
    return E_OK;
}

StatusType TerminateTask(void)
{
    return E_OK;
}

StatusType ChainTask(TaskType tskid)
{
    return E_OK;
}

StatusType Schedule(void)
{
    return E_OK;
}

StatusType GetTaskID(TaskRefType p_tskid)
{
    return E_OK;
}

StatusType GetTaskState(TaskType tskid, TaskStateRefType p_state)
{
    return E_OK;
}


void EnableAllInterrupts(void)
{
}

void DisableAllInterrupts(void)
{
}

void ResumeAllInterrupts(void)
{
}

void SuspendAllInterrupts(void)
{
}

void ResumeOSInterrupts(void)
{
}

void SuspendOSInterrupts(void)
{
}



StatusType GetResource(ResourceType resid)
{
    return E_OK;
}

StatusType ReleaseResource(ResourceType resid)
{
    return E_OK;
}



StatusType SetEvent(TaskType tskid, EventMaskType mask)
{
    return E_OK;
}

StatusType ClearEvent(EventMaskType mask)
{
    return E_OK;
}

StatusType GetEvent(TaskType tskid, EventMaskRefType p_mask)
{
    return E_OK;
}

StatusType WaitEvent(EventMaskType mask)
{
    return E_OK;
}


StatusType GetAlarmBase(AlarmType almid, AlarmBaseRefType p_info)
{
    return E_OK;
}

StatusType GetAlarm(AlarmType almid, TickRefType p_tick)
{
    return E_OK;
}

StatusType SetRelAlarm(AlarmType almid, TickType incr, TickType cycle)
{
    return E_OK;
}

StatusType SetAbsAlarm(AlarmType almid, TickType start, TickType cycle)
{
    return E_OK;
}

StatusType CancelAlarm(AlarmType almid)
{
    return E_OK;
}


StatusType StartScheduleTableRel(ScheduleTableType ScheduleTableID, TickType Offset)
{
	return E_OK;
}

StatusType StartScheduleTableAbs(ScheduleTableType ScheduleTableID, TickType Start)
{
	return E_OK;
}

StatusType StopScheduleTable(ScheduleTableType ScheduleTableID)
{
	return E_OK;
}

StatusType NextScheduleTable(ScheduleTableType ScheduleTableID_From, ScheduleTableType ScheduleTableID_To)
{
	return E_OK;
}

StatusType StartScheduleTableSynchron(ScheduleTableType ScheduleTableID)
{
	return E_OK;
}

StatusType SyncScheduleTable(ScheduleTableType ScheduleTableID, TickType Value)
{
	return E_OK;
}

StatusType SetScheduleTableAsync(ScheduleTableType ScheduleTableID)
{
	return E_OK;
}

StatusType GetScheduleTableStatus(ScheduleTableType ScheduleTableID, ScheduleTableStatusRefType ScheduleStatus)
{
	return E_OK;
}


AppModeType GetActiveApplicationMode(void)
{
    return OSDEFAULTAPPMODE;
}

void StartOS(AppModeType mode)
{
}

void ShutdownOS(StatusType ercd)
{
}


StatusType SignalCounter(CounterType cntid)
{
    return E_OK;
}



#define DeclareTask(TaskName)       extern const TaskType TaskName

const TaskType OsTask1  = 1;
const TaskType OsTask2  = 2;
const TaskType OsTask3  = 3;
const TaskType OsTask4  = 4;
const TaskType OsTask5  = 5;
const TaskType OsTask6  = 6;
const TaskType OsTask7  = 7;
const TaskType OsTask8  = 8;

const TaskType StdOsTask1  = 1;
const TaskType StdOsTask2  = 2;
const TaskType StdOsTask3  = 3;


const AlarmType OsAlarm1 = 1;
const AlarmType OsAlarm2 = 2;
const AlarmType OsAlarm3 = 3;
const AlarmType OsAlarm4 = 4;
const AlarmType OsAlarm5 = 5;
const AlarmType OsAlarm6 = 6;

const ScheduleTableType OsScheduleTable1 = 1;


const ResourceType OsResourceArea = 1;

