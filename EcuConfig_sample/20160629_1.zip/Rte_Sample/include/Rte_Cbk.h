#ifndef _RTE_CBK_H
#define _RTE_CBK_H

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/
/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Rte.h"

/* PRQA S 777 ++
   Variable names are (partly) defined by user in SWC configuration.
*/

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_CBK_SW_MAJOR_VERSION (3u)
#define RTE_CBK_SW_MINOR_VERSION (5u)
#define RTE_CBK_SW_PATCH_VERSION (0u)
/*============================================================================*
 * EXPORTED FUNCTIONS PROTOTYPES                                              *
 *============================================================================*/
#define RTE_START_SEC_CODE
#include "MemMap.h"


#define RTE_STOP_SEC_CODE
#include "MemMap.h"

/* PRQA S 777 -- */
#endif /* _RTE_CBK_H */
