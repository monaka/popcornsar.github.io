#ifndef _RTE_CFG_H
#define _RTE_CFG_H

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/
/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_CFG_SW_MAJOR_VERSION (3u)
#define RTE_CFG_SW_MINOR_VERSION (5u)
#define RTE_CFG_SW_PATCH_VERSION (0u)

#define RTE_VERSION_CHECK_FOREIGN_MODULE           STD_ON

/**
 * VFB tracing switch
 */
#define RTE_VFB_TRACE (FALSE)

/*============================================================================*
 * EXPORTED FUNCTIONS PROTOTYPES                                              *
 *============================================================================*/

#endif /* _RTE_CFG_H */
