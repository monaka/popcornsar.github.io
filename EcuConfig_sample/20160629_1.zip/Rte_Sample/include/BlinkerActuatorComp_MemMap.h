
#if defined (BlinkerActuatorComp_START_SEC_CODE)
   #ifdef CONST_8BIT_SEC_STARTED
     #error "Memory section is not stopped"
   #else
     #define CONST_8BIT_SEC_STARTED
     #undef  BlinkerActuatorComp_START_SEC_CODE
     #define DEFAULT_START_SEC_CONST_8BIT
   #endif
#elif defined (BlinkerActuatorComp_STOP_SEC_CODE)
   #ifndef CONST_8BIT_SEC_STARTED
     #error "Memory section is not started"
   #else
     #undef  CONST_8BIT_SEC_STARTED
     #undef  BlinkerActuatorComp_STOP_SEC_CODE
     #define DEFAULT_STOP_SEC_CONST_8BIT
   #endif
#else
   #include "MemMap.h"
#endif

