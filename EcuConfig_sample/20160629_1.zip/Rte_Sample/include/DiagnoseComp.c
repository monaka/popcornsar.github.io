
#include "Rte_DiagnoseComp.h"

FUNC(void, DiagnoseComp_CODE) DiagnoseCompMainRunnable(void)
{
  
}
