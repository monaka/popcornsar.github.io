#ifndef _RTE_BLINKERACTUATORCOMP_H
#define _RTE_BLINKERACTUATORCOMP_H

#define RTE_CORE 

#ifndef RTE_CORE
#ifdef RTE_APPLICATION_HEADER_FILE
#error Multiple application header files included.
#endif /* RTE_APPLICATION_HEADER_FILE */
#define RTE_APPLICATION_HEADER_FILE
#endif /* RTE_CORE */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/
/* PRQA S 777 ++
   Variable names are (partly) defined by user in SWC configuration.
*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Rte_BlinkerActuatorComp_Type.h"
#include "Rte_DataHandleType.h"

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_BLINKERACTUATORCOMP_SW_MAJOR_VERSION (3u)
#define RTE_BLINKERACTUATORCOMP_SW_MINOR_VERSION (5u)
#define RTE_BLINKERACTUATORCOMP_SW_PATCH_VERSION (0u)

#ifndef RTE_CORE
/* Application errors --------------------------------------------------------*/

/* Init values ---------------------------------------------------------------*/
#define Rte_InitValue_R_BlinkerActuator_LeftBlinkerOn ((Boolean)FALSE)
#define Rte_InitValue_R_BlinkerActuator_RightBlinkerOn ((Boolean)FALSE)

/* API Mapping ---------------------------------------------------------------*/
#define Rte_Read_R_BlinkerActuator_LeftBlinkerOn Rte_Read_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn
#define Rte_Read_R_BlinkerActuator_RightBlinkerOn Rte_Read_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn

/* Port handle API Mapping ---------------------------------------------------*/
#endif

/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS                                              *
 *============================================================================*/

/* PDS/CDS local data types --------------------------------------------------*/

/* Per-Instance-Memory types -------------------------------------------------*/

/* Port Data Structures (PDS) ------------------------------------------------*/

/* Component Data Structure (CDS) --------------------------------------------*/
typedef struct Rte_CDS_BlinkerActuatorComp_Tag
{
   /* Data Handles section. -----------------------*/

   /* Per-instance Memory Handles section. --------*/

   /* Inter-runnable Variable Handles section. ----*/

   /* Calibration Parameter Handles section. ------*/

   /* Exclusive-area API section. -----------------*/

   /* Port API section. ---------------------------*/

   /* Inter Runnable Variable API section. --------*/

   /* Inter Runnable Triggering API section. ------*/

   /* Vendor specific section. --------------------*/
   uint8 _dummy;
} Rte_CDS_BlinkerActuatorComp;

#ifndef RTE_CORE
/* Port handle types ---------------------------------------------------------*/

/* Pim types -----------------------------------------------------------------*/

/* Instance handle type ------------------------------------------------------*/
typedef P2CONST(Rte_CDS_BlinkerActuatorComp, TYPEDEF, RTE_CONST) Rte_Instance;
#endif

/*============================================================================*
 * EXPORTED OBJECT DECLARATIONS                                               *
 *============================================================================*/

#define RTE_START_SEC_CONST_UNSPECIFIED
#include "MemMap.h"

extern CONSTP2CONST(Rte_CDS_BlinkerActuatorComp, RTE_CONST, RTE_APPL_CONST) Rte_Inst_BlinkerActuatorComp;

#define RTE_STOP_SEC_CONST_UNSPECIFIED
#include "MemMap.h"

/*============================================================================*
 * EXPORTED FUNCTIONS PROTOTYPES                                              *
 *============================================================================*/
/* Declaration of runnable entities ------------------------------------------*/

#define BlinkerActuatorComp_START_SEC_CODE
#include "BlinkerActuatorComp_MemMap.h"

extern FUNC(void, BlinkerActuatorComp_CODE) RE_BlinkerActuator(void);

#define BlinkerActuatorComp_STOP_SEC_CODE
#include "BlinkerActuatorComp_MemMap.h"


#define RTE_START_SEC_CODE
#include "MemMap.h"

/* Declaration of API functions ----------------------------------------------*/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn(P2VAR(Boolean, AUTOMATIC, RTE_APPL_DATA) data);
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn(P2VAR(Boolean, AUTOMATIC, RTE_APPL_DATA) data);

#define RTE_STOP_SEC_CODE
#include "MemMap.h"

/* PRQA S 777 -- */

#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* _RTE_BLINKERACTUATORCOMP_H */
