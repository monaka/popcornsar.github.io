#ifndef _RTE_CONTROLLERCOMP_TYPE_H
#define _RTE_CONTROLLERCOMP_TYPE_H


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Rte_Type.h"

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_CONTROLLERCOMP_TYPE_SW_MAJOR_VERSION (3u)
#define RTE_CONTROLLERCOMP_TYPE_SW_MINOR_VERSION (5u)
#define RTE_CONTROLLERCOMP_TYPE_SW_PATCH_VERSION (0u)

/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS                                              *
 *============================================================================*/

/* Mode Declaration Groups ---------------------------------------------------*/

/* Enumeration Data Types ----------------------------------------------------*/
#ifndef False
#define False ((Boolean) 0)
#endif /* False */

#ifndef True
#define True ((Boolean) 1)
#endif /* True */


/* Limits of Range Data Types  -----------------------------------------------*/
#ifndef RTE_CORE

#define BlinkerModeType_LowerLimit ((BlinkerMode) 0)
#define BlinkerModeType_UpperLimit ((BlinkerMode) 3)

#define BooleanType_LowerLimit ((Boolean) 0)
#define BooleanType_UpperLimit ((Boolean) 1)

#endif /* RTE_CORE */

#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* _RTE_CONTROLLERCOMP_TYPE_H */
