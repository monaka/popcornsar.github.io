#ifndef _OS_H_
#define _OS_H_

typedef unsigned char UINT8;
typedef unsigned long UINT32;


#ifndef STATUSTYPEDEFINED 
typedef UINT8       StatusType;
#define  STATUSTYPEDEFINED 
#endif


typedef UINT8           TaskType;
typedef UINT8           TaskStateType;
typedef UINT8           ResourceType;
typedef UINT32          EventMaskType;
typedef UINT32          TickType;
typedef UINT8           AlarmType;
typedef UINT8           AppModeType;
typedef UINT8           OSServiceIdType;
typedef UINT8           IsrType;
typedef UINT8           CounterType;

typedef UINT8           ScheduleTableType;
typedef UINT8           ScheduleTableStatusType;

typedef struct {
    TickType maxallowedvalue;
    TickType ticksperbase;
    TickType mincycle;
} AlarmBaseType;

typedef TaskType        *TaskRefType;
typedef TaskStateType   *TaskStateRefType;
typedef EventMaskType   *EventMaskRefType;
typedef TickType        *TickRefType;
typedef AlarmBaseType   *AlarmBaseRefType;

typedef ScheduleTableStatusType *ScheduleTableStatusRefType;

#define DeclareTask(TaskName)       extern const TaskType TaskName
#define DeclareResource(ResName)    extern const ResourceType ResName
#define DeclareEvent(EventName)     extern const EventMaskType EventName
#define DeclareAlarm(AlarmName)     extern const AlarmType AlarmName

#define DeclareScheduleTable(ScheduleTableName)       extern const ScheduleTableType ScheduleTableName


#define TASKNAME(TaskName)  TaskMain##TaskName
#define ISRNAME(ISRName)    ISRMain##ISRName
#define ALARMCALLBACKNAME(AlarmCallBackName)    \
                            AlarmMain##AlarmCallBackName
#define TASK(TaskName)      void TaskMain##TaskName(void)
#define ISR(ISRName)        void ISRMain##ISRName(void)
#define ALARMCALLBACK(AlarmCallBackName)    \
                                void AlarmMain##AlarmCallBackName(void)

extern StatusType ActivateTask(TaskType tskid);
extern StatusType TerminateTask(void);
extern StatusType ChainTask(TaskType tskid);
extern StatusType Schedule(void);
extern StatusType GetTaskID(TaskRefType p_tskid);
extern StatusType GetTaskState(TaskType tskid, TaskStateRefType p_state);

extern void EnableAllInterrupts(void);
extern void DisableAllInterrupts(void);
extern void ResumeAllInterrupts(void);
extern void SuspendAllInterrupts(void);
extern void ResumeOSInterrupts(void);
extern void SuspendOSInterrupts(void);


extern StatusType GetResource(ResourceType resid);
extern StatusType ReleaseResource(ResourceType resid);


extern StatusType SetEvent(TaskType tskid, EventMaskType mask);
extern StatusType ClearEvent(EventMaskType mask);
extern StatusType GetEvent(TaskType tskid, EventMaskRefType p_mask);
extern StatusType WaitEvent(EventMaskType mask);


extern StatusType GetAlarmBase(AlarmType almid, AlarmBaseRefType p_info);
extern StatusType GetAlarm(AlarmType almid, TickRefType p_tick);
extern StatusType SetRelAlarm(AlarmType almid, TickType incr, TickType cycle);
extern StatusType SetAbsAlarm(AlarmType almid, TickType start, TickType cycle);
extern StatusType CancelAlarm(AlarmType almid);


extern StatusType StartScheduleTableRel(ScheduleTableType ScheduleTableID, TickType Offset);
extern StatusType StartScheduleTableAbs(ScheduleTableType ScheduleTableID, TickType Start);
extern StatusType StopScheduleTable(ScheduleTableType ScheduleTableID);
extern StatusType NextScheduleTable(ScheduleTableType ScheduleTableID_From, ScheduleTableType ScheduleTableID_To);
extern StatusType StartScheduleTableSynchron(ScheduleTableType ScheduleTableID);
extern StatusType SyncScheduleTable(ScheduleTableType ScheduleTableID, TickType Value);
extern StatusType SetScheduleTableAsync(ScheduleTableType ScheduleTableID);
extern StatusType GetScheduleTableStatus(ScheduleTableType ScheduleTableID, ScheduleTableStatusRefType ScheduleStatus);

extern AppModeType GetActiveApplicationMode(void);
extern void StartOS(AppModeType mode);
extern void ShutdownOS(StatusType ercd);


extern StatusType SignalCounter(CounterType cntid);


extern void ErrorHook(StatusType ercd);
extern void PreTaskHook(void);
extern void PostTaskHook(void);
extern void StartupHook(void);
extern void ShutdownHook(StatusType ercd);



#define E_OS_ACCESS		((StatusType) 1)
#define E_OS_CALLEVEL	((StatusType) 2)
#define E_OS_ID			((StatusType) 3)
#define E_OS_LIMIT		((StatusType) 4)
#define E_OS_NOFUNC		((StatusType) 5)
#define E_OS_RESOURCE	((StatusType) 6)
#define E_OS_STATE		((StatusType) 7)
#define E_OS_VALUE		((StatusType) 8)


#define INVALID_TASK		((TaskType) UINT8_INVALID)

#define SUSPENDED			((StatusType) 0)
#define RUNNING				((StatusType) 1)
#define READY				((StatusType) 2)
#define WAITING				((StatusType) 3)

#define RES_SCHEDULER		((ResourceType) 0)
#define OSDEFAULTAPPMODE	((AppModeType) 0x01)


#define SCHEDULETABLE_STOPPED					((ScheduleTableStatusType) 0)
#define SCHEDULETABLE_NEXT						((ScheduleTableStatusType) 1)
#define SCHEDULETABLE_WAITING					((ScheduleTableStatusType) 2)
#define SCHEDULETABLE_RUNNING					((ScheduleTableStatusType) 3)
#define SCHEDULETABLE_RUNNING_AND_SYNCHRONOUS	((ScheduleTableStatusType) 4)



#define OSServiceId_ActivateTask				((OSServiceIdType) 0)
#define OSServiceId_TerminateTask				((OSServiceIdType) 1)
#define OSServiceId_ChainTask					((OSServiceIdType) 2)
#define OSServiceId_Schedule					((OSServiceIdType) 3)
#define OSServiceId_GetTaskID					((OSServiceIdType) 4)
#define OSServiceId_GetTaskState				((OSServiceIdType) 5)
#define OSServiceId_EnableAllInterrupts			((OSServiceIdType) 6)
#define OSServiceId_DisableAllInterrupts		((OSServiceIdType) 7)
#define OSServiceId_ResumeAllInterrupts			((OSServiceIdType) 8)
#define OSServiceId_SuspendAllInterrupts		((OSServiceIdType) 9)
#define OSServiceId_ResumeOSInterrupts			((OSServiceIdType) 10)
#define OSServiceId_SuspendOSInterrupts			((OSServiceIdType) 11)
#define OSServiceId_GetResource					((OSServiceIdType) 12)
#define OSServiceId_ReleaseResource				((OSServiceIdType) 13)
#define OSServiceId_SetEvent					((OSServiceIdType) 14)
#define OSServiceId_ClearEvent					((OSServiceIdType) 15)
#define OSServiceId_GetEvent					((OSServiceIdType) 16)
#define OSServiceId_WaitEvent					((OSServiceIdType) 17)
#define OSServiceId_GetAlarmBase				((OSServiceIdType) 18)
#define OSServiceId_GetAlarm					((OSServiceIdType) 19)
#define OSServiceId_SetRelAlarm					((OSServiceIdType) 20)
#define OSServiceId_SetAbsAlarm					((OSServiceIdType) 21)
#define OSServiceId_CancelAlarm					((OSServiceIdType) 22)
#define OSServiceId_GetActiveApplicationMode	((OSServiceIdType) 23)
#define OSServiceId_StartOS						((OSServiceIdType) 24)
#define OSServiceId_ShutdownOS					((OSServiceIdType) 25)
#define OSServiceId_SignalCounter				((OSServiceIdType) 26)

typedef union {
		TaskType			tskid;
		TaskRefType			p_tskid;
		TaskStateRefType	p_state;
		ResourceType		resid;
		EventMaskType		mask;
		EventMaskRefType	p_mask;
		AlarmType			almid;
		AlarmBaseRefType	p_info;
		TickRefType			p_tick;
		TickType			incr;
		TickType			cycle;
		TickType			start;
		AppModeType			mode;
		CounterType			cntid;
	} _ErrorHook_Par;

extern OSServiceIdType	_errorhook_svcid;
extern _ErrorHook_Par	_errorhook_par1, _errorhook_par2, _errorhook_par3;


#define OSErrorGetServiceId()				(_errorhook_svcid)

#define OSError_ActivateTask_TaskID()		(_errorhook_par1.tskid)
#define OSError_ChainTask_TaskID()			(_errorhook_par1.tskid)
#define OSError_GetTaskID_TaskID()			(_errorhook_par1.p_tskid)
#define OSError_GetTaskState_TaskID()		(_errorhook_par1.tskid)
#define OSError_GetTaskState_State()		(_errorhook_par2.p_state)
#define OSError_GetResource_ResID()			(_errorhook_par1.resid)
#define OSError_ReleaseResource_ResID()		(_errorhook_par1.resid)
#define OSError_SetEvent_TaskID()			(_errorhook_par1.tskid)
#define OSError_SetEvent_Mask()				(_errorhook_par2.mask)
#define OSError_ClearEvent_Mask()			(_errorhook_par1.mask)
#define OSError_GetEvent_TaskID()			(_errorhook_par1.tskid)
#define OSError_GetEvent_Mask()				(_errorhook_par2.p_mask)
#define OSError_WaitEvent_Mask()			(_errorhook_par1.mask)
#define OSError_GetAlarmBase_AlarmID()		(_errorhook_par1.almid)
#define OSError_GetAlarmBase_Info()			(_errorhook_par2.p_info)
#define OSError_GetAlarm_AlarmID()			(_errorhook_par1.almid)
#define OSError_GetAlarm_Tick()				(_errorhook_par2.p_tick)
#define OSError_SetRelAlarm_AlarmID()		(_errorhook_par1.almid)
#define OSError_SetRelAlarm_increment()		(_errorhook_par2.incr)
#define OSError_SetRelAlarm_cycle()			(_errorhook_par3.cycle)
#define OSError_SetAbsAlarm_AlarmID()		(_errorhook_par1.almid)
#define OSError_SetAbsAlarm_start()			(_errorhook_par2.start)
#define OSError_SetAbsAlarm_cycle()			(_errorhook_par3.cycle)
#define OSError_CancelAlarm_AlarmID()		(_errorhook_par1.almid)
#define OSError_SignalCounter_CounterID()	(_errorhook_par1.cntid)


#define	TKERNEL_MAKER	0x0118u
#define	TKERNEL_PRID	0x0010u
#define	TKERNEL_SPVER	0x0221u
#define	TKERNEL_PRVER	0x1010u



#endif // _OS_H_

