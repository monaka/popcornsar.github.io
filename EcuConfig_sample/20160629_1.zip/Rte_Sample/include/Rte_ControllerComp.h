#ifndef _RTE_CONTROLLERCOMP_H
#define _RTE_CONTROLLERCOMP_H

#ifndef RTE_CORE
#ifdef RTE_APPLICATION_HEADER_FILE
#error Multiple application header files included.
#endif /* RTE_APPLICATION_HEADER_FILE */
#define RTE_APPLICATION_HEADER_FILE
#endif /* RTE_CORE */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/
/* PRQA S 777 ++
   Variable names are (partly) defined by user in SWC configuration.
*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Rte_ControllerComp_Type.h"
#include "Rte_DataHandleType.h"

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_CONTROLLERCOMP_SW_MAJOR_VERSION (3u)
#define RTE_CONTROLLERCOMP_SW_MINOR_VERSION (5u)
#define RTE_CONTROLLERCOMP_SW_PATCH_VERSION (0u)

#ifndef RTE_CORE
/* Application errors --------------------------------------------------------*/

/* Init values ---------------------------------------------------------------*/
#define Rte_InitValue_R_BlinkerSensor_BlinkerMode ((BlinkerMode)0U)

/* API Mapping ---------------------------------------------------------------*/
#define Rte_Write_P_BlinkerActuator_LeftBlinkerOn Rte_Write_ControllerComp_P_BlinkerActuator_LeftBlinkerOn
#define Rte_Write_P_BlinkerActuator_RightBlinkerOn Rte_Write_ControllerComp_P_BlinkerActuator_RightBlinkerOn
#define Rte_Read_R_BlinkerSensor_BlinkerMode Rte_Read_ControllerComp_R_BlinkerSensor_BlinkerMode
#define Rte_IsUpdated_R_BlinkerSensor_BlinkerMode Rte_IsUpdated_ControllerComp_R_BlinkerSensor_BlinkerMode
#define Rte_IrvWrite_RE_ControllerComp_VAR_BlinkerState Rte_IrvWrite_ControllerComp_RE_ControllerComp_VAR_BlinkerState
#define Rte_IrvRead_RE_ControllerDiagnose_VAR_BlinkerState Rte_IrvRead_ControllerComp_RE_ControllerDiagnose_VAR_BlinkerState

/* Port handle API Mapping ---------------------------------------------------*/
#endif

/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS                                              *
 *============================================================================*/

/* PDS/CDS local data types --------------------------------------------------*/

/* Per-Instance-Memory types -------------------------------------------------*/

/* Port Data Structures (PDS) ------------------------------------------------*/

/* Component Data Structure (CDS) --------------------------------------------*/
typedef struct Rte_CDS_ControllerComp_Tag
{
   /* Data Handles section. -----------------------*/

   /* Per-instance Memory Handles section. --------*/

   /* Inter-runnable Variable Handles section. ----*/

   /* Calibration Parameter Handles section. ------*/

   /* Exclusive-area API section. -----------------*/

   /* Port API section. ---------------------------*/

   /* Inter Runnable Variable API section. --------*/

   /* Inter Runnable Triggering API section. ------*/

   /* Vendor specific section. --------------------*/
   uint8 _dummy;
} Rte_CDS_ControllerComp;

#ifndef RTE_CORE
/* Port handle types ---------------------------------------------------------*/

/* Pim types -----------------------------------------------------------------*/

/* Instance handle type ------------------------------------------------------*/
typedef P2CONST(Rte_CDS_ControllerComp, TYPEDEF, RTE_CONST) Rte_Instance;
#endif

/*============================================================================*
 * EXPORTED OBJECT DECLARATIONS                                               *
 *============================================================================*/

#define RTE_START_SEC_CONST_UNSPECIFIED
#include "MemMap.h"

extern CONSTP2CONST(Rte_CDS_ControllerComp, RTE_CONST, RTE_APPL_CONST) Rte_Inst_ControllerComp;

#define RTE_STOP_SEC_CONST_UNSPECIFIED
#include "MemMap.h"

/*============================================================================*
 * EXPORTED FUNCTIONS PROTOTYPES                                              *
 *============================================================================*/
/* Declaration of runnable entities ------------------------------------------*/

#define ControllerComp_START_SEC_CODE
#include "ControllerComp_MemMap.h"

extern FUNC(void, ControllerComp_CODE) ControllerCompMainRunnable(void);
extern FUNC(void, ControllerComp_CODE) ControllerDiagRunnable(P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) ARG_DiagnoseBlinkerState);

#define ControllerComp_STOP_SEC_CODE
#include "ControllerComp_MemMap.h"


#define RTE_START_SEC_CODE
#include "MemMap.h"

/* Declaration of API functions ----------------------------------------------*/
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Write_ControllerComp_P_BlinkerActuator_LeftBlinkerOn(Boolean data);
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Write_ControllerComp_P_BlinkerActuator_RightBlinkerOn(Boolean data);
extern FUNC(Std_ReturnType, RTE_CODE) Rte_Read_ControllerComp_R_BlinkerSensor_BlinkerMode(P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) data);
extern FUNC(boolean, RTE_CODE) Rte_IsUpdated_ControllerComp_R_BlinkerSensor_BlinkerMode(void);
extern FUNC(void, RTE_CODE) Rte_IrvWrite_ControllerComp_RE_ControllerComp_VAR_BlinkerState(BlinkerMode data);
extern FUNC(BlinkerMode, RTE_CODE) Rte_IrvRead_ControllerComp_RE_ControllerDiagnose_VAR_BlinkerState(void);

#define RTE_STOP_SEC_CODE
#include "MemMap.h"

/* PRQA S 777 -- */

#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* _RTE_CONTROLLERCOMP_H */
