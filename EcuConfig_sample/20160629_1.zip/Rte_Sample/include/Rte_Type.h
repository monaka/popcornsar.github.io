#ifndef _RTE_TYPE_H
#define _RTE_TYPE_H

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Rte.h"

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_TYPE_SW_MAJOR_VERSION (3u)
#define RTE_TYPE_SW_MINOR_VERSION (5u)
#define RTE_TYPE_SW_PATCH_VERSION (0u)

/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS                                              *
 *============================================================================*/

typedef uint8    BlinkerMode;
typedef boolean  Boolean;

#endif /* _RTE_TYPE_H */
