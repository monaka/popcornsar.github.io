
#if defined (BlinkerSensorComp_START_SEC_CODE)
   #ifdef CONST_8BIT_SEC_STARTED
     #error "Memory section is not stopped"
   #else
     #define CONST_8BIT_SEC_STARTED
     #undef  BlinkerSensorComp_START_SEC_CODE
     #define DEFAULT_START_SEC_CONST_8BIT
   #endif
#elif defined (BlinkerSensorComp_STOP_SEC_CODE)
   #ifndef CONST_8BIT_SEC_STARTED
     #error "Memory section is not started"
   #else
     #undef  CONST_8BIT_SEC_STARTED
     #undef  BlinkerSensorComp_STOP_SEC_CODE
     #define DEFAULT_STOP_SEC_CONST_8BIT
   #endif
#else
   #include "MemMap.h"
#endif
