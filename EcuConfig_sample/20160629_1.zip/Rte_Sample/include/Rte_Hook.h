#ifndef _RTE_HOOK_H
#define _RTE_HOOK_H

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/
/* PRQA S 777 ++
   Variable names are (partly) defined by user in SWC configuration.
*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "Os.h"
#include "Rte_Type.h"
#include "Rte_Cfg.h"

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_HOOK_SW_MAJOR_VERSION (3u)
#define RTE_HOOK_SW_MINOR_VERSION (5u)
#define RTE_HOOK_SW_PATCH_VERSION (0u)


#ifndef RTE_VFB_TRACE
#define RTE_VFB_TRACE (FALSE)
#endif /* RTE_VFB_TRACE */

/*============================================================================*
 * EXPORTED FUNCTIONS PROTOTYPES                                              *
 *============================================================================*/
#define RTE_START_SEC_CODE
#include "MemMap.h"

/* PRQA S 3453 ++
   MISRA-C:2004 RULE 19.7 VIOLATION:
   Implementation is according to AUTOSAR requirement rte_sws_1236.
*/

#if defined(Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Return
#endif
#if defined(Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Return)
#undef Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Return
extern FUNC(void, RTE_CODE) Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Return(P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) ARG_DiagnoseBlinkerState);
#else
#define Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Return(param0) do{}while(0)
#endif /* Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Return */

#if defined(Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Start
#endif
#if defined(Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Start)
#undef Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Start
extern FUNC(void, RTE_CODE) Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Start(P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) ARG_DiagnoseBlinkerState);
#else
#define Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Start(param0) do{}while(0)
#endif /* Rte_CallHook_DiagnoseComp_R_Diagnose_GetBlinkerState_Start */

#if defined(Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Return
#endif
#if defined(Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Return)
#undef Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Return
extern FUNC(void, RTE_CODE) Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Return(void);
#else
#define Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Return() do{}while(0)
#endif /* Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Return */

#if defined(Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Start
#endif
#if defined(Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Start)
#undef Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Start
extern FUNC(void, RTE_CODE) Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Start(void);
#else
#define Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Start() do{}while(0)
#endif /* Rte_IrvReadHook_ControllerComp_VAR_BlinkerState_Start */

#if defined(Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Return
#endif
#if defined(Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Return)
#undef Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Return
extern FUNC(void, RTE_CODE) Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Return(void);
#else
#define Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Return() do{}while(0)
#endif /* Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Return */

#if defined(Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Start
#endif
#if defined(Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Start)
#undef Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Start
extern FUNC(void, RTE_CODE) Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Start(void);
#else
#define Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Start() do{}while(0)
#endif /* Rte_IrvWriteHook_ControllerComp_VAR_BlinkerState_Start */

#if defined(Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return
#endif
#if defined(Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return)
#undef Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return
extern FUNC(void, RTE_CODE) Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return();
#else
#define Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return() do{}while(0)
#endif /* Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return */

#if defined(Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start
#endif
#if defined(Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start)
#undef Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start
extern FUNC(void, RTE_CODE) Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start();
#else
#define Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start() do{}while(0)
#endif /* Rte_IsUpdatedHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start */

#if defined(Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Return
#endif
#if defined(Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Return)
#undef Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Return
extern FUNC(void, RTE_CODE) Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Return(P2VAR(Boolean, AUTOMATIC, RTE_APPL_DATA) data);
#else
#define Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Return(param0) do{}while(0)
#endif /* Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Return */

#if defined(Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Start
#endif
#if defined(Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Start)
#undef Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Start
extern FUNC(void, RTE_CODE) Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Start(P2VAR(Boolean, AUTOMATIC, RTE_APPL_DATA) data);
#else
#define Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Start(param0) do{}while(0)
#endif /* Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_LeftBlinkerOn_Start */

#if defined(Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Return
#endif
#if defined(Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Return)
#undef Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Return
extern FUNC(void, RTE_CODE) Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Return(P2VAR(Boolean, AUTOMATIC, RTE_APPL_DATA) data);
#else
#define Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Return(param0) do{}while(0)
#endif /* Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Return */

#if defined(Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Start
#endif
#if defined(Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Start)
#undef Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Start
extern FUNC(void, RTE_CODE) Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Start(P2VAR(Boolean, AUTOMATIC, RTE_APPL_DATA) data);
#else
#define Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Start(param0) do{}while(0)
#endif /* Rte_ReadHook_BlinkerActuatorComp_R_BlinkerActuator_RightBlinkerOn_Start */

#if defined(Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return
#endif
#if defined(Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return)
#undef Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return
extern FUNC(void, RTE_CODE) Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return(P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) data);
#else
#define Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return(param0) do{}while(0)
#endif /* Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Return */

#if defined(Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start
#endif
#if defined(Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start)
#undef Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start
extern FUNC(void, RTE_CODE) Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start(P2VAR(BlinkerMode, AUTOMATIC, RTE_APPL_DATA) data);
#else
#define Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start(param0) do{}while(0)
#endif /* Rte_ReadHook_ControllerComp_R_BlinkerSensor_BlinkerMode_Start */

#if defined(Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Return
#endif
#if defined(Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Return)
#undef Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Return
extern FUNC(void, RTE_CODE) Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Return(void);
#else
#define Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Return() do{}while(0)
#endif /* Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Return */

#if defined(Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Start
#endif
#if defined(Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Start)
#undef Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Start
extern FUNC(void, RTE_CODE) Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Start(void);
#else
#define Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Start() do{}while(0)
#endif /* Rte_Runnable_BlinkerActuatorComp_RE_BlinkerActuator_Start */

#if defined(Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Return
#endif
#if defined(Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Return)
#undef Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Return
extern FUNC(void, RTE_CODE) Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Return(void);
#else
#define Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Return() do{}while(0)
#endif /* Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Return */

#if defined(Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Start
#endif
#if defined(Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Start)
#undef Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Start
extern FUNC(void, RTE_CODE) Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Start(void);
#else
#define Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Start() do{}while(0)
#endif /* Rte_Runnable_BlinkerSensorComp_RE_BlinkerSensor_Start */

#if defined(Rte_Runnable_ControllerComp_RE_ControllerComp_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_ControllerComp_RE_ControllerComp_Return
#endif
#if defined(Rte_Runnable_ControllerComp_RE_ControllerComp_Return)
#undef Rte_Runnable_ControllerComp_RE_ControllerComp_Return
extern FUNC(void, RTE_CODE) Rte_Runnable_ControllerComp_RE_ControllerComp_Return(void);
#else
#define Rte_Runnable_ControllerComp_RE_ControllerComp_Return() do{}while(0)
#endif /* Rte_Runnable_ControllerComp_RE_ControllerComp_Return */

#if defined(Rte_Runnable_ControllerComp_RE_ControllerComp_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_ControllerComp_RE_ControllerComp_Start
#endif
#if defined(Rte_Runnable_ControllerComp_RE_ControllerComp_Start)
#undef Rte_Runnable_ControllerComp_RE_ControllerComp_Start
extern FUNC(void, RTE_CODE) Rte_Runnable_ControllerComp_RE_ControllerComp_Start(void);
#else
#define Rte_Runnable_ControllerComp_RE_ControllerComp_Start() do{}while(0)
#endif /* Rte_Runnable_ControllerComp_RE_ControllerComp_Start */

#if defined(Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Return
#endif
#if defined(Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Return)
#undef Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Return
extern FUNC(void, RTE_CODE) Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Return(void);
#else
#define Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Return() do{}while(0)
#endif /* Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Return */

#if defined(Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Start
#endif
#if defined(Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Start)
#undef Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Start
extern FUNC(void, RTE_CODE) Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Start(void);
#else
#define Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Start() do{}while(0)
#endif /* Rte_Runnable_ControllerComp_RE_ControllerDiagnose_Start */

#if defined(Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Return
#endif
#if defined(Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Return)
#undef Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Return
extern FUNC(void, RTE_CODE) Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Return(void);
#else
#define Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Return() do{}while(0)
#endif /* Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Return */

#if defined(Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Start
#endif
#if defined(Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Start)
#undef Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Start
extern FUNC(void, RTE_CODE) Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Start(void);
#else
#define Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Start() do{}while(0)
#endif /* Rte_Runnable_DiagnoseComp_RE_DiagnoseComp_Start */

#if defined(Rte_Task_Dispatch) && (RTE_VFB_TRACE == FALSE)
#undef Rte_Task_Dispatch
#endif
#if defined(Rte_Task_Dispatch)
#undef Rte_Task_Dispatch
extern FUNC(void, RTE_CODE) Rte_Task_Dispatch(TaskType task);
#else
#define Rte_Task_Dispatch(param0) do{}while(0)
#endif /* Rte_Task_Dispatch */

#if defined(Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Return
#endif
#if defined(Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Return)
#undef Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Return
extern FUNC(void, RTE_CODE) Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Return(BlinkerMode data);
#else
#define Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Return(param0) do{}while(0)
#endif /* Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Return */

#if defined(Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Start
#endif
#if defined(Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Start)
#undef Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Start
extern FUNC(void, RTE_CODE) Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Start(BlinkerMode data);
#else
#define Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Start(param0) do{}while(0)
#endif /* Rte_WriteHook_BlinkerSensorComp_P_BlinkerSensor_BlinkerMode_Start */

#if defined(Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Return
#endif
#if defined(Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Return)
#undef Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Return
extern FUNC(void, RTE_CODE) Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Return(Boolean data);
#else
#define Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Return(param0) do{}while(0)
#endif /* Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Return */

#if defined(Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Start
#endif
#if defined(Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Start)
#undef Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Start
extern FUNC(void, RTE_CODE) Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Start(Boolean data);
#else
#define Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Start(param0) do{}while(0)
#endif /* Rte_WriteHook_ControllerComp_P_BlinkerActuator_LeftBlinkerOn_Start */

#if defined(Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Return) && (RTE_VFB_TRACE == FALSE)
#undef Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Return
#endif
#if defined(Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Return)
#undef Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Return
extern FUNC(void, RTE_CODE) Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Return(Boolean data);
#else
#define Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Return(param0) do{}while(0)
#endif /* Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Return */

#if defined(Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Start) && (RTE_VFB_TRACE == FALSE)
#undef Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Start
#endif
#if defined(Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Start)
#undef Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Start
extern FUNC(void, RTE_CODE) Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Start(Boolean data);
#else
#define Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Start(param0) do{}while(0)
#endif /* Rte_WriteHook_ControllerComp_P_BlinkerActuator_RightBlinkerOn_Start */

/* PRQA S 777,3453 -- */
#define RTE_STOP_SEC_CODE
#include "MemMap.h"

#endif /* _RTE_HOOK_H */
