#ifndef _RTE_DATAHANDLETYPE_H
#define _RTE_DATAHANDLETYPE_H

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define RTE_DATAHANDLETYPE_SW_MAJOR_VERSION (3u)
#define RTE_DATAHANDLETYPE_SW_MINOR_VERSION (5u)
#define RTE_DATAHANDLETYPE_SW_PATCH_VERSION (0u)

/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS                                              *
 *============================================================================*/

/* Data Handle Types ---------------------------------------------------------*/

#endif /* _RTE_DATAHANDLETYPE_H */
