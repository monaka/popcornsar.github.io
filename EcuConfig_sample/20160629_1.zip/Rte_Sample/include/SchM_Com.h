#ifndef SCHM_COM_H
#define SCHM_COM_H


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*============================================================================*
 * PREPROCESSOR DIRECTIVES                                                    *
 *============================================================================*/

/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/

#include "SchM_Com_Type.h"

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/
#define SCHM_COM_SW_MAJOR_VERSION (3u)
#define SCHM_COM_SW_MINOR_VERSION (5u)
#define SCHM_COM_SW_PATCH_VERSION (0u)

/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS                                              *
 *============================================================================*/

/* ExclusiveArea prototypes  -------------------------------------------------*/
#define RTE_START_SEC_CODE
#include "MemMap.h"

/* Mode management prototypes  -----------------------------------------------*/
#define RTE_STOP_SEC_CODE
#include "MemMap.h"

/* Entrypoint prototypes  ----------------------------------------------------*/

#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* SCHM_COM_H */
