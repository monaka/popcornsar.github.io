#ifndef _RTE_H
#define _RTE_H

/*============================================================================*
 * PREPROCESSOR DIRECTIVES
 *============================================================================*/

/* INCLUDE DIRECTIVES FOR STANDARD HEADERS -----------------------------------*/


/* INCLUDE DIRECTIVES FOR OTHER HEADERS --------------------------------------*/
#include "Std_Types.h"                                /* Standard type header */

/* EXPORTED DEFINES FOR CONSTANTS --------------------------------------------*/


#define RTE_VENDOR_ID                           ((uint16)41)

/**
 * Rte major version number of AUTOSAR release version on which the
 * appropriate implementation is based on.
 */
#define RTE_AR_RELEASE_MAJOR_VERSION            (4u)

/**
 * Rte minor version number of AUTOSAR release version on which the
 * appropriate implementation is based on.
 */
#define RTE_AR_RELEASE_MINOR_VERSION            (0u)

/**
 * Rte revision version number of AUTOSAR release version on which the
 * appropriate implementation is based on.
 */
#define RTE_AR_RELEASE_REVISION_VERSION         (2u)

/** \cond Doxygen_Suppress */

/**
 * Rte major version number of the vendor specific implementation of the module.
 * The numbering is vendor specific.
 */
#define RTE_SW_MAJOR_VERSION                    (3u)

/**
 * Rte minor version number of the vendor specific implementation of the module.
 * The numbering is vendor specific.
 */
#define RTE_SW_MINOR_VERSION                    (5u)

/**
 * Rte patch level version number of the vendor specific implementation of the module.
 * The numbering is vendor specific.
 */
#define RTE_SW_PATCH_VERSION                    (0u)

/** \endcond */

/**
 * SchM vendor ID as defined in vendor list
 */
#define SCHM_VENDOR_ID                          (RTE_VENDOR_ID)

/**
 * SchM major version number of AUTOSAR release version on which the
 * appropriate implementation is based on.
 */
#define SCHM_AR_RELEASE_MAJOR_VERSION           (RTE_AR_RELEASE_MAJOR_VERSION)

/**
 * Schm minor version number of AUTOSAR release version on which the
 * appropriate implementation is based on.
 */
#define SCHM_AR_RELEASE_MINOR_VERSION           (RTE_AR_RELEASE_MINOR_VERSION)

/**
 * SchM revision version number of AUTOSAR release version on which the
 * appropriate implementation is based on.
 */
#define SCHM_AR_RELEASE_REVISION_VERSION        (RTE_AR_RELEASE_REVISION_VERSION)

/** \cond Doxygen_Suppress */

/**
 * SchM major version number of the vendor specific implementation of the module.
 * The numbering is vendor specific.
 */
#define SCHM_SW_MAJOR_VERSION                   (RTE_SW_MAJOR_VERSION)

/**
 * SchM minor version number of the vendor specific implementation of the module.
 * The numbering is vendor specific.
 */
#define SCHM_SW_MINOR_VERSION                   (RTE_SW_MINOR_VERSION)

/**
 * SchM patch level version number of the vendor specific implementation of the module.
 * The numbering is vendor specific.
 */
#define SCHM_SW_PATCH_VERSION                   (RTE_SW_PATCH_VERSION)

/** \endcond */

/* Predefined error codes) ---------------------------------------------------*/

/**
 * No error occurred.
 */
#define RTE_E_OK                       ((Std_ReturnType)0)

/**
 * Generic application error indicated by signal invalidation in sender
 * receiver communication with data semantics on the receiver side.
 */
#define RTE_E_INVALID                  ((Std_ReturnType)1)

/**
 * An IPDU group was disabled while the application was waiting for the
 * transmission acknowledgment. No value is available. This is not
 * considered a fault, since the IPDU group is switched off on purpose.
 * The semantics are as follows:
 * - The OUT buffers of a client or of explicit read APIs are not modified
 * - No runnable with startOnEvent on a DataReceivedEvent for this VariableData-
 *   Prototype is triggered.
 * - The buffers for implicit read access will keep the previous value.
 */
#define RTE_E_COM_STOPPED              ((Std_ReturnType)128)

/**
 * A blocking API call returned due to expiry of a local timeout rather than
 * the intended result. OUT buffers are not modified. The interpretation of
 * this being an error depends on the application.
 */
#define RTE_E_TIMEOUT                  ((Std_ReturnType)129)

/**
 * A internal RTE limit has been exceeded. Request could not be handled.
 * OUT buffers are not modified.
 */
#define RTE_E_LIMIT                    ((Std_ReturnType)130)

/**
 * An explicit read API call returned no data. (This is no error.)
 */
#define RTE_E_NO_DATA                  ((Std_ReturnType)131)

/**
 * Transmission acknowledgement received.
 */
#define RTE_E_TRANSMIT_ACK             ((Std_ReturnType)132)

/**
 * No data received for the corresponding unqueued data element 
 * since system start or partition restart.
 */
#define RTE_E_NEVER_RECEIVED           ((Std_ReturnType)133)

/**
 * The port used for communication is not connected.
 */
#define RTE_E_UNCONNECTED              ((Std_ReturnType)134)

/**
 * The error is returned by a blocking API and indicates that the 
 * runnable could not enter a wait state, because one ExecutableEntity
 * of the current tasks call stack has entered or is running in an
 * ExclusiveArea.
 */
#define RTE_E_IN_EXCLUSIVE_AREA        ((Std_ReturnType)135)

/**
 * The error can be returned by an RTE API, if the parameters contain a 
 * direct or indirect reference to memory that is not accessible from 
 * the callers partition.
 */
#define RTE_E_SEG_FAULT                ((Std_ReturnType)136)

/**
 * An API call for reading received data with event semantics indicates that
 * some incoming data has been lost due to an overflow of the receive 
 * queue or due to an error of the underlying communication stack.
 */
#define RTE_E_LOST_DATA                ((Std_ReturnType)64)

/**
 * An API call for reading received data with data semantics indicates that
 * the available data has exceeded the aliveTimeout limit. A COM signal 
 * outdated callback will result in this error.
 */
#define RTE_E_MAX_AGE_EXCEEDED         ((Std_ReturnType)64)

/**
 * No error occurred.
 */
#define SCHM_E_OK                      (RTE_E_OK)

/**
 * A internal Basic Software Scheduler limit has been exceeded. Request could
 * not be handled. OUT buffers are not modified.
 */
#define SCHM_E_LIMIT                   (RTE_E_LIMIT)

/**
 * An explicit read API call returned no data. (This is no error.)
 */
#define SCHM_E_NO_DATA                 (RTE_E_NO_DATA)

/**
 * Transmission acknowledgement received.
 */
#define SCHM_E_TRANSMIT_ACK            (RTE_E_TRANSMIT_ACK)

/**
 * The error is returned by a blocking API and indicates that the schedulable entity
 * could not enter a wait state, because one ExecutableEntity of the current
 * task's call stack has entered or is running in an ExclusiveArea.
 */
#define SCHM_E_IN_EXCLUSIVE_AREA       (RTE_E_IN_EXCLUSIVE_AREA)

/**
 * The configured timeout exceeds before the intended result was ready.
 */
#define SCHM_E_TIMEOUT                 (RTE_E_TIMEOUT)

/* EXPORTED DEFINE MACROS (#, ##) --------------------------------------------*/


/*============================================================================*
 * EXPORTED TYPEDEF DECLARATIONS
 *============================================================================*/

/* ENUMS ---------------------------------------------------------------------*/


/* STRUCTS -------------------------------------------------------------------*/


/* UNIONS --------------------------------------------------------------------*/


/* OTHER TYPEDEFS ------------------------------------------------------------*/


/*============================================================================*
 * EXPORTED OBJECT DECLARATIONS
 *============================================================================*/

/*============================================================================*
 * EXPORTED FUNCTIONS PROTOTYPES
 *============================================================================*/

/*============================================================================*
 * EXPORTED FUNCTION-LIKE-MACROS and INLINE FUNCTIONS
 *============================================================================*/

#endif   /* #ifdef _RTE_H */
/* END OF FILE -------------------------------------------------------------- */
