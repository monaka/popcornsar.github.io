/*****************************************************************************/
/* Public macros                                                             */
/*****************************************************************************/
/* PRQA S 0883 EOF*/
#define MEMMAP_VENDOR_ID          (31u)

#define MEMMAP_SW_MAJOR_VERSION (1u)
#define MEMMAP_SW_MINOR_VERSION (0u)
#define MEMMAP_SW_PATCH_VERSION (0u)

#define MEMMAP_AR_RELEASE_MAJOR_VERSION (4u)
#define MEMMAP_AR_RELEASE_MINOR_VERSION (0u)
#define MEMMAP_AR_RELEASE_REVISION_VERSION (2u)

/*============================= GLOBAL SYMBOLS ===============================*/

/* Version of AUTOSAR Specification */
#define ADC_MEMMAP_AR_MAJOR_VERSION (1u)
#define ADC_MEMMAP_AR_MINOR_VERSION (0u)
#define ADC_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define ADC_MEMMAP_SW_MAJOR_VERSION (1u)
#define ADC_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define CAN_MEMMAP_AR_MAJOR_VERSION (1u)
#define CAN_MEMMAP_AR_MINOR_VERSION (0u)
#define CAN_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define CAN_MEMMAP_SW_MAJOR_VERSION (1u)
#define CAN_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define DIO_MEMMAP_AR_MAJOR_VERSION (1u)
#define DIO_MEMMAP_AR_MINOR_VERSION (0u)
#define DIO_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define DIO_MEMMAP_SW_MAJOR_VERSION (1u)
#define DIO_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define GPT_MEMMAP_AR_MAJOR_VERSION (1u)
#define GPT_MEMMAP_AR_MINOR_VERSION (0u)
#define GPT_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define GPT_MEMMAP_SW_MAJOR_VERSION (1u)
#define GPT_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define ICU_MEMMAP_AR_MAJOR_VERSION (1u)
#define ICU_MEMMAP_AR_MINOR_VERSION (0u)
#define ICU_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define ICU_MEMMAP_SW_MAJOR_VERSION (1u)
#define ICU_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define LIN_MEMMAP_AR_MAJOR_VERSION (1u)
#define LIN_MEMMAP_AR_MINOR_VERSION (0u)
#define LIN_MEMMAP_AR_PATCH_VERSION (0u)

/* Lin software version information */
#define LIN_MEMMAP_SW_MAJOR_VERSION (1u)
#define LIN_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define MCU_MEMMAP_AR_MAJOR_VERSION (1u)
#define MCU_MEMMAP_AR_MINOR_VERSION (0u)
#define MCU_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define MCU_MEMMAP_SW_MAJOR_VERSION (1u)
#define MCU_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define PORT_MEMMAP_AR_MAJOR_VERSION (1u)
#define PORT_MEMMAP_AR_MINOR_VERSION (0u)
#define PORT_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define PORT_MEMMAP_SW_MAJOR_VERSION (1u)
#define PORT_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define PWM_MEMMAP_AR_MAJOR_VERSION (1u)
#define PWM_MEMMAP_AR_MINOR_VERSION (0u)
#define PWM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define PWM_MEMMAP_SW_MAJOR_VERSION (1u)
#define PWM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define SPI_MEMMAP_AR_MAJOR_VERSION (1u)
#define SPI_MEMMAP_AR_MINOR_VERSION (0u)
#define SPI_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define SPI_MEMMAP_SW_MAJOR_VERSION (1u)
#define SPI_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define WDG_23_DRIVERA_MEMMAP_AR_MAJOR_VERSION (1u)
#define WDG_23_DRIVERA_MEMMAP_AR_MINOR_VERSION (0u)
#define WDG_23_DRIVERA_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define WDG_23_DRIVERA_MEMMAP_SW_MAJOR_VERSION (1u)
#define WDG_23_DRIVERA_MEMMAP_SW_MINOR_VERSION (0u)

/*============================================================================*/

/* Version of AUTOSAR Specification */
#define CANIF_MEMMAP_AR_MAJOR_VERSION (4u)
#define CANIF_MEMMAP_AR_MINOR_VERSION (0u)
#define CANIF_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define CANIF_MEMMAP_SW_MAJOR_VERSION (1u)
#define CANIF_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define CANNM_MEMMAP_AR_MAJOR_VERSION (4u)
#define CANNM_MEMMAP_AR_MINOR_VERSION (0u)
#define CANNM_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define CANNM_MEMMAP_SW_MAJOR_VERSION (2u)
#define CANNM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define CANSM_MEMMAP_AR_MAJOR_VERSION (3u)
#define CANSM_MEMMAP_AR_MINOR_VERSION (0u)
#define CANSM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define CANSM_MEMMAP_SW_MAJOR_VERSION (1u)
#define CANSM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define CANTP_MEMMAP_AR_MAJOR_VERSION (4u)
#define CANTP_MEMMAP_AR_MINOR_VERSION (0u)
#define CANTP_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define CANTP_MEMMAP_SW_MAJOR_VERSION (2u)
#define CANTP_MEMMAP_SW_MINOR_VERSION (1u)

/* Version of AUTOSAR Specification */
#define CANTRCV_MEMMAP_AR_MAJOR_VERSION (3u)
#define CANTRCV_MEMMAP_AR_MINOR_VERSION (0u)
#define CANTRCV_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define CANTRCV_MEMMAP_SW_MAJOR_VERSION (1u)
#define CANTRCV_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define LINTRCV_MEMMAP_AR_MAJOR_VERSION (4u)
#define LINTRCV_MEMMAP_AR_MINOR_VERSION (0u)
#define LINTRCV_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define LINTRCV_MEMMAP_SW_MAJOR_VERSION (1u)
#define LINTRCV_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define COMM_MEMMAP_AR_MAJOR_VERSION (4u)
#define COMM_MEMMAP_AR_MINOR_VERSION (1u)
#define COMM_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define COMM_MEMMAP_SW_MAJOR_VERSION (2u)
#define COMM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define CRC_MEMMAP_AR_MAJOR_VERSION (3u)
#define CRC_MEMMAP_AR_MINOR_VERSION (0u)
#define CRC_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define CRC_MEMMAP_SW_MAJOR_VERSION (1u)
#define CRC_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define DCM_MEMMAP_AR_MAJOR_VERSION (3u)
#define DCM_MEMMAP_AR_MINOR_VERSION (0u)
#define DCM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define DCM_MEMMAP_SW_MAJOR_VERSION (1u)
#define DCM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define DEM_MEMMAP_AR_MAJOR_VERSION (3u)
#define DEM_MEMMAP_AR_MINOR_VERSION (0u)
#define DEM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define DEM_MEMMAP_SW_MAJOR_VERSION (1u)
#define DEM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define DET_MEMMAP_AR_MAJOR_VERSION (3u)
#define DET_MEMMAP_AR_MINOR_VERSION (0u)
#define DET_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define DET_MEMMAP_SW_MAJOR_VERSION (1u)
#define DET_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define EA_MEMMAP_AR_MAJOR_VERSION (3u)
#define EA_MEMMAP_AR_MINOR_VERSION (0u)
#define EA_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define EA_MEMMAP_SW_MAJOR_VERSION (1u)
#define EA_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define ECUM_MEMMAP_AR_MAJOR_VERSION (3u)
#define ECUM_MEMMAP_AR_MINOR_VERSION (0u)
#define ECUM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define ECUM_MEMMAP_SW_MAJOR_VERSION (1u)
#define ECUM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define EEP_MEMMAP_AR_MAJOR_VERSION (3u)
#define EEP_MEMMAP_AR_MINOR_VERSION (0u)
#define EEP_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define EEP_MEMMAP_SW_MAJOR_VERSION (1u)
#define EEP_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define FEE_MEMMAP_AR_MAJOR_VERSION (3u)
#define FEE_MEMMAP_AR_MINOR_VERSION (0u)
#define FEE_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define FEE_MEMMAP_SW_MAJOR_VERSION (1u)
#define FEE_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define FIM_MEMMAP_AR_MAJOR_VERSION (3u)
#define FIM_MEMMAP_AR_MINOR_VERSION (0u)
#define FIM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define FIM_MEMMAP_SW_MAJOR_VERSION (1u)
#define FIM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define FRNM_MEMMAP_AR_MAJOR_VERSION (3u)
#define FRNM_MEMMAP_AR_MINOR_VERSION (0u)
#define FRNM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define FRNM_MEMMAP_SW_MAJOR_VERSION (1u)
#define FRNM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define FRTP_MEMMAP_AR_MAJOR_VERSION (3u)
#define FRTP_MEMMAP_AR_MINOR_VERSION (0u)
#define FRTP_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define FRTP_MEMMAP_SW_MAJOR_VERSION (1u)
#define FRTP_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define IOHWAB_MEMMAP_AR_MAJOR_VERSION (3u)
#define IOHWAB_MEMMAP_AR_MINOR_VERSION (0u)
#define IOHWAB_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define IOHWAB_MEMMAP_SW_MAJOR_VERSION (1u)
#define IOHWAB_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define IPDUM_MEMMAP_AR_MAJOR_VERSION (3u)
#define IPDUM_MEMMAP_AR_MINOR_VERSION (0u)
#define IPDUM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define IPDUM_MEMMAP_SW_MAJOR_VERSION (1u)
#define IPDUM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define STBM_MEMMAP_AR_MAJOR_VERSION (4u)
#define STBM_MEMMAP_AR_MINOR_VERSION (0u)
#define STBM_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define STBM_MEMMAP_SW_MAJOR_VERSION (1u)
#define STBM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define LINIF_MEMMAP_AR_MAJOR_VERSION (4u)
#define LINIF_MEMMAP_AR_MINOR_VERSION (0u)
#define LINIF_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define LINIF_MEMMAP_SW_MAJOR_VERSION (2u)
#define LINIF_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define LINNM_MEMMAP_AR_MAJOR_VERSION (3u)
#define LINNM_MEMMAP_AR_MINOR_VERSION (0u)
#define LINNM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define LINNM_MEMMAP_SW_MAJOR_VERSION (1u)
#define LINNM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define LINSM_MEMMAP_AR_MAJOR_VERSION (3u)
#define LINSM_MEMMAP_AR_MINOR_VERSION (0u)
#define LINSM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define LINSM_MEMMAP_SW_MAJOR_VERSION (1u)
#define LINSM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define MEMIF_MEMMAP_AR_MAJOR_VERSION (3u)
#define MEMIF_MEMMAP_AR_MINOR_VERSION (0u)
#define MEMIF_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define MEMIF_MEMMAP_SW_MAJOR_VERSION (1u)
#define MEMIF_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define NM_MEMMAP_AR_MAJOR_VERSION (3u)
#define NM_MEMMAP_AR_MINOR_VERSION (0u)
#define NM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define NM_MEMMAP_SW_MAJOR_VERSION (1u)
#define NM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define NVM_MEMMAP_AR_MAJOR_VERSION (3u)
#define NVM_MEMMAP_AR_MINOR_VERSION (0u)
#define NVM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define NVM_MEMMAP_SW_MAJOR_VERSION (1u)
#define NVM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define OS_MEMMAP_AR_MAJOR_VERSION (4u)
#define OS_MEMMAP_AR_MINOR_VERSION (0u)
#define OS_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define OS_MEMMAP_SW_MAJOR_VERSION (1u)
#define OS_MEMMAP_SW_MINOR_VERSION (0u)
#define OS_MEMMAP_SW_PATCH_VERSION (0u)

/* Version of AUTOSAR Specification */
#define SCHM_MEMMAP_AR_MAJOR_VERSION (3u)
#define SCHM_MEMMAP_AR_MINOR_VERSION (0u)
#define SCHM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define SCHM_MEMMAP_SW_MAJOR_VERSION (1u)
#define SCHM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define WDGIF_MEMMAP_AR_MAJOR_VERSION (3u)
#define WDGIF_MEMMAP_AR_MINOR_VERSION (0u)
#define WDGIF_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define WDGIF_MEMMAP_SW_MAJOR_VERSION (1u)
#define WDGIF_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define WDGM_MEMMAP_AR_MAJOR_VERSION (3u)
#define WDGM_MEMMAP_AR_MINOR_VERSION (0u)
#define WDGM_MEMMAP_AR_PATCH_VERSION (0u)

/* Version of File/Software */
#define WDGM_MEMMAP_SW_MAJOR_VERSION (1u)
#define WDGM_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define FRTRCV_MEMMAP_AR_MAJOR_VERSION (4u)
#define FRTRCV_MEMMAP_AR_MINOR_VERSION (0u)
#define FRTRCV_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define FRTRCV_MEMMAP_SW_MAJOR_VERSION (2u)
#define FRTRCV_MEMMAP_SW_MINOR_VERSION (0u)

/* Version of AUTOSAR Specification */
#define FRSM_MEMMAP_AR_MAJOR_VERSION (4u)
#define FRSM_MEMMAP_AR_MINOR_VERSION (0u)
#define FRSM_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define FRSM_MEMMAP_SW_MAJOR_VERSION (2u)
#define FRSM_MEMMAP_SW_MINOR_VERSION (0u)


/* Version of AUTOSAR Specification */
#define NMEXT_MEMMAP_AR_MAJOR_VERSION (4u)
#define NMEXT_MEMMAP_AR_MINOR_VERSION (0u)
#define NMEXT_MEMMAP_AR_PATCH_VERSION (2u)

/* Version of File/Software */
#define NMEXT_MEMMAP_SW_MAJOR_VERSION (1u)
#define NMEXT_MEMMAP_SW_MINOR_VERSION (0u)

/*====================== MAPPING OF MODULE SECTIONS ==========================*/
#if defined (START_WITH_IF)
/* -------------------------- ADC Driver ------------------------------------ */

#elif defined (ADC_START_SEC_VAR_8BIT)
  #undef       ADC_START_SEC_VAR_8BIT
  #define      DEFAULT_START_SEC_VAR_8BIT
#elif defined   (ADC_STOP_SEC_VAR_8BIT)
  #undef       ADC_STOP_SEC_VAR_8BIT
  #define      DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (ADC_START_SEC_VAR_FAST_8BIT)
  #undef      ADC_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (ADC_STOP_SEC_VAR_FAST_8BIT)
  #undef      ADC_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (ADC_START_SEC_VAR_16BIT)
  #undef      ADC_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (ADC_STOP_SEC_VAR_16BIT)
  #undef      ADC_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (ADC_START_SEC_VAR_32BIT)
  #undef      ADC_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (ADC_STOP_SEC_VAR_32BIT)
  #undef      ADC_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (ADC_START_SEC_VAR_UNSPECIFIED)
  #undef      ADC_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (ADC_STOP_SEC_VAR_UNSPECIFIED)
  #undef      ADC_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (ADC_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      ADC_START_SEC_CONFIG_VAR_UNSPECIFIED
  /*#pragma ghs section sbss=".ADC_RAM_CONFIG_UNSPECIFIED"*/
#elif defined (ADC_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      ADC_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  /*#pragma ghs section sbss=default*/

#elif defined (ADC_START_SEC_CONST_8BIT)
  #undef      ADC_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (ADC_STOP_SEC_CONST_8BIT)
  #undef      ADC_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (ADC_START_SEC_CONST_16BIT)
  #undef      ADC_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (ADC_STOP_SEC_CONST_16BIT)
  #undef      ADC_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (ADC_START_SEC_CONST_UNSPECIFIED)
  #undef      ADC_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (ADC_STOP_SEC_CONST_UNSPECIFIED)
  #undef      ADC_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (ADC_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      ADC_START_SEC_CONFIG_CONST_UNSPECIFIED
  /*#pragma ghs section rosdata=".ADC_CFG_CONST_ROM_UNSPEC"*/
#elif defined (ADC_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      ADC_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  /*#pragma ghs section rosdata=default*/

#elif defined (ADC_START_SEC_PUBLIC_CODE)
  #undef      ADC_START_SEC_PUBLIC_CODE
  /*#pragma ghs section text=".ADC_PUBLIC_CODE_ROM"*/
#elif defined (ADC_STOP_SEC_PUBLIC_CODE)
  #undef      ADC_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (ADC_START_SEC_PRIVATE_CODE)
  #undef      ADC_START_SEC_PRIVATE_CODE
  /*#pragma ghs section text=".ADC_PRIVATE_CODE_ROM"*/
#elif defined (ADC_STOP_SEC_PRIVATE_CODE)
  #undef      ADC_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------- CAN Driver ------------------------------------ */
#elif defined (CAN_START_SEC_VAR_8BIT)
  #undef      CAN_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (CAN_STOP_SEC_VAR_8BIT)
  #undef      CAN_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (CAN_START_SEC_VAR_FAST_8BIT)
  #undef      CAN_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (CAN_STOP_SEC_VAR_FAST_8BIT)
  #undef      CAN_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (CAN_START_SEC_VAR_16BIT)
  #undef      CAN_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (CAN_STOP_SEC_VAR_16BIT)
  #undef      CAN_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (CAN_START_SEC_VAR_32BIT)
  #undef      CAN_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (CAN_STOP_SEC_VAR_32BIT)
  #undef      CAN_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (CAN_START_SEC_VAR_UNSPECIFIED)
  #undef      CAN_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CAN_STOP_SEC_VAR_UNSPECIFIED)
  #undef      CAN_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (CAN_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      CAN_START_SEC_CONFIG_VAR_UNSPECIFIED
  /*#pragma ghs section sbss=".CAN_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (CAN_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      CAN_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (CAN_START_SEC_CONST_8BIT)
  #undef      CAN_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (CAN_STOP_SEC_CONST_8BIT)
  #undef      CAN_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (CAN_START_SEC_CONST_16BIT)
  #undef      CAN_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (CAN_STOP_SEC_CONST_16BIT)
  #undef      CAN_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (CAN_START_SEC_CONST_UNSPECIFIED)
  #undef      CAN_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CAN_STOP_SEC_CONST_UNSPECIFIED)
  #undef      CAN_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CAN_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      CAN_START_SEC_CONFIG_CONST_UNSPECIFIED
  /*#pragma ghs section rosdata=".CAN_CFG_CONST_ROM_UNSPEC"*/
#elif defined (CAN_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      CAN_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  /*#pragma ghs section rosdata=default*/

#elif defined (CAN_START_SEC_PUBLIC_CODE)
  #undef      CAN_START_SEC_PUBLIC_CODE
  /*#pragma ghs section text=".CAN_PUBLIC_CODE_ROM"*/
#elif defined (CAN_STOP_SEC_PUBLIC_CODE)
  #undef      CAN_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (CAN_START_SEC_PRIVATE_CODE)
  #undef      CAN_START_SEC_PRIVATE_CODE
  /*#pragma ghs section text=".CAN_PRIVATE_CODE_ROM"*/
#elif defined (CAN_STOP_SEC_PRIVATE_CODE)
  #undef      CAN_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------- DIO Driver ------------------------------------ */
#elif defined (DIO_START_SEC_VAR_8BIT)
  #undef      DIO_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (DIO_STOP_SEC_VAR_8BIT)
  #undef      DIO_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (DIO_START_SEC_VAR_FAST_8BIT)
  #undef      DIO_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (DIO_STOP_SEC_VAR_FAST_8BIT)
  #undef      DIO_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (DIO_START_SEC_VAR_16BIT)
  #undef      DIO_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (DIO_STOP_SEC_VAR_16BIT)
  #undef      DIO_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (DIO_START_SEC_VAR_32BIT)
  #undef      DIO_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (DIO_STOP_SEC_VAR_32BIT)
  #undef      DIO_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (DIO_START_SEC_VAR_UNSPECIFIED)
  #undef      DIO_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (DIO_STOP_SEC_VAR_UNSPECIFIED)
  #undef      DIO_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DIO_START_SEC_CONST_8BIT)
  #undef      DIO_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (DIO_STOP_SEC_CONST_8BIT)
  #undef      DIO_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (DIO_START_SEC_CONST_16BIT)
  #undef      DIO_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (DIO_STOP_SEC_CONST_16BIT)
  #undef      DIO_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (DIO_START_SEC_CONST_32BIT)
  #undef      DIO_START_SEC_CONST_32BIT
  #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (DIO_STOP_SEC_CONST_32BIT)
  #undef      DIO_STOP_SEC_CONST_32BIT
  #define DEFAULT_STOP_SEC_CONST_32BIT


#elif defined (DIO_START_SEC_CONST_UNSPECIFIED)
  #undef      DIO_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DIO_STOP_SEC_CONST_UNSPECIFIED)
  #undef      DIO_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED


#elif defined (DIO_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      DIO_START_SEC_CONFIG_CONST_UNSPECIFIED
  #define START_SEC_DIO_CONFIG_CONST_UNSPECIFIED
#elif defined (DIO_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      DIO_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define STOP_SEC_DIO_CONFIG_CONST_UNSPECIFIED

#elif defined (DIO_START_SEC_PUBLIC_CODE)
  #undef      DIO_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".DIO_PUBLIC_CODE_ROM"*/
#elif defined (DIO_STOP_SEC_PUBLIC_CODE)
  #undef      DIO_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (DIO_START_SEC_PRIVATE_CODE)
  #undef      DIO_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".DIO_PRIVATE_CODE_ROM"*/
#elif defined (DIO_STOP_SEC_PRIVATE_CODE)
  #undef      DIO_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* ---------------------------------------------------------------------------*/
/*                   GPT Driver                                               */
/* ---------------------------------------------------------------------------*/
#elif defined (GPT_START_SEC_VAR_8BIT)
  #undef      GPT_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (GPT_STOP_SEC_VAR_8BIT)
  #undef      GPT_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (GPT_START_SEC_VAR_FAST_8BIT)
  #undef      GPT_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (GPT_STOP_SEC_VAR_FAST_8BIT)
  #undef      GPT_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (GPT_START_SEC_VAR_16BIT)
  #undef      GPT_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (GPT_STOP_SEC_VAR_16BIT)
  #undef      GPT_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (GPT_START_SEC_VAR_32BIT)
  #undef      GPT_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (GPT_STOP_SEC_VAR_32BIT)
  #undef      GPT_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (GPT_START_SEC_VAR_UNSPECIFIED)
  #undef      GPT_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (GPT_STOP_SEC_VAR_UNSPECIFIED)
  #undef      GPT_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (GPT_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      GPT_START_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_VAR_UNSPECIFIED
#elif defined (GPT_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      GPT_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_VAR_UNSPECIFIED

#elif defined (GPT_START_SEC_CONST_8BIT)
  #undef      GPT_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (GPT_STOP_SEC_CONST_8BIT)
  #undef      GPT_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (GPT_START_SEC_CONST_16BIT)
  #undef      GPT_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (GPT_STOP_SEC_CONST_16BIT)
  #undef      GPT_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (GPT_START_SEC_CONST_UNSPECIFIED)
  #undef      GPT_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (GPT_STOP_SEC_CONST_UNSPECIFIED)
  #undef      GPT_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (GPT_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      GPT_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".GPT_CFG_CONST_ROM_UNSPEC"*/
#elif defined (GPT_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      GPT_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=default*/

#elif defined (GPT_START_SEC_PUBLIC_CODE)
  #undef      GPT_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".GPT_PUBLIC_CODE_ROM"*/
#elif defined (GPT_STOP_SEC_PUBLIC_CODE)
  #undef      GPT_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (GPT_START_SEC_PRIVATE_CODE)
  #undef      GPT_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".GPT_PRIVATE_CODE_ROM"*/
#elif defined (GPT_STOP_SEC_PRIVATE_CODE)
  #undef      GPT_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
  
  
/******************************************************************************\
**  Sections for RTE Module
\******************************************************************************/

#elif defined (RTE_START_SEC_VAR_8BIT)
	#undef RTE_START_SEC_VAR_8BIT
	#define DEFAULT_START_SEC_VAR_8BIT
#elif defined (RTE_STOP_SEC_VAR_8BIT)
	#undef RTE_STOP_SEC_VAR_8BIT
	#define DEFAULT_STOP_SEC_VAR_8BIT
	
#elif defined (RTE_START_SEC_VAR_16BIT)
	#undef RTE_START_SEC_VAR_16BIT
	#define DEFAULT_START_SEC_VAR_16BIT
#elif defined (RTE_STOP_SEC_VAR_16BIT)
	#undef RTE_STOP_SEC_VAR_16BIT
	#define DEFAULT_STOP_SEC_VAR_16BIT
	
#elif defined (RTE_START_SEC_VAR_32BIT)
	#undef RTE_START_SEC_VAR_32BIT
	#define DEFAULT_START_SEC_VAR_32BIT
#elif defined (RTE_STOP_SEC_VAR_32BIT)
	#undef RTE_STOP_SEC_VAR_32BIT
	#define DEFAULT_STOP_SEC_VAR_32BIT
	
#elif defined (RTE_START_SEC_VAR_NVRAM_PRM)
	#undef RTE_START_SEC_VAR_NVRAM_PRM
	#define DEFAULT_START_SEC_VAR_NVRAM
#elif defined (RTE_STOP_SEC_VAR_NVRAM_PRM)
	#undef RTE_STOP_SEC_VAR_NVRAM_PRM
	#define DEFAULT_STOP_SEC_VAR_NVRAM
	
#elif defined (RTE_START_SEC_VAR_NVRAM_SEC)
	#undef RTE_START_SEC_VAR_NVRAM_SEC
	#define DEFAULT_START_SEC_VAR_NVRAM
#elif defined (RTE_STOP_SEC_VAR_NVRAM_SEC)
	#undef RTE_STOP_SEC_VAR_NVRAM_SEC
	#define DEFAULT_STOP_SEC_VAR_NVRAM
	
#elif defined (RTE_START_SEC_VAR_NVRAM_MIR)
	#undef RTE_START_SEC_VAR_NVRAM_MIR
	#define DEFAULT_START_SEC_VAR_NVRAM
#elif defined (RTE_STOP_SEC_VAR_NVRAM_MIR)
	#undef RTE_STOP_SEC_VAR_NVRAM_MIR
	#define DEFAULT_STOP_SEC_VAR_NVRAM
	
#elif defined (RTE_START_SEC_VAR_NVRAM_POSTBUILD)
	#undef RTE_START_SEC_VAR_NVRAM_POSTBUILD
	#define DEFAULT_START_SEC_VAR_NVRAM
#elif defined (RTE_STOP_SEC_VAR_NVRAM_POSTBUILD)
	#undef RTE_STOP_SEC_VAR_NVRAM_POSTBUILD
	#define DEFAULT_STOP_SEC_VAR_NVRAM
	
#elif defined (RTE_START_SEC_VAR_UNSPECIFIED)
	#undef RTE_START_SEC_VAR_UNSPECIFIED
	#define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (RTE_STOP_SEC_VAR_UNSPECIFIED)
	#undef RTE_STOP_SEC_VAR_UNSPECIFIED
	#define DEFAULT_STOP_SEC_VAR_UNSPECIFIED
	
#elif defined (RTE_START_SEC_VAR_FAST_8BIT)
	#undef RTE_START_SEC_VAR_FAST_8BIT
	#define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (RTE_STOP_SEC_VAR_FAST_8BIT)
	#undef RTE_STOP_SEC_VAR_FAST_8BIT
	#define DEFAULT_STOP_SEC_VAR_FAST_8BIT
	
#elif defined (RTE_START_SEC_VAR_FAST_16BIT)
	#undef RTE_START_SEC_VAR_FAST_16BIT
	#define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (RTE_STOP_SEC_VAR_FAST_16BIT)
	#undef RTE_STOP_SEC_VAR_FAST_16BIT
	#define DEFAULT_STOP_SEC_VAR_FAST_16BIT
	
#elif defined (RTE_START_SEC_VAR_FAST_32BIT)
	#undef RTE_START_SEC_VAR_FAST_32BIT
	#define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (RTE_STOP_SEC_VAR_FAST_32BIT)
	#undef RTE_STOP_SEC_VAR_FAST_32BIT
	#define DEFAULT_STOP_SEC_VAR_FAST_32BIT
	
#elif defined (RTE_START_SEC_VAR_FAST_UNSPECIFIED)
	#undef RTE_START_SEC_VAR_FAST_UNSPECIFIED
	#define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (RTE_STOP_SEC_VAR_FAST_UNSPECIFIED)
	#undef RTE_STOP_SEC_VAR_FAST_UNSPECIFIED
	#define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED
	
#elif defined (RTE_START_SEC_VAR_NOINIT_8BIT)
	#undef RTE_START_SEC_VAR_NOINIT_8BIT
	#define DEFAULT_START_SEC_VAR_NOINIT_8BIT
#elif defined (RTE_STOP_SEC_VAR_NOINIT_8BIT)
	#undef RTE_STOP_SEC_VAR_NOINIT_8BIT
	#define DEFAULT_STOP_SEC_VAR_NOINIT_8BIT
	
#elif defined (RTE_START_SEC_VAR_NOINIT_16BIT)
	#undef RTE_START_SEC_VAR_NOINIT_16BIT
	#define DEFAULT_START_SEC_VAR_NOINIT_16BIT
#elif defined (RTE_STOP_SEC_VAR_NOINIT_16BIT)
	#undef RTE_STOP_SEC_VAR_NOINIT_16BIT
	#define DEFAULT_STOP_SEC_VAR_NOINIT_16BIT
	
#elif defined (RTE_START_SEC_VAR_NOINIT_32BIT)
	#undef RTE_START_SEC_VAR_NOINIT_32BIT
	#define DEFAULT_START_SEC_VAR_NOINIT_32BIT
#elif defined (RTE_STOP_SEC_VAR_NOINIT_32BIT)
	#undef RTE_STOP_SEC_VAR_NOINIT_32BIT
	#define DEFAULT_STOP_SEC_VAR_NOINIT_32BIT
	
#elif defined (RTE_START_SEC_VAR_NOINIT_UNSPECIFIED)
	#undef RTE_START_SEC_VAR_NOINIT_UNSPECIFIED
	#define DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED
#elif defined (RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
	#undef RTE_STOP_SEC_VAR_NOINIT_UNSPECIFIED
	#define DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED
	
#elif defined (RTE_START_SEC_VAR_NOINIT_POSTBUILD)
	#undef RTE_START_SEC_VAR_NOINIT_POSTBUILD
	#define DEFAULT_START_SEC_VAR_NOINIT_POSTBUILD
#elif defined (RTE_STOP_SEC_VAR_NOINIT_POSTBUILD)
	#undef RTE_STOP_SEC_VAR_NOINIT_POSTBUILD
	#define DEFAULT_STOP_SEC_VAR_NOINIT_POSTBUILD
	
#elif defined (RTE_START_SEC_CONST_8BIT)
	#undef RTE_START_SEC_CONST_8BIT
	#define DEFAULT_START_SEC_CONST_8BIT
#elif defined (RTE_STOP_SEC_CONST_8BIT)
	#undef RTE_STOP_SEC_CONST_8BIT
	#define DEFAULT_STOP_SEC_CONST_8BIT
	
#elif defined (RTE_START_SEC_CONST_16BIT)
	#undef RTE_START_SEC_CONST_16BIT
	#define DEFAULT_START_SEC_CONST_16BIT
#elif defined (RTE_STOP_SEC_CONST_16BIT)
	#undef RTE_STOP_SEC_CONST_16BIT
	#define DEFAULT_STOP_SEC_CONST_16BIT
	
#elif defined (RTE_START_SEC_CONST_32BIT)
	#undef RTE_START_SEC_CONST_32BIT
	#define DEFAULT_START_SEC_CONST_32BIT
#elif defined (RTE_STOP_SEC_CONST_32BIT)
	#undef RTE_STOP_SEC_CONST_32BIT
	#define DEFAULT_STOP_SEC_CONST_32BIT
	
#elif defined (RTE_START_SEC_CONST_UNSPECIFIED)
	#undef RTE_START_SEC_CONST_UNSPECIFIED
	#define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (RTE_STOP_SEC_CONST_UNSPECIFIED)
	#undef RTE_STOP_SEC_CONST_UNSPECIFIED
	#define DEFAULT_STOP_SEC_CONST_UNSPECIFIED
	
#elif defined (RTE_START_SEC_CONST_POSTBUILD)
	#undef RTE_START_SEC_CONST_POSTBUILD
	#define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (RTE_STOP_SEC_CONST_POSTBUILD)
	#undef RTE_STOP_SEC_CONST_POSTBUILD
	#define DEFAULT_STOP_SEC_CONST_UNSPECIFIED
	
#elif defined (RTE_START_SEC_CODE)
	#undef RTE_START_SEC_CODE
	#define DEFAULT_START_SEC_CODE
#elif defined (RTE_STOP_SEC_CODE)
	#undef RTE_STOP_SEC_CODE
	#define DEFAULT_STOP_SEC_CODE
	
  
  
/******************************************************************************\
**  Sections for DCM Module
\******************************************************************************/

#elif defined (DCM_START_SEC_VAR_8BIT)
	#undef     DCM_START_SEC_VAR_8BIT
	#define    DEFAULT_START_SEC_VAR_8BIT
#elif defined (DCM_STOP_SEC_VAR_8BIT)
	#undef     DCM_STOP_SEC_VAR_8BIT
	#define    DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (DCM_START_SEC_VAR_UNSPECIFIED)
	#undef     DCM_START_SEC_VAR_UNSPECIFIED
	#define    DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_UNSPECIFIED)
	#undef     DCM_STOP_SEC_VAR_UNSPECIFIED
	#define    DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DCM_START_SEC_VAR_NOINIT_UNSPECIFIED)
	#undef     DCM_START_SEC_VAR_NOINIT_UNSPECIFIED
	#define    DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
	#undef     DCM_STOP_SEC_VAR_NOINIT_UNSPECIFIED
	#define    DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED

#elif defined (DCM_START_SEC_CONST_UNSPECIFIED)
	#undef     DCM_START_SEC_CONST_UNSPECIFIED
	#define    DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DCM_STOP_SEC_CONST_UNSPECIFIED)
	#undef     DCM_STOP_SEC_CONST_UNSPECIFIED
	#define    DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DCM_START_SEC_CODE)
	#undef     DCM_START_SEC_CODE
	#define    DEFAULT_START_SEC_CODE
#elif defined (DCM_STOP_SEC_CODE)
	#undef     DCM_STOP_SEC_CODE
	#define    DEFAULT_STOP_SEC_CODE

/******************************************************************************\
**  Sections for DEM Module
\******************************************************************************/

#elif defined (DEM_START_SEC_VAR_8BIT)
	#undef     DEM_START_SEC_VAR_8BIT
	#define	   DEFAULT_START_SEC_VAR_8BIT
#elif defined (DEM_STOP_SEC_VAR_8BIT)
	#undef     DEM_STOP_SEC_VAR_8BIT
	#define	   DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (DEM_START_SEC_VAR_NVRAM_COMMON)
	#undef     DEM_START_SEC_VAR_NVRAM_COMMON
	#define	   DEFAULT_START_SEC_VAR_NVRAM
#elif defined (DEM_STOP_SEC_VAR_NVRAM_COMMON)
	#undef     DEM_STOP_SEC_VAR_NVRAM_COMMON
	#define	   DEFAULT_STOP_SEC_VAR_NVRAM

#elif defined (DEM_START_SEC_VAR_UNSPECIFIED)
	#undef     DEM_START_SEC_VAR_UNSPECIFIED
	#define	   DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (DEM_STOP_SEC_VAR_UNSPECIFIED)
	#undef     DEM_STOP_SEC_VAR_UNSPECIFIED
	#define	   DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DEM_START_SEC_CONST_8BIT)
	#undef     DEM_START_SEC_CONST_8BIT
	#define	   DEFAULT_START_SEC_CONST_8BIT
#elif defined (DEM_STOP_SEC_CONST_8BIT)
	#undef     DEM_STOP_SEC_CONST_8BIT
	#define	   DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (DEM_START_SEC_CONST_UNSPECIFIED)
	#undef     DEM_START_SEC_CONST_UNSPECIFIED
	#define	   DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DEM_STOP_SEC_CONST_UNSPECIFIED)
	#undef     DEM_STOP_SEC_CONST_UNSPECIFIED
	#define	   DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DEM_START_SEC_CONST_POSTBUILD)
	#undef     DEM_START_SEC_CONST_POSTBUILD
	#define	   DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DEM_STOP_SEC_CONST_POSTBUILD)
	#undef     DEM_STOP_SEC_CONST_POSTBUILD
	#define	   DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DEM_START_SEC_CODE)
	#undef     DEM_START_SEC_CODE
	#define	   DEFAULT_START_SEC_CODE
#elif defined (DEM_STOP_SEC_CODE)
	#undef     DEM_STOP_SEC_CODE
	#define	   DEFAULT_STOP_SEC_CODE

/******************************************************************************\
**  Sections for DET Module
\******************************************************************************/
#elif defined (DET_START_SEC_VAR_8BIT)
	#undef	   DET_START_SEC_VAR_8BIT
	#define	   DEFAULT_START_SEC_VAR_8BIT
#elif defined (DET_STOP_SEC_VAR_8BIT)
	#undef	   DET_STOP_SEC_VAR_8BIT
	#define	   DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (DET_START_SEC_VAR_16BIT)
	#undef	   DET_START_SEC_VAR_16BIT
	#define	   DEFAULT_START_SEC_VAR_16BIT
#elif defined (DET_STOP_SEC_VAR_16BIT)
	#undef	   DET_STOP_SEC_VAR_16BIT
	#define	   DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (DET_START_SEC_VAR_32BIT)
	#undef	   DET_START_SEC_VAR_32BIT
	#define	   DEFAULT_START_SEC_VAR_32BIT
#elif defined (DET_STOP_SEC_VAR_32BIT)
	#undef	   DET_STOP_SEC_VAR_32BIT
	#define	   DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (DET_START_SEC_VAR_UNSPECIFIED)
	#undef	   DET_START_SEC_VAR_UNSPECIFIED
	#define    DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (DET_STOP_SEC_VAR_UNSPECIFIED)
	#undef	   DET_STOP_SEC_VAR_UNSPECIFIED
	#define	   DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DET_START_SEC_VAR_FAST_8BIT)
	#undef	   DET_START_SEC_VAR_FAST_8BIT
	#define	   DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (DET_STOP_SEC_VAR_FAST_8BIT)
	#undef	   DET_STOP_SEC_VAR_FAST_8BIT
	#define	   DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (DET_START_SEC_VAR_FAST_16BIT)
	#undef	   DET_START_SEC_VAR_FAST_16BIT
	#define	   DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (DET_STOP_SEC_VAR_FAST_16BIT)
	#undef	   DET_STOP_SEC_VAR_FAST_16BIT
	#define	   DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (DET_START_SEC_VAR_FAST_32BIT)
	#undef	   DET_START_SEC_VAR_FAST_32BIT
	#define	   DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (DET_STOP_SEC_VAR_FAST_32BIT)
	#undef	   DET_STOP_SEC_VAR_FAST_32BIT
	#define	   DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (DET_START_SEC_VAR_FAST_UNSPECIFIED)
	#undef	   DET_START_SEC_VAR_FAST_UNSPECIFIED
	#define	   DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (DET_STOP_SEC_VAR_FAST_UNSPECIFIED)
	#undef	   DET_STOP_SEC_VAR_FAST_UNSPECIFIED
	#define	   DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

#elif defined (DET_START_SEC_VAR_NOINIT_8BIT)
	#undef	   DET_START_SEC_VAR_NOINIT_8BIT
	#define	   DEFAULT_START_SEC_VAR_NOINIT_8BIT
#elif defined (DET_STOP_SEC_VAR_NOINIT_8BIT)
	#undef	   DET_STOP_SEC_VAR_NOINIT_8BIT
	#define	   DEFAULT_STOP_SEC_VAR_NOINIT_8BIT

#elif defined (DET_START_SEC_VAR_NOINIT_16BIT)
	#undef	   DET_START_SEC_VAR_NOINIT_16BIT
	#define	   DEFAULT_START_SEC_VAR_NOINIT_16BIT
#elif defined (DET_STOP_SEC_VAR_NOINIT_16BIT)
	#undef	   DET_STOP_SEC_VAR_NOINIT_16BIT
	#define	   DEFAULT_STOP_SEC_VAR_NOINIT_16BIT

#elif defined (DET_START_SEC_VAR_NOINIT_32BIT)
	#undef     DET_START_SEC_VAR_NOINIT_32BIT
	#define    DEFAULT_START_SEC_VAR_NOINIT_32BIT
#elif defined (DET_STOP_SEC_VAR_NOINIT_32BIT)
	#undef     DET_STOP_SEC_VAR_NOINIT_32BIT
	#define    DEFAULT_STOP_SEC_VAR_NOINIT_32BIT

#elif defined (DET_START_SEC_VAR_NOINIT_UNSPECIFIED)
	#undef     DET_START_SEC_VAR_NOINIT_UNSPECIFIED
	#define    DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED
#elif defined (DET_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
	#undef     DET_STOP_SEC_VAR_NOINIT_UNSPECIFIED
	#define    DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED

#elif defined (DET_START_SEC_CONST_8BIT)
	#undef     DET_START_SEC_CONST_8BIT
	#define    DEFAULT_START_SEC_CONST_8BIT
#elif defined (DET_STOP_SEC_CONST_8BIT)
	#undef     DET_STOP_SEC_CONST_8BIT
	#define    DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (DET_START_SEC_CONST_16BIT)
	#undef     DET_START_SEC_CONST_16BIT
	#define    DEFAULT_START_SEC_CONST_16BIT
#elif defined (DET_STOP_SEC_CONST_16BIT)
	#undef     DET_STOP_SEC_CONST_16BIT
	#define    DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (DET_START_SEC_CONST_32BIT)
	#undef     DET_START_SEC_CONST_32BIT
	#define    DEFAULT_START_SEC_CONST_32BIT
#elif defined (DET_STOP_SEC_CONST_32BIT)
	#undef     DET_STOP_SEC_CONST_32BIT
	#define    DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (DET_START_SEC_CONST_UNSPECIFIED)
	#undef     DET_START_SEC_CONST_UNSPECIFIED
	#define    DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DET_STOP_SEC_CONST_UNSPECIFIED)
	#undef     DET_STOP_SEC_CONST_UNSPECIFIED
	#define    DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DET_START_SEC_CONST_POSTBUILD)
	#undef     DET_START_SEC_CONST_POSTBUILD
	#define    DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DET_STOP_SEC_CONST_POSTBUILD)
	#undef     DET_STOP_SEC_CONST_POSTBUILD
	#define    DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DET_START_SEC_CODE)
	#undef     DET_START_SEC_CODE
	#define    DEFAULT_START_SEC_CODE
#elif defined (DET_STOP_SEC_CODE)
	#undef     DET_STOP_SEC_CODE
	#define    DEFAULT_STOP_SEC_CODE

  
  
/* ---------------------------------------------------------------------------*/
/*                   ICU Driver                                               */
/* ---------------------------------------------------------------------------*/
#elif defined (ICU_START_SEC_VAR_8BIT)
  #undef      ICU_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (ICU_STOP_SEC_VAR_8BIT)
  #undef      ICU_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (ICU_START_SEC_VAR_FAST_8BIT)
  #undef      ICU_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (ICU_STOP_SEC_VAR_FAST_8BIT)
  #undef      ICU_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (ICU_START_SEC_VAR_16BIT)
  #undef      ICU_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (ICU_STOP_SEC_VAR_16BIT)
  #undef      ICU_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (ICU_START_SEC_VAR_32BIT)
  #undef      ICU_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (ICU_STOP_SEC_VAR_32BIT)
  #undef      ICU_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (ICU_START_SEC_VAR_UNSPECIFIED)
  #undef      ICU_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (ICU_STOP_SEC_VAR_UNSPECIFIED)
  #undef      ICU_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (ICU_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      ICU_START_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_VAR_UNSPECIFIED
#elif defined (ICU_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      ICU_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_VAR_UNSPECIFIED

#elif defined (ICU_START_SEC_CONST_8BIT)
  #undef      ICU_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (ICU_STOP_SEC_CONST_8BIT)
  #undef      ICU_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (ICU_START_SEC_CONST_16BIT)
  #undef      ICU_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (ICU_STOP_SEC_CONST_16BIT)
  #undef      ICU_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (ICU_START_SEC_CONST_UNSPECIFIED)
  #undef      ICU_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (ICU_STOP_SEC_CONST_UNSPECIFIED)
  #undef      ICU_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (ICU_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      ICU_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".ICU_CFG_CONST_ROM_UNSPEC"*/
#elif defined (ICU_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      ICU_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=default*/

#elif defined (ICU_START_SEC_PUBLIC_CODE)
  #undef      ICU_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".ICU_PUBLIC_CODE_ROM"*/
#elif defined (ICU_STOP_SEC_PUBLIC_CODE)
  #undef      ICU_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (ICU_START_SEC_PRIVATE_CODE)
  #undef      ICU_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".ICU_PRIVATE_CODE_ROM"*/
#elif defined (ICU_STOP_SEC_PRIVATE_CODE)
  #undef      ICU_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                  LIN (LIN Driver)                                          */
/* -------------------------------------------------------------------------- */
#elif defined (LIN_START_SEC_VAR_8BIT)
  #undef      LIN_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (LIN_STOP_SEC_VAR_8BIT)
  #undef      LIN_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (LIN_START_SEC_VAR_FAST_8BIT)
  #undef      LIN_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (LIN_STOP_SEC_VAR_FAST_8BIT)
  #undef      LIN_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (LIN_START_SEC_VAR_16BIT)
  #undef      LIN_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (LIN_STOP_SEC_VAR_16BIT)
  #undef      LIN_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (LIN_START_SEC_VAR_32BIT)
  #undef      LIN_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (LIN_STOP_SEC_VAR_32BIT)
  #undef      LIN_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (LIN_START_SEC_VAR_UNSPECIFIED)
  #undef      LIN_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (LIN_STOP_SEC_VAR_UNSPECIFIED)
  #undef      LIN_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (LIN_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      LIN_START_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_VAR_UNSPECIFIED
#elif defined (LIN_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      LIN_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_VAR_UNSPECIFIED

#elif defined (LIN_START_SEC_CONST_8BIT)
  #undef      LIN_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (LIN_STOP_SEC_CONST_8BIT)
  #undef      LIN_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (LIN_START_SEC_CONST_16BIT)
  #undef      LIN_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (LIN_STOP_SEC_CONST_16BIT)
  #undef      LIN_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (LIN_START_SEC_CONST_UNSPECIFIED)
  #undef      LIN_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LIN_STOP_SEC_CONST_UNSPECIFIED)
  #undef      LIN_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LIN_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      LIN_START_SEC_CONFIG_CONST_UNSPECIFIED
  #define START_SEC_LIN_CONFIG_CONST_UNSPECIFIED
#elif defined (LIN_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      LIN_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define STOP_SEC_LIN_CONFIG_CONST_UNSPECIFIED

#elif defined (LIN_START_SEC_PUBLIC_CODE)
  #undef      LIN_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".LIN_PUBLIC_CODE_ROM"*/
#elif defined (LIN_STOP_SEC_PUBLIC_CODE)
  #undef      LIN_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (LIN_START_SEC_PRIVATE_CODE)
  #undef      LIN_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".LIN_PRIVATE_CODE_ROM"*/
#elif defined (LIN_STOP_SEC_PRIVATE_CODE)
  #undef      LIN_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (LIN_START_SEC_CODE)
  #undef      LIN_START_SEC_CODE
  #define DEFAULT_START_SEC_CODE
   /*#pragma ghs section text=".LIN_PRIVATE_CODE_ROM"*/
#elif defined (LIN_STOP_SEC_CODE)
  #undef      LIN_STOP_SEC_CODE
  #define DEFAULT_STOP_SEC_CODE


/* -------------------------------------------------------------------------- */
/*                   MCU Driver                                               */
/* -------------------------------------------------------------------------- */
#elif defined (MCU_START_SEC_VAR_8BIT)
  #undef      MCU_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (MCU_STOP_SEC_VAR_8BIT)
  #undef      MCU_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (MCU_START_SEC_VAR_FAST_8BIT)
  #undef      MCU_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (MCU_STOP_SEC_VAR_FAST_8BIT)
  #undef      MCU_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (MCU_START_SEC_VAR_16BIT)
  #undef      MCU_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (MCU_STOP_SEC_VAR_16BIT)
  #undef      MCU_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (MCU_START_SEC_VAR_32BIT)
  #undef      MCU_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (MCU_STOP_SEC_VAR_32BIT)
  #undef      MCU_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (MCU_START_SEC_VAR_UNSPECIFIED)
  #undef      MCU_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (MCU_STOP_SEC_VAR_UNSPECIFIED)
  #undef      MCU_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (MCU_START_SEC_CONST_8BIT)
  #undef      MCU_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (MCU_STOP_SEC_CONST_8BIT)
  #undef      MCU_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (MCU_START_SEC_CONST_16BIT)
  #undef      MCU_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (MCU_STOP_SEC_CONST_16BIT)
  #undef      MCU_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (MCU_START_SEC_CONST_UNSPECIFIED)
  #undef      MCU_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (MCU_STOP_SEC_CONST_UNSPECIFIED)
  #undef      MCU_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (MCU_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      MCU_START_SEC_CONFIG_CONST_UNSPECIFIED
  #define START_SEC_MCU_CONFIG_CONST_UNSPECIFIED
#elif defined (MCU_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      MCU_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define STOP_SEC_MCU_CONFIG_CONST_UNSPECIFIED

#elif defined (MCU_START_SEC_PUBLIC_CODE)
  #undef      MCU_START_SEC_PUBLIC_CODE
  #define DEFAULT_START_SEC_CODE
   /*#pragma ghs section text=".MCU_PUBLIC_CODE_ROM"*/
#elif defined (MCU_STOP_SEC_PUBLIC_CODE)
  #undef      MCU_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (MCU_START_SEC_PRIVATE_CODE)
  #undef      MCU_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".MCU_PRIVATE_CODE_ROM"*/
#elif defined (MCU_STOP_SEC_PRIVATE_CODE)
  #undef      MCU_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*                   PORT Driver                                              */
/* -------------------------------------------------------------------------- */
#elif defined (PORT_START_SEC_VAR_8BIT)
  #undef      PORT_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (PORT_STOP_SEC_VAR_8BIT)
  #undef      PORT_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (PORT_START_SEC_VAR_FAST_8BIT)
  #undef      PORT_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (PORT_STOP_SEC_VAR_FAST_8BIT)
  #undef      PORT_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (PORT_START_SEC_VAR_16BIT)
  #undef      PORT_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (PORT_STOP_SEC_VAR_16BIT)
  #undef      PORT_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (PORT_START_SEC_VAR_32BIT)
  #undef      PORT_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (PORT_STOP_SEC_VAR_32BIT)
  #undef      PORT_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (PORT_START_SEC_VAR_UNSPECIFIED)
  #undef      PORT_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (PORT_STOP_SEC_VAR_UNSPECIFIED)
  #undef      PORT_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (PORT_START_SEC_CONST_8BIT)
  #undef      PORT_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (PORT_STOP_SEC_CONST_8BIT)
  #undef      PORT_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (PORT_START_SEC_CONST_16BIT)
  #undef      PORT_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (PORT_STOP_SEC_CONST_16BIT)
  #undef      PORT_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (PORT_START_SEC_CONST_UNSPECIFIED)
  #undef      PORT_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (PORT_STOP_SEC_CONST_UNSPECIFIED)
  #undef      PORT_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (PORT_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      PORT_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".PORT_CFG_CONST_ROM_UNSPEC"*/
#elif defined (PORT_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      PORT_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=default*/

#elif defined (PORT_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      PORT_START_SEC_CONFIG_CONST_UNSPECIFIED
  #define START_SEC_PORT_CONFIG_CONST_UNSPECIFIED
#elif defined (PORT_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      PORT_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define STOP_SEC_PORT_CONFIG_CONST_UNSPECIFIED

#elif defined (PORT_START_SEC_PUBLIC_CODE)
  #undef      PORT_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".PORT_PUBLIC_CODE_ROM"*/
#elif defined (PORT_STOP_SEC_PUBLIC_CODE)
  #undef      PORT_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (PORT_START_SEC_PRIVATE_CODE)
  #undef      PORT_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".PORT_PRIVATE_CODE_ROM"*/
#elif defined (PORT_STOP_SEC_PRIVATE_CODE)
  #undef      PORT_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* ---------------------------------------------------------------------------*/
/*                   PWM Driver                                               */
/* ---------------------------------------------------------------------------*/
#elif defined (PWM_START_SEC_VAR_8BIT)
  #undef      PWM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (PWM_STOP_SEC_VAR_8BIT)
  #undef      PWM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (PWM_START_SEC_VAR_FAST_8BIT)
  #undef      PWM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (PWM_STOP_SEC_VAR_FAST_8BIT)
  #undef      PWM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (PWM_START_SEC_VAR_16BIT)
  #undef      PWM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (PWM_STOP_SEC_VAR_16BIT)
  #undef      PWM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (PWM_START_SEC_VAR_32BIT)
  #undef      PWM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (PWM_STOP_SEC_VAR_32BIT)
  #undef      PWM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (PWM_START_SEC_VAR_UNSPECIFIED)
  #undef      PWM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (PWM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      PWM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (PWM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      PWM_START_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_VAR_UNSPECIFIED
#elif defined (PWM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      PWM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_VAR_UNSPECIFIED

#elif defined (PWM_START_SEC_CONST_8BIT)
  #undef      PWM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (PWM_STOP_SEC_CONST_8BIT)
  #undef      PWM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (PWM_START_SEC_CONST_16BIT)
  #undef      PWM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (PWM_STOP_SEC_CONST_16BIT)
  #undef      PWM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (PWM_START_SEC_CONST_UNSPECIFIED)
  #undef      PWM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (PWM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      PWM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (PWM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      PWM_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".PWM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (PWM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      PWM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=default*/

#elif defined (PWM_START_SEC_PUBLIC_CODE)
  #undef      PWM_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".PWM_PUBLIC_CODE_ROM"*/
#elif defined (PWM_STOP_SEC_PUBLIC_CODE)
  #undef      PWM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (PWM_START_SEC_PRIVATE_CODE)
  #undef      PWM_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".PWM_PRIVATE_CODE_ROM"*/
#elif defined (PWM_STOP_SEC_PRIVATE_CODE)
  #undef      PWM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             SPI (SPI Driver)                                               */
/* -------------------------------------------------------------------------- */

#elif defined (SPI_START_SEC_VAR_8BIT)
  #undef      SPI_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (SPI_STOP_SEC_VAR_8BIT)
  #undef      SPI_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (SPI_START_SEC_VAR_FAST_8BIT)
  #undef      SPI_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (SPI_STOP_SEC_VAR_FAST_8BIT)
  #undef      SPI_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (SPI_START_SEC_VAR_16BIT)
  #undef      SPI_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (SPI_STOP_SEC_VAR_16BIT)
  #undef      SPI_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (SPI_START_SEC_VAR_32BIT)
  #undef      SPI_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (SPI_STOP_SEC_VAR_32BIT)
  #undef      SPI_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (SPI_START_SEC_VAR_UNSPECIFIED)
  #undef      SPI_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (SPI_STOP_SEC_VAR_UNSPECIFIED)
  #undef      SPI_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (SPI_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      SPI_START_SEC_CONFIG_VAR_UNSPECIFIED
   /*#pragma ghs section sbss=".SPI_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (SPI_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      SPI_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (SPI_START_SEC_CONST_8BIT)
  #undef      SPI_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (SPI_STOP_SEC_CONST_8BIT)
  #undef      SPI_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (SPI_START_SEC_CONST_16BIT)
  #undef      SPI_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (SPI_STOP_SEC_CONST_16BIT)
  #undef      SPI_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (SPI_START_SEC_CONST_UNSPECIFIED)
  #undef      SPI_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (SPI_STOP_SEC_CONST_UNSPECIFIED)
  #undef      SPI_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (SPI_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      SPI_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".SPI_CFG_CONST_ROM_UNSPEC"*/
#elif defined (SPI_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      SPI_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=default*/

#elif defined (SPI_START_SEC_PUBLIC_CODE)
  #undef      SPI_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".SPI_PUBLIC_CODE_ROM"*/
#elif defined (SPI_STOP_SEC_PUBLIC_CODE)
  #undef      SPI_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (SPI_START_SEC_PRIVATE_CODE)
  #undef      SPI_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".SPI_PRIVATE_CODE_ROM"*/
#elif defined (SPI_STOP_SEC_PRIVATE_CODE)
  #undef      SPI_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (SPI_START_SEC_APPL_CODE)
  #undef      SPI_START_SEC_APPL_CODE
   /*#pragma ghs section text=".SPI_APPL_CODE_ROM"*/
#elif defined (SPI_STOP_SEC_APPL_CODE)
  #undef      SPI_STOP_SEC_APPL_CODE
  #define DEFAULT_STOP_SEC_CODE

/* ------------------------------------------------------------------------- */
/*                   Watchdog Driver                                         */
/* ------------------------------------------------------------------------- */
#elif defined (WDG_23_DRIVERA_START_SEC_VAR_8BIT)
  #undef      WDG_23_DRIVERA_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (WDG_23_DRIVERA_STOP_SEC_VAR_8BIT)
  #undef      WDG_23_DRIVERA_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (WDG_23_DRIVERA_START_SEC_VAR_FAST_8BIT)
  #undef      WDG_23_DRIVERA_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (WDG_23_DRIVERA_STOP_SEC_VAR_FAST_8BIT)
  #undef      WDG_23_DRIVERA_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (WDG_23_DRIVERA_START_SEC_VAR_16BIT)
  #undef      WDG_23_DRIVERA_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (WDG_23_DRIVERA_STOP_SEC_VAR_16BIT)
  #undef      WDG_23_DRIVERA_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (WDG_23_DRIVERA_START_SEC_VAR_32BIT)
  #undef      WDG_23_DRIVERA_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (WDG_23_DRIVERA_STOP_SEC_VAR_32BIT)
  #undef      WDG_23_DRIVERA_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (WDG_23_DRIVERA_START_SEC_VAR_UNSPECIFIED)
  #undef      WDG_23_DRIVERA_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (WDG_23_DRIVERA_STOP_SEC_VAR_UNSPECIFIED)
  #undef      WDG_23_DRIVERA_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (WDG_23_DRIVERA_START_SEC_CONST_8BIT)
  #undef      WDG_23_DRIVERA_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (WDG_23_DRIVERA_STOP_SEC_CONST_8BIT)
  #undef      WDG_23_DRIVERA_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (WDG_23_DRIVERA_START_SEC_CONST_16BIT)
  #undef      WDG_23_DRIVERA_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (WDG_23_DRIVERA_STOP_SEC_CONST_16BIT)
  #undef      WDG_23_DRIVERA_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (WDG_23_DRIVERA_START_SEC_CONST_UNSPECIFIED)
  #undef      WDG_23_DRIVERA_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDG_23_DRIVERA_STOP_SEC_CONST_UNSPECIFIED)
  #undef      WDG_23_DRIVERA_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDG_23_DRIVERA_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      WDG_23_DRIVERA_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".WDG_CFG_CONST_ROM_UNSPEC"*/
#elif defined (WDG_23_DRIVERA_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      WDG_23_DRIVERA_STOP_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=default*/

#elif defined (WDG_23_DRIVERA_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      WDG_23_DRIVERA_START_SEC_CONFIG_CONST_UNSPECIFIED
  #define START_SEC_WDG_CONFIG_CONST_UNSPECIFIED
#elif defined (WDG_23_DRIVERA_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      WDG_23_DRIVERA_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define STOP_SEC_WDG_CONFIG_CONST_UNSPECIFIED

#elif defined (WDG_23_DRIVERA_START_SEC_PUBLIC_CODE)
  #undef      WDG_23_DRIVERA_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".WDG_PUBLIC_CODE_ROM"*/
#elif defined (WDG_23_DRIVERA_STOP_SEC_PUBLIC_CODE)
  #undef      WDG_23_DRIVERA_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (WDG_23_DRIVERA_START_SEC_PRIVATE_CODE)
  #undef      WDG_23_DRIVERA_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".WDG_PRIVATE_CODE_ROM"*/
#elif defined (WDG_23_DRIVERA_STOP_SEC_PRIVATE_CODE)
  #undef      WDG_23_DRIVERA_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             CANIF (CAN Interface)                                          */
/* -------------------------------------------------------------------------- */

/*
 * CANIF (CAN Interface)
 */

/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (CANIF_START_SEC_CODE)
   #undef      CANIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CANIF_STOP_SEC_CODE)
   #undef      CANIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (CANIF_START_SEC_VAR_BOOLEAN)
   #undef      CANIF_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (CANIF_STOP_SEC_VAR_BOOLEAN)
   #undef      CANIF_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (CANIF_START_SEC_VAR_8BIT)
   #undef      CANIF_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (CANIF_STOP_SEC_VAR_8BIT)
   #undef      CANIF_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (CANIF_START_SEC_VAR_16BIT)
   #undef      CANIF_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (CANIF_STOP_SEC_VAR_16BIT)
   #undef      CANIF_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (CANIF_START_SEC_VAR_32BIT)
   #undef      CANIF_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (CANIF_STOP_SEC_VAR_32BIT)
   #undef      CANIF_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (CANIF_START_SEC_VAR_UNSPECIFIED)
   #undef      CANIF_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_VAR_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (CANIF_START_SEC_VAR_FAST_BOOLEAN)
   #undef      CANIF_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (CANIF_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      CANIF_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (CANIF_START_SEC_VAR_FAST_8BIT)
   #undef      CANIF_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (CANIF_STOP_SEC_VAR_FAST_8BIT)
   #undef      CANIF_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (CANIF_START_SEC_VAR_FAST_16BIT)
   #undef      CANIF_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (CANIF_STOP_SEC_VAR_FAST_16BIT)
   #undef      CANIF_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (CANIF_START_SEC_VAR_FAST_32BIT)
   #undef      CANIF_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (CANIF_STOP_SEC_VAR_FAST_32BIT)
   #undef      CANIF_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (CANIF_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      CANIF_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (CANIF_START_SEC_CONST_BOOLEAN)
   #undef      CANIF_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (CANIF_STOP_SEC_CONST_BOOLEAN)
   #undef      CANIF_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (CANIF_START_SEC_CONST_8BIT)
   #undef      CANIF_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (CANIF_STOP_SEC_CONST_8BIT)
   #undef      CANIF_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (CANIF_START_SEC_CONST_16BIT)
   #undef      CANIF_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (CANIF_STOP_SEC_CONST_16BIT)
   #undef      CANIF_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (CANIF_START_SEC_CONST_32BIT)
   #undef      CANIF_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (CANIF_STOP_SEC_CONST_32BIT)
   #undef      CANIF_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (CANIF_START_SEC_CONST_UNSPECIFIED)
   #undef      CANIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (CANIF_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      CANIF_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (CANIF_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      CANIF_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (CANIF_START_SEC_CONFIG_DATA_8BIT)
   #undef      CANIF_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (CANIF_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      CANIF_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (CANIF_START_SEC_CONFIG_DATA_16BIT)
   #undef      CANIF_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (CANIF_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      CANIF_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (CANIF_START_SEC_CONFIG_DATA_32BIT)
   #undef      CANIF_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (CANIF_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      CANIF_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (CANIF_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      CANIF_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (CANIF_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      CANIF_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (CANIF_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      CANIF_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (CANIF_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      CANIF_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (CANIF_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      CANIF_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (CANIF_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      CANIF_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (CANIF_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      CANIF_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (CANIF_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      CANIF_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (CANIF_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      CANIF_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (CANIF_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      CANIF_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (CANIF_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      CANIF_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (CANIF_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      CANIF_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (CANIF_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      CANIF_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (CANIF_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      CANIF_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (CANIF_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      CANIF_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (CANIF_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      CANIF_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (CANIF_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      CANIF_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (CANIF_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      CANIF_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (CANIF_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      CANIF_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (CANIF_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      CANIF_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             CANSM (CAN State Manager)                                      */
/* -------------------------------------------------------------------------- */
/*
 * CANSM (CAN State Manager)
 */

/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (CANSM_START_SEC_CODE)
   #undef      CANSM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CANSM_STOP_SEC_CODE)
   #undef      CANSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (CANSM_START_SEC_VAR_BOOLEAN)
   #undef      CANSM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (CANSM_STOP_SEC_VAR_BOOLEAN)
   #undef      CANSM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (CANSM_START_SEC_VAR_8BIT)
   #undef      CANSM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (CANSM_STOP_SEC_VAR_8BIT)
   #undef      CANSM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (CANSM_START_SEC_VAR_16BIT)
   #undef      CANSM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (CANSM_STOP_SEC_VAR_16BIT)
   #undef      CANSM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (CANSM_START_SEC_VAR_32BIT)
   #undef      CANSM_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (CANSM_STOP_SEC_VAR_32BIT)
   #undef      CANSM_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (CANSM_START_SEC_VAR_UNSPECIFIED)
   #undef      CANSM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      CANSM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (CANSM_START_SEC_VAR_FAST_BOOLEAN)
   #undef      CANSM_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (CANSM_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      CANSM_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (CANSM_START_SEC_VAR_FAST_8BIT)
   #undef      CANSM_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (CANSM_STOP_SEC_VAR_FAST_8BIT)
   #undef      CANSM_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (CANSM_START_SEC_VAR_FAST_16BIT)
   #undef      CANSM_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (CANSM_STOP_SEC_VAR_FAST_16BIT)
   #undef      CANSM_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (CANSM_START_SEC_VAR_FAST_32BIT)
   #undef      CANSM_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (CANSM_STOP_SEC_VAR_FAST_32BIT)
   #undef      CANSM_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (CANSM_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      CANSM_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (CANSM_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      CANSM_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (CANSM_START_CONFIG_DATA_BOOLEAN)
   #undef      CANSM_START_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (CANSM_STOP_CONFIG_DATA_BOOLEAN)
   #undef      CANSM_STOP_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (CANSM_START_CONFIG_DATA_8BIT)
   #undef      CANSM_START_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (CANSM_STOP_CONFIG_DATA_8BIT)
   #undef      CANSM_STOP_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (CANSM_START_CONFIG_DATA_16BIT)
   #undef      CANSM_START_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (CANSM_STOP_CONFIG_DATA_16BIT)
   #undef      CANSM_STOP_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (CANSM_START_CONFIG_DATA_32BIT)
   #undef      CANSM_START_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (CANSM_STOP_CONFIG_DATA_32BIT)
   #undef      CANSM_STOP_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (CANSM_START_CONFIG_DATA_UNSPECIFIED)
   #undef      CANSM_START_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (CANSM_STOP_CONFIG_DATA_UNSPECIFIED)
   #undef      CANSM_STOP_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             CANNM (CAN Network Manager)                                    */
/* -------------------------------------------------------------------------- */
#elif defined (CANNM_START_SEC_CODE)
   #undef      CANNM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CANNM_STOP_SEC_CODE)
   #undef      CANNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (CANNM_START_SEC_VAR_BOOLEAN)
   #undef      CANNM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (CANNM_STOP_SEC_VAR_BOOLEAN)
   #undef      CANNM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (CANNM_START_SEC_VAR_8BIT)
   #undef      CANNM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (CANNM_STOP_SEC_VAR_8BIT)
   #undef      CANNM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (CANNM_START_SEC_VAR_16BIT)
   #undef      CANNM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (CANNM_STOP_SEC_VAR_16BIT)
   #undef      CANNM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (CANNM_START_SEC_VAR_32BIT)
   #undef      CANNM_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (CANNM_STOP_SEC_VAR_32BIT)
   #undef      CANNM_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (CANNM_START_SEC_VAR_UNSPECIFIED)
   #undef      CANNM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (CANNM_START_SEC_CONST_BOOLEAN)
   #undef      CANNM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (CANNM_STOP_SEC_CONST_BOOLEAN)
   #undef      CANNM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (CANNM_START_SEC_CONST_8BIT)
   #undef      CANNM_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (CANNM_STOP_SEC_CONST_8BIT)
   #undef      CANNM_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (CANNM_START_SEC_CONST_16BIT)
   #undef      CANNM_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (CANNM_STOP_SEC_CONST_16BIT)
   #undef      CANNM_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (CANNM_START_SEC_CONST_32BIT)
   #undef      CANNM_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (CANNM_STOP_SEC_CONST_32BIT)
   #undef      CANNM_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (CANNM_START_SEC_CONST_UNSPECIFIED)
   #undef      CANNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (CANNM_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      CANNM_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (CANNM_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      CANNM_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (CANNM_START_SEC_CONFIG_DATA_8BIT)
   #undef      CANNM_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (CANNM_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      CANNM_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (CANNM_START_SEC_CONFIG_DATA_16BIT)
   #undef      CANNM_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (CANNM_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      CANNM_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (CANNM_START_SEC_CONFIG_DATA_32BIT)
   #undef      CANNM_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (CANNM_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      CANNM_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (CANNM_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      CANNM_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (CANNM_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      CANNM_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (CANNM_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      CANNM_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (CANNM_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      CANNM_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (CANNM_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      CANNM_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (CANNM_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      CANNM_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (CANNM_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      CANNM_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (CANNM_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      CANNM_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (CANNM_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      CANNM_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (CANNM_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      CANNM_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (CANNM_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      CANNM_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (CANNM_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      CANNM_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (CANNM_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      CANNM_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (CANNM_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      CANNM_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (CANNM_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      CANNM_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (CANNM_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      CANNM_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (CANNM_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      CANNM_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (CANNM_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      CANNM_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (CANNM_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      CANNM_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (CANNM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      CANNM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             CANTP (CAN Transport  Protocol)                                */
/* -------------------------------------------------------------------------- */
/*
 * CANTP (CAN Transport Layer)
 */

/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (CANTP_START_SEC_CODE)
   #undef      CANTP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (CANTP_STOP_SEC_CODE)
   #undef      CANTP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (CANTP_START_SEC_VAR_BOOLEAN)
   #undef      CANTP_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (CANTP_STOP_SEC_VAR_BOOLEAN)
   #undef      CANTP_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (CANTP_START_SEC_VAR_8BIT)
   #undef      CANTP_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (CANTP_STOP_SEC_VAR_8BIT)
   #undef      CANTP_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (CANTP_START_SEC_VAR_16BIT)
   #undef      CANTP_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (CANTP_STOP_SEC_VAR_16BIT)
   #undef      CANTP_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (CANTP_START_SEC_VAR_32BIT)
   #undef      CANTP_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (CANTP_STOP_SEC_VAR_32BIT)
   #undef      CANTP_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (CANTP_START_SEC_VAR_UNSPECIFIED)
   #undef      CANTP_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_VAR_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (CANTP_START_SEC_VAR_FAST_BOOLEAN)
   #undef      CANTP_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (CANTP_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      CANTP_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (CANTP_START_SEC_VAR_FAST_8BIT)
   #undef      CANTP_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (CANTP_STOP_SEC_VAR_FAST_8BIT)
   #undef      CANTP_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (CANTP_START_SEC_VAR_FAST_16BIT)
   #undef      CANTP_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (CANTP_STOP_SEC_VAR_FAST_16BIT)
   #undef      CANTP_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (CANTP_START_SEC_VAR_FAST_32BIT)
   #undef      CANTP_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (CANTP_STOP_SEC_VAR_FAST_32BIT)
   #undef      CANTP_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (CANTP_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      CANTP_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (CANTP_START_SEC_CONST_BOOLEAN)
   #undef      CANTP_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (CANTP_STOP_SEC_CONST_BOOLEAN)
   #undef      CANTP_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (CANTP_START_SEC_CONST_8BIT)
   #undef      CANTP_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (CANTP_STOP_SEC_CONST_8BIT)
   #undef      CANTP_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (CANTP_START_SEC_CONST_16BIT)
   #undef      CANTP_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (CANTP_STOP_SEC_CONST_16BIT)
   #undef      CANTP_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (CANTP_START_SEC_CONST_32BIT)
   #undef      CANTP_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (CANTP_STOP_SEC_CONST_32BIT)
   #undef      CANTP_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (CANTP_START_SEC_CONST_UNSPECIFIED)
   #undef      CANTP_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_CONST_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (CANTP_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      CANTP_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (CANTP_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      CANTP_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (CANTP_START_SEC_CONFIG_DATA_8BIT)
   #undef      CANTP_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (CANTP_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      CANTP_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (CANTP_START_SEC_CONFIG_DATA_16BIT)
   #undef      CANTP_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (CANTP_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      CANTP_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (CANTP_START_SEC_CONFIG_DATA_32BIT)
   #undef      CANTP_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (CANTP_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      CANTP_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (CANTP_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      CANTP_START_SEC_CONFIG_VAR_UNSPECIFIED
  #define  DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      CANTP_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED
  
#elif defined (CANTP_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      CANTP_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED


/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */

#elif defined (CANTP_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      CANTP_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (CANTP_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      CANTP_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (CANTP_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      CANTP_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED


/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (CANTP_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      CANTP_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (CANTP_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      CANTP_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (CANTP_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      CANTP_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (CANTP_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      CANTP_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             CANTRCV (CAN Tranceiver Driver)                                */
/* -------------------------------------------------------------------------- */
#elif defined (CANTRCV_START_SEC_VAR_8BIT)
  #undef      CANTRCV_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (CANTRCV_STOP_SEC_VAR_8BIT)
  #undef      CANTRCV_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (CANTRCV_START_SEC_VAR_FAST_8BIT)
  #undef      CANTRCV_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (CANTRCV_STOP_SEC_VAR_FAST_8BIT)
  #undef      CANTRCV_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (CANTRCV_START_SEC_VAR_16BIT)
  #undef      CANTRCV_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (CANTRCV_STOP_SEC_VAR_16BIT)
  #undef      CANTRCV_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (CANTRCV_START_SEC_VAR_32BIT)
  #undef      CANTRCV_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (CANTRCV_STOP_SEC_VAR_32BIT)
  #undef      CANTRCV_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (CANTRCV_START_SEC_VAR_UNSPECIFIED)
  #undef      CANTRCV_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CANTRCV_STOP_SEC_VAR_UNSPECIFIED)
  #undef      CANTRCV_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (CANTRCV_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      CANTRCV_START_SEC_CONFIG_VAR_UNSPECIFIED
   /*#pragma ghs section sbss=".CANTRCV_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (CANTRCV_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      CANTRCV_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (CANTRCV_START_SEC_CONST_8BIT)
  #undef      CANTRCV_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (CANTRCV_STOP_SEC_CONST_8BIT)
  #undef      CANTRCV_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (CANTRCV_START_SEC_CONST_16BIT)
  #undef      CANTRCV_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (CANTRCV_STOP_SEC_CONST_16BIT)
  #undef      CANTRCV_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (CANTRCV_START_SEC_CONST_32BIT)
  #undef      CANTRCV_START_SEC_CONST_32BIT
  #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (CANTRCV_STOP_SEC_CONST_32BIT)
  #undef      CANTRCV_STOP_SEC_CONST_32BIT
  #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (CANTRCV_START_SEC_CONST_UNSPECIFIED)
  #undef      CANTRCV_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CANTRCV_STOP_SEC_CONST_UNSPECIFIED)
  #undef      CANTRCV_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      CANTRCV_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".CANTRCV_CFG_CONST_ROM_UNSPEC"*/
#elif defined (CANTRCV_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      CANTRCV_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CANTRCV_START_SEC_PUBLIC_CODE)
  #undef      CANTRCV_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".CANTRCV_PUBLIC_CODE_ROM"*/
#elif defined (CANTRCV_STOP_SEC_PUBLIC_CODE)
  #undef      CANTRCV_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (CANTRCV_START_SEC_PRIVATE_CODE)
  #undef      CANTRCV_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".CANTRCV_PRIVATE_CODE_ROM"*/
#elif defined (CANTRCV_STOP_SEC_PRIVATE_CODE)
  #undef      CANTRCV_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (CANTRCV_START_SEC_CODE_SLOW)
  #undef      CANTRCV_START_SEC_CODE_SLOW
  #define     DEFAULT_START_SEC_CODE
   /*#pragma ghs section text=".CANTRCV_PRIVATE_CODE_ROM"*/
#elif defined (CANTRCV_STOP_SEC_CODE_SLOW)
  #undef      CANTRCV_STOP_SEC_CODE_SLOW
  #define DEFAULT_STOP_SEC_CODE

#elif defined (CANTRCV_START_SEC_CODE_FAST_2)
  #undef      CANTRCV_START_SEC_CODE_FAST_2
  #define     DEFAULT_START_SEC_CODE
   /*#pragma ghs section text=".CANTRCV_PRIVATE_CODE_ROM"*/
#elif defined (CANTRCV_STOP_SEC_CODE_FAST_2)
  #undef      CANTRCV_STOP_SEC_CODE_FAST_2
  #define DEFAULT_STOP_SEC_CODE

#elif defined (CANTRCV_START_SEC_CODE_FAST_1)
  #undef      CANTRCV_START_SEC_CODE_FAST_1
  #define     DEFAULT_START_SEC_CODE
   /*#pragma ghs section text=".CANTRCV_PRIVATE_CODE_ROM"*/
#elif defined (CANTRCV_STOP_SEC_CODE_FAST_1)
  #undef      CANTRCV_STOP_SEC_CODE_FAST_1
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             LINTRCV (LIN Tranceiver Driver)                                */
/* -------------------------------------------------------------------------- */
#elif defined (LINTRCV_START_SEC_VAR_8BIT)
  #undef      LINTRCV_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (LINTRCV_STOP_SEC_VAR_8BIT)
  #undef      LINTRCV_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (LINTRCV_START_SEC_VAR_FAST_8BIT)
  #undef      LINTRCV_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (LINTRCV_STOP_SEC_VAR_FAST_8BIT)
  #undef      LINTRCV_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (LINTRCV_START_SEC_VAR_16BIT)
  #undef      LINTRCV_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (LINTRCV_STOP_SEC_VAR_16BIT)
  #undef      LINTRCV_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (LINTRCV_START_SEC_VAR_32BIT)
  #undef      LINTRCV_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (LINTRCV_STOP_SEC_VAR_32BIT)
  #undef      LINTRCV_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (LINTRCV_START_SEC_VAR_UNSPECIFIED)
  #undef      LINTRCV_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (LINTRCV_STOP_SEC_VAR_UNSPECIFIED)
  #undef      LINTRCV_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (LINTRCV_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      LINTRCV_START_SEC_CONFIG_VAR_UNSPECIFIED
   /*#pragma ghs section sbss=".LINTRCV_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (LINTRCV_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      LINTRCV_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (LINTRCV_START_SEC_CONST_8BIT)
  #undef      LINTRCV_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (LINTRCV_STOP_SEC_CONST_8BIT)
  #undef      LINTRCV_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (LINTRCV_START_SEC_CONST_16BIT)
  #undef      LINTRCV_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (LINTRCV_STOP_SEC_CONST_16BIT)
  #undef      LINTRCV_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (LINTRCV_START_SEC_CONST_UNSPECIFIED)
  #undef      LINTRCV_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINTRCV_STOP_SEC_CONST_UNSPECIFIED)
  #undef      LINTRCV_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINTRCV_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      LINTRCV_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".LINTRCV_CFG_CONST_ROM_UNSPEC"*/
#elif defined (LINTRCV_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      LINTRCV_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINTRCV_START_SEC_PUBLIC_CODE)
  #undef      LINTRCV_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".LINTRCV_PUBLIC_CODE_ROM"*/
#elif defined (LINTRCV_STOP_SEC_PUBLIC_CODE)
  #undef      LINTRCV_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (LINTRCV_START_SEC_PRIVATE_CODE)
  #undef      LINTRCV_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".LINTRCV_PRIVATE_CODE_ROM"*/
#elif defined (LINTRCV_STOP_SEC_PRIVATE_CODE)
  #undef      LINTRCV_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (LINTRCV_START_SEC_CODE_SLOW)
  #undef      LINTRCV_START_SEC_CODE_SLOW
  #define     DEFAULT_START_SEC_CODE
   /*#pragma ghs section text=".LINTRCV_PRIVATE_CODE_ROM"*/
#elif defined (LINTRCV_STOP_SEC_CODE_SLOW)
  #undef      LINTRCV_STOP_SEC_CODE_SLOW
  #define DEFAULT_STOP_SEC_CODE
  
#elif defined (LINTRCV_START_SEC_CODE_FAST)
  #undef      LINTRCV_START_SEC_CODE_FAST
  #define     DEFAULT_START_SEC_CODE
   /*#pragma ghs section text=".LINTRCV_PRIVATE_CODE_ROM"*/
#elif defined (LINTRCV_STOP_SEC_CODE_FAST)
  #undef      LINTRCV_STOP_SEC_CODE_FAST
  #define DEFAULT_STOP_SEC_CODE

#elif defined (LINTRCV_START_CONFIG_DATA_UNSPECIFIED)
  #undef      LINTRCV_START_CONFIG_DATA_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (LINTRCV_STOP_CONFIG_DATA_UNSPECIFIED)
  #undef      LINTRCV_STOP_CONFIG_DATA_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED
  
#elif defined (LINTRCV_START_CONFIG_DATA_32BIT)
  #undef      LINTRCV_START_CONFIG_DATA_32BIT
  #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (LINTRCV_STOP_CONFIG_DATA_32BIT)
  #undef      LINTRCV_STOP_CONFIG_DATA_32BIT
  #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT
  
/* -------------------------------------------------------------------------- */
/*             COMM (Communication Manager)                                   */
/* -------------------------------------------------------------------------- */

#elif defined (COMM_START_SEC_CODE)
  #undef      COMM_START_SEC_CODE
  #define DEFAULT_START_SEC_CODE
#elif defined (COMM_STOP_SEC_CODE)
  #undef      COMM_STOP_SEC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (COMM_START_SEC_VAR_8BIT)
  #undef      COMM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (COMM_STOP_SEC_VAR_8BIT)
  #undef      COMM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (COMM_START_SEC_VAR_16BIT)
  #undef      COMM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (COMM_STOP_SEC_VAR_16BIT)
  #undef      COMM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (COMM_START_SEC_VAR_32BIT)
  #undef      COMM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (COMM_STOP_SEC_VAR_32BIT)
  #undef      COMM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (COMM_START_SEC_VAR_UNSPECIFIED)
  #undef      COMM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (COMM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      COMM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (COMM_START_SEC_CONST_8BIT)
  #undef      COMM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (COMM_STOP_SEC_CONST_8BIT)
  #undef      COMM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (COMM_START_SEC_CONST_16BIT)
  #undef      COMM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (COMM_STOP_SEC_CONST_16BIT)
  #undef      COMM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (COMM_START_SEC_CONST_32BIT)
  #undef      COMM_START_SEC_CONST_32BIT
  #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (COMM_STOP_SEC_CONST_32BIT)
  #undef      COMM_STOP_SEC_CONST_32BIT
  #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (COMM_START_SEC_CONST_UNSPECIFIED)
  #undef      COMM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (COMM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      COMM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (COMM_START_SEC_CONFIG_DATA_8BIT)
  #undef      COMM_START_SEC_CONFIG_DATA_8BIT
  #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (COMM_STOP_SEC_CONFIG_DATA_8BIT)
  #undef      COMM_STOP_SEC_CONFIG_DATA_8BIT
  #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (COMM_START_SEC_CONFIG_DATA_16BIT)
  #undef      COMM_START_SEC_CONFIG_DATA_16BIT
  #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (COMM_STOP_SEC_CONFIG_DATA_16BIT)
  #undef      COMM_STOP_SEC_CONFIG_DATA_16BIT
  #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (COMM_START_SEC_CONFIG_DATA_32BIT)
  #undef      COMM_START_SEC_CONFIG_DATA_32BIT
  #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (COMM_STOP_SEC_CONFIG_DATA_32BIT)
  #undef      COMM_STOP_SEC_CONFIG_DATA_32BIT
  #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (COMM_START_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      COMM_START_SEC_CONFIG_DATA_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (COMM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      COMM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             CRC (CRC Library)                                              */
/* -------------------------------------------------------------------------- */
#elif defined (CRC_START_SEC_VAR_8BIT)
  #undef      CRC_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (CRC_STOP_SEC_VAR_8BIT)
  #undef      CRC_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (CRC_START_SEC_VAR_FAST_8BIT)
  #undef      CRC_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (CRC_STOP_SEC_VAR_FAST_8BIT)
  #undef      CRC_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (CRC_START_SEC_VAR_16BIT)
  #undef      CRC_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (CRC_STOP_SEC_VAR_16BIT)
  #undef      CRC_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (CRC_START_SEC_VAR_32BIT)
  #undef      CRC_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (CRC_STOP_SEC_VAR_32BIT)
  #undef      CRC_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (CRC_START_SEC_VAR_UNSPECIFIED)
  #undef      CRC_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (CRC_STOP_SEC_VAR_UNSPECIFIED)
  #undef      CRC_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (CRC_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      CRC_START_SEC_CONFIG_VAR_UNSPECIFIED
   /*#pragma ghs section sbss=".CRC_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (CRC_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      CRC_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (CRC_START_SEC_CONST_8BIT)
  #undef      CRC_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (CRC_STOP_SEC_CONST_8BIT)
  #undef      CRC_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (CRC_START_SEC_CONST_16BIT)
  #undef      CRC_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (CRC_STOP_SEC_CONST_16BIT)
  #undef      CRC_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (CRC_START_SEC_CONST_32BIT)
  #undef      CRC_START_SEC_CONST_32BIT
  #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (CRC_STOP_SEC_CONST_32BIT)
  #undef      CRC_STOP_SEC_CONST_32BIT
  #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (CRC_START_SEC_CONST_UNSPECIFIED)
  #undef      CRC_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (CRC_STOP_SEC_CONST_UNSPECIFIED)
  #undef      CRC_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CRC_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      CRC_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".CRC_CFG_CONST_ROM_UNSPEC"*/
#elif defined (CRC_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      CRC_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (CRC_START_SEC_PUBLIC_CODE)
  #undef      CRC_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".CRC_PUBLIC_CODE_ROM"*/
#elif defined (CRC_STOP_SEC_PUBLIC_CODE)
  #undef      CRC_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (CRC_START_SEC_PRIVATE_CODE)
  #undef      CRC_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".CRC_PRIVATE_CODE_ROM"*/
#elif defined (CRC_STOP_SEC_PRIVATE_CODE)
  #undef      CRC_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             DCM (Diagonostic Communication Manager)                        */
/* -------------------------------------------------------------------------- */
#elif defined (DCM_START_SEC_VAR_8BIT)
  #undef      DCM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (DCM_STOP_SEC_VAR_8BIT)
  #undef      DCM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (DCM_START_SEC_VAR_FAST_8BIT)
  #undef      DCM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (DCM_STOP_SEC_VAR_FAST_8BIT)
  #undef      DCM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (DCM_START_SEC_VAR_16BIT)
  #undef      DCM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (DCM_STOP_SEC_VAR_16BIT)
  #undef      DCM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (DCM_START_SEC_VAR_32BIT)
  #undef      DCM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (DCM_STOP_SEC_VAR_32BIT)
  #undef      DCM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (DCM_START_SEC_VAR_UNSPECIFIED)
  #undef      DCM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (DCM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      DCM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DCM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      DCM_START_SEC_CONFIG_VAR_UNSPECIFIED
   /*#pragma ghs section sbss=".DCM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (DCM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      DCM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DCM_START_SEC_CONST_8BIT)
  #undef      DCM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (DCM_STOP_SEC_CONST_8BIT)
  #undef      DCM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (DCM_START_SEC_CONST_16BIT)
  #undef      DCM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (DCM_STOP_SEC_CONST_16BIT)
  #undef      DCM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (DCM_START_SEC_CONST_UNSPECIFIED)
  #undef      DCM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DCM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      DCM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DCM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      DCM_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".DCM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (DCM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      DCM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DCM_START_SEC_PUBLIC_CODE)
  #undef      DCM_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".DCM_PUBLIC_CODE_ROM"*/
#elif defined (DCM_STOP_SEC_PUBLIC_CODE)
  #undef      DCM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (DCM_START_SEC_PRIVATE_CODE)
  #undef      DCM_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".DCM_PRIVATE_CODE_ROM"*/
#elif defined (DCM_STOP_SEC_PRIVATE_CODE)
  #undef      DCM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             DEM (Diagonostic Event Manager)                                */
/* -------------------------------------------------------------------------- */
#elif defined (DEM_START_SEC_VAR_8BIT)
  #undef      DEM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (DEM_STOP_SEC_VAR_8BIT)
  #undef      DEM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (DEM_START_SEC_VAR_FAST_8BIT)
  #undef      DEM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (DEM_STOP_SEC_VAR_FAST_8BIT)
  #undef      DEM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (DEM_START_SEC_VAR_16BIT)
  #undef      DEM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (DEM_STOP_SEC_VAR_16BIT)
  #undef      DEM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (DEM_START_SEC_VAR_32BIT)
  #undef      DEM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (DEM_STOP_SEC_VAR_32BIT)
  #undef      DEM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (DEM_START_SEC_VAR_UNSPECIFIED)
  #undef      DEM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (DEM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      DEM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DEM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      DEM_START_SEC_CONFIG_VAR_UNSPECIFIED
   /*#pragma ghs section sbss=".DEM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (DEM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      DEM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DEM_START_SEC_CONST_8BIT)
  #undef      DEM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (DEM_STOP_SEC_CONST_8BIT)
  #undef      DEM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (DEM_START_SEC_CONST_16BIT)
  #undef      DEM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (DEM_STOP_SEC_CONST_16BIT)
  #undef      DEM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (DEM_START_SEC_CONST_UNSPECIFIED)
  #undef      DEM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DEM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      DEM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DEM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      DEM_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".DEM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (DEM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      DEM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DEM_START_SEC_PUBLIC_CODE)
  #undef      DEM_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".DEM_PUBLIC_CODE_ROM"*/
#elif defined (DEM_STOP_SEC_PUBLIC_CODE)
  #undef      DEM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (DEM_START_SEC_PRIVATE_CODE)
  #undef      DEM_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".DEM_PRIVATE_CODE_ROM"*/
#elif defined (DEM_STOP_SEC_PRIVATE_CODE)
  #undef      DEM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             DET (Development Error Tracer)                                 */
/* -------------------------------------------------------------------------- */
#elif defined (DET_START_SEC_VAR_8BIT)
  #undef      DET_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (DET_STOP_SEC_VAR_8BIT)
  #undef      DET_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (DET_START_SEC_VAR_FAST_8BIT)
  #undef      DET_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (DET_STOP_SEC_VAR_FAST_8BIT)
  #undef      DET_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (DET_START_SEC_VAR_16BIT)
  #undef      DET_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (DET_STOP_SEC_VAR_16BIT)
  #undef      DET_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (DET_START_SEC_VAR_32BIT)
  #undef      DET_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (DET_STOP_SEC_VAR_32BIT)
  #undef      DET_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (DET_START_SEC_VAR_UNSPECIFIED)
  #undef      DET_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (DET_STOP_SEC_VAR_UNSPECIFIED)
  #undef      DET_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DET_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      DET_START_SEC_CONFIG_VAR_UNSPECIFIED
   /*#pragma ghs section sbss=".DET_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (DET_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      DET_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (DET_START_SEC_CONST_8BIT)
  #undef      DET_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (DET_STOP_SEC_CONST_8BIT)
  #undef      DET_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (DET_START_SEC_CONST_16BIT)
  #undef      DET_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (DET_STOP_SEC_CONST_16BIT)
  #undef      DET_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (DET_START_SEC_CONST_UNSPECIFIED)
  #undef      DET_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (DET_STOP_SEC_CONST_UNSPECIFIED)
  #undef      DET_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DET_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      DET_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".DET_CFG_CONST_ROM_UNSPEC"*/
#elif defined (DET_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      DET_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (DET_START_SEC_PUBLIC_CODE)
  #undef      DET_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".DET_PUBLIC_CODE_ROM"*/
#elif defined (DET_STOP_SEC_PUBLIC_CODE)
  #undef      DET_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (DET_START_SEC_PRIVATE_CODE)
  #undef      DET_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".DET_PRIVATE_CODE_ROM"*/
#elif defined (DET_STOP_SEC_PRIVATE_CODE)
  #undef      DET_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             EA (EEPROM Abstraction)                                        */
/* -------------------------------------------------------------------------- */
#elif defined (EA_START_SEC_VAR_8BIT)
  #undef      EA_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (EA_STOP_SEC_VAR_8BIT)
  #undef      EA_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (EA_START_SEC_VAR_FAST_8BIT)
  #undef      EA_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (EA_STOP_SEC_VAR_FAST_8BIT)
  #undef      EA_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (EA_START_SEC_VAR_16BIT)
  #undef      EA_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (EA_STOP_SEC_VAR_16BIT)
  #undef      EA_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (EA_START_SEC_VAR_32BIT)
  #undef      EA_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (EA_STOP_SEC_VAR_32BIT)
  #undef      EA_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (EA_START_SEC_VAR_UNSPECIFIED)
  #undef      EA_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (EA_STOP_SEC_VAR_UNSPECIFIED)
  #undef      EA_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (EA_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      EA_START_SEC_CONFIG_VAR_UNSPECIFIED
   /*#pragma ghs section sbss=".EA_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (EA_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      EA_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (EA_START_SEC_CONST_8BIT)
  #undef      EA_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (EA_STOP_SEC_CONST_8BIT)
  #undef      EA_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (EA_START_SEC_CONST_16BIT)
  #undef      EA_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (EA_STOP_SEC_CONST_16BIT)
  #undef      EA_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (EA_START_SEC_CONST_UNSPECIFIED)
  #undef      EA_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (EA_STOP_SEC_CONST_UNSPECIFIED)
  #undef      EA_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (EA_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      EA_START_SEC_CONFIG_CONST_UNSPECIFIED
   /*#pragma ghs section rosdata=".EA_CFG_CONST_ROM_UNSPEC"*/
#elif defined (EA_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      EA_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (EA_START_SEC_PUBLIC_CODE)
  #undef      EA_START_SEC_PUBLIC_CODE
   /*#pragma ghs section text=".EA_PUBLIC_CODE_ROM"*/
#elif defined (EA_STOP_SEC_PUBLIC_CODE)
  #undef      EA_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (EA_START_SEC_PRIVATE_CODE)
  #undef      EA_START_SEC_PRIVATE_CODE
   /*#pragma ghs section text=".EA_PRIVATE_CODE_ROM"*/
#elif defined (EA_STOP_SEC_PRIVATE_CODE)
  #undef      EA_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             ECUM (ECU State Manager)                                       */
/* -------------------------------------------------------------------------- */
#elif defined (ECUM_START_SEC_VAR_8BIT)
  #undef      ECUM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (ECUM_STOP_SEC_VAR_8BIT)
  #undef      ECUM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (ECUM_START_SEC_VAR_FAST_8BIT)
  #undef      ECUM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (ECUM_STOP_SEC_VAR_FAST_8BIT)
  #undef      ECUM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (ECUM_START_SEC_VAR_16BIT)
  #undef      ECUM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (ECUM_STOP_SEC_VAR_16BIT)
  #undef      ECUM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (ECUM_START_SEC_VAR_32BIT)
  #undef      ECUM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (ECUM_STOP_SEC_VAR_32BIT)
  #undef      ECUM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (ECUM_START_SEC_VAR_UNSPECIFIED)
  #undef      ECUM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      ECUM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (ECUM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      ECUM_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".ECUM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (ECUM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      ECUM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (ECUM_START_SEC_CONST_8BIT)
  #undef      ECUM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (ECUM_STOP_SEC_CONST_8BIT)
  #undef      ECUM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (ECUM_START_SEC_CONST_16BIT)
  #undef      ECUM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (ECUM_STOP_SEC_CONST_16BIT)
  #undef      ECUM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (ECUM_START_SEC_CONST_UNSPECIFIED)
  #undef      ECUM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (ECUM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      ECUM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (ECUM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      ECUM_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".ECUM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (ECUM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      ECUM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (ECUM_START_SEC_PUBLIC_CODE)
  #undef      ECUM_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".ECUM_PUBLIC_CODE_ROM"*/
#elif defined (ECUM_STOP_SEC_PUBLIC_CODE)
  #undef      ECUM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (ECUM_START_SEC_PRIVATE_CODE)
  #undef      ECUM_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".ECUM_PRIVATE_CODE_ROM"*/
#elif defined (ECUM_STOP_SEC_PRIVATE_CODE)
  #undef      ECUM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             EEP (External EEPROM Driver)                                   */
/* -------------------------------------------------------------------------- */
#elif defined (EEP_START_SEC_VAR_8BIT)
  #undef      EEP_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (EEP_STOP_SEC_VAR_8BIT)
  #undef      EEP_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (EEP_START_SEC_VAR_FAST_8BIT)
  #undef      EEP_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (EEP_STOP_SEC_VAR_FAST_8BIT)
  #undef      EEP_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (EEP_START_SEC_VAR_16BIT)
  #undef      EEP_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (EEP_STOP_SEC_VAR_16BIT)
  #undef      EEP_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (EEP_START_SEC_VAR_32BIT)
  #undef      EEP_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (EEP_STOP_SEC_VAR_32BIT)
  #undef      EEP_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (EEP_START_SEC_VAR_UNSPECIFIED)
  #undef      EEP_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (EEP_STOP_SEC_VAR_UNSPECIFIED)
  #undef      EEP_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (EEP_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      EEP_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".EEP_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (EEP_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      EEP_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (EEP_START_SEC_CONST_8BIT)
  #undef      EEP_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (EEP_STOP_SEC_CONST_8BIT)
  #undef      EEP_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (EEP_START_SEC_CONST_16BIT)
  #undef      EEP_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (EEP_STOP_SEC_CONST_16BIT)
  #undef      EEP_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (EEP_START_SEC_CONST_UNSPECIFIED)
  #undef      EEP_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (EEP_STOP_SEC_CONST_UNSPECIFIED)
  #undef      EEP_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (EEP_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      EEP_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".EEP_CFG_CONST_ROM_UNSPEC"*/
#elif defined (EEP_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      EEP_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (EEP_START_SEC_PUBLIC_CODE)
  #undef      EEP_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".EEP_PUBLIC_CODE_ROM"*/
#elif defined (EEP_STOP_SEC_PUBLIC_CODE)
  #undef      EEP_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (EEP_START_SEC_PRIVATE_CODE)
  #undef      EEP_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".EEP_PRIVATE_CODE_ROM"*/
#elif defined (EEP_STOP_SEC_PRIVATE_CODE)
  #undef      EEP_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*             FEE (Flash EEPROM Emulation)                                   */
/* -------------------------------------------------------------------------- */
#elif defined (FEE_START_SEC_VAR_8BIT)
  #undef      FEE_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FEE_STOP_SEC_VAR_8BIT)
  #undef      FEE_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (FEE_START_SEC_VAR_FAST_8BIT)
  #undef      FEE_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (FEE_STOP_SEC_VAR_FAST_8BIT)
  #undef      FEE_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (FEE_START_SEC_VAR_16BIT)
  #undef      FEE_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (FEE_STOP_SEC_VAR_16BIT)
  #undef      FEE_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (FEE_START_SEC_VAR_32BIT)
  #undef      FEE_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (FEE_STOP_SEC_VAR_32BIT)
  #undef      FEE_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (FEE_START_SEC_VAR_UNSPECIFIED)
  #undef      FEE_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FEE_STOP_SEC_VAR_UNSPECIFIED)
  #undef      FEE_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (FEE_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      FEE_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".FEE_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (FEE_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      FEE_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (FEE_START_SEC_CONST_8BIT)
  #undef      FEE_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (FEE_STOP_SEC_CONST_8BIT)
  #undef      FEE_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (FEE_START_SEC_CONST_16BIT)
  #undef      FEE_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (FEE_STOP_SEC_CONST_16BIT)
  #undef      FEE_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (FEE_START_SEC_CONST_UNSPECIFIED)
  #undef      FEE_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FEE_STOP_SEC_CONST_UNSPECIFIED)
  #undef      FEE_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FEE_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      FEE_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".FEE_CFG_CONST_ROM_UNSPEC"*/
#elif defined (FEE_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      FEE_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FEE_START_SEC_PUBLIC_CODE)
  #undef      FEE_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".FEE_PUBLIC_CODE_ROM"*/
#elif defined (FEE_STOP_SEC_PUBLIC_CODE)
  #undef      FEE_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (FEE_START_SEC_PRIVATE_CODE)
  #undef      FEE_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".FEE_PRIVATE_CODE_ROM"*/
#elif defined (FEE_STOP_SEC_PRIVATE_CODE)
  #undef      FEE_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             FIM (Function Inhibition Manager)                              */
/* -------------------------------------------------------------------------- */
#elif defined (FIM_START_SEC_VAR_8BIT)
  #undef      FIM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FIM_STOP_SEC_VAR_8BIT)
  #undef      FIM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (FIM_START_SEC_VAR_FAST_8BIT)
  #undef      FIM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (FIM_STOP_SEC_VAR_FAST_8BIT)
  #undef      FIM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (FIM_START_SEC_VAR_16BIT)
  #undef      FIM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (FIM_STOP_SEC_VAR_16BIT)
  #undef      FIM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (FIM_START_SEC_VAR_32BIT)
  #undef      FIM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (FIM_STOP_SEC_VAR_32BIT)
  #undef      FIM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (FIM_START_SEC_VAR_UNSPECIFIED)
  #undef      FIM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FIM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      FIM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (FIM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      FIM_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".FIM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (FIM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      FIM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (FIM_START_SEC_CONST_8BIT)
  #undef      FIM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (FIM_STOP_SEC_CONST_8BIT)
  #undef      FIM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (FIM_START_SEC_CONST_16BIT)
  #undef      FIM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (FIM_STOP_SEC_CONST_16BIT)
  #undef      FIM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (FIM_START_SEC_CONST_UNSPECIFIED)
  #undef      FIM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FIM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      FIM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FIM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      FIM_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".FIM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (FIM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      FIM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FIM_START_SEC_PUBLIC_CODE)
  #undef      FIM_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".FIM_PUBLIC_CODE_ROM"*/
#elif defined (FIM_STOP_SEC_PUBLIC_CODE)
  #undef      FIM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (FIM_START_SEC_PRIVATE_CODE)
  #undef      FIM_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".FIM_PRIVATE_CODE_ROM"*/
#elif defined (FIM_STOP_SEC_PRIVATE_CODE)
  #undef      FIM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (FIM_START_SEC_CONST_POSTBUILD)
  #undef      FIM_START_SEC_CONST_POSTBUILD
  #define DEFAULT_START_SEC_CONST_POSTBUILD
#elif defined (FIM_STOP_SEC_CONST_POSTBUILD)
  #undef      FIM_STOP_SEC_CONST_POSTBUILD
  #define DEFAULT_STOP_SEC_CONST_POSTBUILD

 
/* -------------------------------------------------------------------------- */
/*             FRIF (Flexray Interface)                                       */
/* -------------------------------------------------------------------------- */
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (FRIF_START_SEC_CODE)
   #undef      FRIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRIF_STOP_SEC_CODE)
   #undef      FRIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE 

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (FRIF_START_SEC_VAR_BOOLEAN)
   #undef      FRIF_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (FRIF_STOP_SEC_VAR_BOOLEAN)
   #undef      FRIF_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (FRIF_START_SEC_VAR_8BIT)
   #undef      FRIF_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FRIF_STOP_SEC_VAR_8BIT)
   #undef      FRIF_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (FRIF_START_SEC_VAR_16BIT)
   #undef      FRIF_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (FRIF_STOP_SEC_VAR_16BIT)
   #undef      FRIF_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (FRIF_START_SEC_VAR_32BIT)
   #undef      FRIF_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (FRIF_STOP_SEC_VAR_32BIT)
   #undef      FRIF_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (FRIF_START_SEC_VAR_UNSPECIFIED)
   #undef      FRIF_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_VAR_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED 

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (FRIF_START_SEC_VAR_FAST_BOOLEAN)
   #undef      FRIF_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (FRIF_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      FRIF_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (FRIF_START_SEC_VAR_FAST_8BIT)
   #undef      FRIF_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (FRIF_STOP_SEC_VAR_FAST_8BIT)
   #undef      FRIF_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (FRIF_START_SEC_VAR_FAST_16BIT)
   #undef      FRIF_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (FRIF_STOP_SEC_VAR_FAST_16BIT)
   #undef      FRIF_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (FRIF_START_SEC_VAR_FAST_32BIT)
   #undef      FRIF_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (FRIF_STOP_SEC_VAR_FAST_32BIT)
   #undef      FRIF_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (FRIF_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      FRIF_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (FRIF_START_SEC_CONST_BOOLEAN)
   #undef      FRIF_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (FRIF_STOP_SEC_CONST_BOOLEAN)
   #undef      FRIF_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (FRIF_START_SEC_CONST_8BIT)
   #undef      FRIF_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (FRIF_STOP_SEC_CONST_8BIT)
   #undef      FRIF_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (FRIF_START_SEC_CONST_16BIT)
   #undef      FRIF_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (FRIF_STOP_SEC_CONST_16BIT)
   #undef      FRIF_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (FRIF_START_SEC_CONST_32BIT)
   #undef      FRIF_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (FRIF_STOP_SEC_CONST_32BIT)
   #undef      FRIF_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (FRIF_START_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (FRIF_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      FRIF_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (FRIF_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      FRIF_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (FRIF_START_SEC_CONFIG_DATA_8BIT)
   #undef      FRIF_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (FRIF_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      FRIF_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (FRIF_START_SEC_CONFIG_DATA_16BIT)
   #undef      FRIF_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (FRIF_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      FRIF_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (FRIF_START_SEC_CONFIG_DATA_32BIT)
   #undef      FRIF_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (FRIF_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      FRIF_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (FRIF_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      FRIF_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (FRIF_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      FRIF_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (FRIF_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      FRIF_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (FRIF_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      FRIF_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (FRIF_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      FRIF_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (FRIF_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      FRIF_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (FRIF_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      FRIF_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (FRIF_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      FRIF_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (FRIF_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      FRIF_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (FRIF_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      FRIF_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (FRIF_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      FRIF_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (FRIF_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      FRIF_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (FRIF_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      FRIF_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (FRIF_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      FRIF_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (FRIF_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      FRIF_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (FRIF_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      FRIF_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (FRIF_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      FRIF_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (FRIF_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      FRIF_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (FRIF_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      FRIF_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (FRIF_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      FRIF_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*             FRNM (Flexray Network Manager)                                 */
/* -------------------------------------------------------------------------- */
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (FRNM_START_SEC_CODE)
   #undef      FRNM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRNM_STOP_SEC_CODE)
   #undef      FRNM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (FRNM_START_SEC_VAR_BOOLEAN)
   #undef      FRNM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (FRNM_STOP_SEC_VAR_BOOLEAN)
   #undef      FRNM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (FRNM_START_SEC_VAR_8BIT)
   #undef      FRNM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FRNM_STOP_SEC_VAR_8BIT)
   #undef      FRNM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (FRNM_START_SEC_VAR_16BIT)
   #undef      FRNM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (FRNM_STOP_SEC_VAR_16BIT)
   #undef      FRNM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (FRNM_START_SEC_VAR_32BIT)
   #undef      FRNM_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (FRNM_STOP_SEC_VAR_32BIT)
   #undef      FRNM_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (FRNM_START_SEC_VAR_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (FRNM_START_SEC_VAR_FAST_BOOLEAN)
   #undef      FRNM_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (FRNM_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      FRNM_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (FRNM_START_SEC_VAR_FAST_8BIT)
   #undef      FRNM_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (FRNM_STOP_SEC_VAR_FAST_8BIT)
   #undef      FRNM_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (FRNM_START_SEC_VAR_FAST_16BIT)
   #undef      FRNM_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (FRNM_STOP_SEC_VAR_FAST_16BIT)
   #undef      FRNM_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (FRNM_START_SEC_VAR_FAST_32BIT)
   #undef      FRNM_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (FRNM_STOP_SEC_VAR_FAST_32BIT)
   #undef      FRNM_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (FRNM_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (FRNM_START_SEC_CONST_BOOLEAN)
   #undef      FRNM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (FRNM_STOP_SEC_CONST_BOOLEAN)
   #undef      FRNM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (FRNM_START_SEC_CONST_8BIT)
   #undef      FRNM_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (FRNM_STOP_SEC_CONST_8BIT)
   #undef      FRNM_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (FRNM_START_SEC_CONST_16BIT)
   #undef      FRNM_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (FRNM_STOP_SEC_CONST_16BIT)
   #undef      FRNM_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (FRNM_START_SEC_CONST_32BIT)
   #undef      FRNM_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (FRNM_STOP_SEC_CONST_32BIT)
   #undef      FRNM_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (FRNM_START_SEC_CONST_UNSPECIFIED)
   #undef      FRNM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (FRNM_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      FRNM_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (FRNM_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      FRNM_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (FRNM_START_SEC_CONFIG_DATA_8BIT)
   #undef      FRNM_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (FRNM_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      FRNM_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (FRNM_START_SEC_CONFIG_DATA_16BIT)
   #undef      FRNM_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (FRNM_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      FRNM_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (FRNM_START_SEC_CONFIG_DATA_32BIT)
   #undef      FRNM_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (FRNM_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      FRNM_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (FRNM_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      FRNM_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (FRNM_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      FRNM_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (FRNM_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      FRNM_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (FRNM_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      FRNM_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (FRNM_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      FRNM_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (FRNM_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      FRNM_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (FRNM_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      FRNM_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (FRNM_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      FRNM_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (FRNM_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      FRNM_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (FRNM_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      FRNM_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (FRNM_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      FRNM_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (FRNM_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      FRNM_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (FRNM_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      FRNM_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (FRNM_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      FRNM_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (FRNM_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      FRNM_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (FRNM_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      FRNM_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (FRNM_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      FRNM_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (FRNM_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      FRNM_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (FRNM_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      FRNM_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (FRNM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      FRNM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED 
   
/* -------------------------------------------------------------------------- */
/*             FRTP (Flexray Transport Protocol)                              */
/* -------------------------------------------------------------------------- */
#elif defined (FRTP_START_SEC_CODE)
   #undef      FRTP_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRTP_STOP_SEC_CODE)
   #undef      FRTP_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (FRTP_START_SEC_VAR_8BIT)
  #undef      FRTP_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FRTP_STOP_SEC_VAR_8BIT)
  #undef      FRTP_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (FRTP_START_SEC_VAR_FAST_8BIT)
  #undef      FRTP_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (FRTP_STOP_SEC_VAR_FAST_8BIT)
  #undef      FRTP_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (FRTP_START_SEC_VAR_16BIT)
  #undef      FRTP_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (FRTP_STOP_SEC_VAR_16BIT)
  #undef      FRTP_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (FRTP_START_SEC_VAR_32BIT)
  #undef      FRTP_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (FRTP_STOP_SEC_VAR_32BIT)
  #undef      FRTP_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (FRTP_START_SEC_VAR_UNSPECIFIED)
  #undef      FRTP_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_VAR_UNSPECIFIED)
  #undef      FRTP_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (FRTP_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      FRTP_START_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      FRTP_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (FRTP_START_SEC_CONST_8BIT)
  #undef      FRTP_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (FRTP_STOP_SEC_CONST_8BIT)
  #undef      FRTP_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (FRTP_START_SEC_CONST_16BIT)
  #undef      FRTP_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (FRTP_STOP_SEC_CONST_16BIT)
  #undef      FRTP_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (FRTP_START_SEC_CONST_32BIT)
  #undef      FRTP_START_SEC_CONST_32BIT
  #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (FRTP_STOP_SEC_CONST_32BIT)
  #undef      FRTP_STOP_SEC_CONST_32BIT
  #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (FRTP_START_SEC_CONST_UNSPECIFIED)
  #undef      FRTP_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_CONST_UNSPECIFIED)
  #undef      FRTP_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTP_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      FRTP_START_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      FRTP_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTP_START_SEC_PUBLIC_CODE)
  #undef      FRTP_START_SEC_PUBLIC_CODE
  #define DEFAULT_START_SEC_CODE
#elif defined (FRTP_STOP_SEC_PUBLIC_CODE)
  #undef      FRTP_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (FRTP_START_SEC_PRIVATE_CODE)
  #undef      FRTP_START_SEC_PRIVATE_CODE
  #define DEFAULT_START_SEC_CODE
#elif defined (FRTP_STOP_SEC_PRIVATE_CODE)
  #undef      FRTP_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
  
  
#elif defined (FRTP_START_SEC_VAR_POSTBUILD_8BIT)
  #undef      FRTP_START_SEC_VAR_POSTBUILD_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FRTP_STOP_SEC_VAR_POSTBUILD_8BIT)
  #undef      FRTP_STOP_SEC_VAR_POSTBUILD_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT 
  
 #elif defined (FRTP_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
  #undef      FRTP_START_SEC_CONST_POSTBUILD_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTP_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
  #undef      FRTP_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

 #elif defined (FRTP_START_SEC_CONST_POSTBUILD_32BIT)
  #undef      FRTP_START_SEC_CONST_POSTBUILD_32BIT
  #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (FRTP_STOP_SEC_CONST_POSTBUILD_32BIT)
  #undef      FRTP_STOP_SEC_CONST_POSTBUILD_32BIT
  #define DEFAULT_STOP_SEC_CONST_32BIT
/* -------------------------------------------------------------------------- */
/*             IOHWAB (IO Hardware Abstraction)                               */
/* -------------------------------------------------------------------------- */
#elif defined (IOHWAB_START_SEC_VAR_8BIT)
  #undef      IOHWAB_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (IOHWAB_STOP_SEC_VAR_8BIT)
  #undef      IOHWAB_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (IOHWAB_START_SEC_VAR_FAST_8BIT)
  #undef      IOHWAB_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (IOHWAB_STOP_SEC_VAR_FAST_8BIT)
  #undef      IOHWAB_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (IOHWAB_START_SEC_VAR_16BIT)
  #undef      IOHWAB_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (IOHWAB_STOP_SEC_VAR_16BIT)
  #undef      IOHWAB_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (IOHWAB_START_SEC_VAR_32BIT)
  #undef      IOHWAB_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (IOHWAB_STOP_SEC_VAR_32BIT)
  #undef      IOHWAB_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (IOHWAB_START_SEC_VAR_UNSPECIFIED)
  #undef      IOHWAB_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (IOHWAB_STOP_SEC_VAR_UNSPECIFIED)
  #undef      IOHWAB_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (IOHWAB_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      IOHWAB_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".IOHWAB_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (IOHWAB_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      IOHWAB_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (IOHWAB_START_SEC_CONST_8BIT)
  #undef      IOHWAB_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (IOHWAB_STOP_SEC_CONST_8BIT)
  #undef      IOHWAB_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (IOHWAB_START_SEC_CONST_16BIT)
  #undef      IOHWAB_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (IOHWAB_STOP_SEC_CONST_16BIT)
  #undef      IOHWAB_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (IOHWAB_START_SEC_CONST_UNSPECIFIED)
  #undef      IOHWAB_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (IOHWAB_STOP_SEC_CONST_UNSPECIFIED)
  #undef      IOHWAB_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (IOHWAB_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      IOHWAB_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".IOHWAB_CFG_CONST_ROM_UNSPEC"*/
#elif defined (IOHWAB_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      IOHWAB_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (IOHWAB_START_SEC_PUBLIC_CODE)
  #undef      IOHWAB_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".IOHWAB_PUBLIC_CODE_ROM"*/
#elif defined (IOHWAB_STOP_SEC_PUBLIC_CODE)
  #undef      IOHWAB_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (IOHWAB_START_SEC_PRIVATE_CODE)
  #undef      IOHWAB_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".IOHWAB_PRIVATE_CODE_ROM"*/
#elif defined (IOHWAB_STOP_SEC_PRIVATE_CODE)
  #undef      IOHWAB_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             IPDUM (I-PDU Multiplexer)                                      */
/* -------------------------------------------------------------------------- */

#elif defined (IPDUM_START_SEC_CODE)
   #undef      IPDUM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (IPDUM_STOP_SEC_CODE)
   #undef      IPDUM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

#elif defined (IPDUM_START_SEC_VAR_8BIT)
  #undef      IPDUM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (IPDUM_STOP_SEC_VAR_8BIT)
  #undef      IPDUM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (IPDUM_START_SEC_VAR_FAST_8BIT)
  #undef      IPDUM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (IPDUM_STOP_SEC_VAR_FAST_8BIT)
  #undef      IPDUM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (IPDUM_START_SEC_VAR_16BIT)
  #undef      IPDUM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (IPDUM_STOP_SEC_VAR_16BIT)
  #undef      IPDUM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (IPDUM_START_SEC_VAR_32BIT)
  #undef      IPDUM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (IPDUM_STOP_SEC_VAR_32BIT)
  #undef      IPDUM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (IPDUM_START_SEC_VAR_UNSPECIFIED)
  #undef      IPDUM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      IPDUM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (IPDUM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      IPDUM_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".IPDUM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (IPDUM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      IPDUM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (IPDUM_START_SEC_CONST_8BIT)
  #undef      IPDUM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (IPDUM_STOP_SEC_CONST_8BIT)
  #undef      IPDUM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (IPDUM_START_SEC_CONST_16BIT)
  #undef      IPDUM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (IPDUM_STOP_SEC_CONST_16BIT)
  #undef      IPDUM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (IPDUM_START_SEC_CONST_UNSPECIFIED)
  #undef      IPDUM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      IPDUM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (IPDUM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      IPDUM_START_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      IPDUM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_CONST_UNSPECIFIED

#elif defined (IPDUM_START_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      IPDUM_START_SEC_CONFIG_DATA_UNSPECIFIED
  #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
  #undef      IPDUM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

#elif defined (IPDUM_START_SEC_CONFIG_DATA_32BIT)
  #undef      IPDUM_START_SEC_CONFIG_DATA_32BIT
  #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (IPDUM_STOP_SEC_CONFIG_DATA_32BIT)
  #undef      IPDUM_STOP_SEC_CONFIG_DATA_32BIT
  #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (IPDUM_START_SEC_CONST_POSTBUILD_16BIT)
  #undef      IPDUM_START_SEC_CONST_POSTBUILD_16BIT
  #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (IPDUM_STOP_SEC_CONST_POSTBUILD_16BIT)
  #undef      IPDUM_STOP_SEC_CONST_POSTBUILD_16BIT
  #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (IPDUM_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
  #undef      IPDUM_START_SEC_CONST_POSTBUILD_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
  #undef      IPDUM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

#elif defined (IPDUM_START_SEC_VAR_POSTBUILD_8BIT)
  #undef      IPDUM_START_SEC_VAR_POSTBUILD_8BIT
  #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (IPDUM_STOP_SEC_VAR_POSTBUILD_8BIT)
  #undef      IPDUM_STOP_SEC_VAR_POSTBUILD_8BIT
  #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (IPDUM_START_SEC_CONST_POSTBUILD_8BIT)
  #undef      IPDUM_START_SEC_CONST_POSTBUILD_8BIT
  #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (IPDUM_STOP_SEC_CONST_POSTBUILD_8BIT)
  #undef      IPDUM_STOP_SEC_CONST_POSTBUILD_8BIT
  #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (IPDUM_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
  #undef      IPDUM_START_SEC_VAR_POSTBUILD_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (IPDUM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
  #undef      IPDUM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED

#elif defined (IPDUM_START_SEC_PUBLIC_CODE)
  #undef      IPDUM_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".IPDUM_PUBLIC_CODE_ROM"*/
#elif defined (IPDUM_STOP_SEC_PUBLIC_CODE)
  #undef      IPDUM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (IPDUM_START_SEC_PRIVATE_CODE)
  #undef      IPDUM_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".IPDUM_PRIVATE_CODE_ROM"*/
#elif defined (IPDUM_STOP_SEC_PRIVATE_CODE)
  #undef      IPDUM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             LINIF (LIN Interface)                                          */
/* -------------------------------------------------------------------------- */
#elif defined (LINIF_START_SEC_CODE)
   #undef      LINIF_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINIF_STOP_SEC_CODE)
   #undef      LINIF_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (LINIF_START_SEC_VAR_BOOLEAN)
   #undef      LINIF_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (LINIF_STOP_SEC_VAR_BOOLEAN)
   #undef      LINIF_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (LINIF_START_SEC_VAR_8BIT)
   #undef      LINIF_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (LINIF_STOP_SEC_VAR_8BIT)
   #undef      LINIF_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (LINIF_START_SEC_VAR_16BIT)
   #undef      LINIF_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (LINIF_STOP_SEC_VAR_16BIT)
   #undef      LINIF_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (LINIF_START_SEC_VAR_32BIT)
   #undef      LINIF_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (LINIF_STOP_SEC_VAR_32BIT)
   #undef      LINIF_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (LINIF_START_SEC_VAR_UNSPECIFIED)
   #undef      LINIF_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_VAR_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (LINIF_START_SEC_CONST_BOOLEAN)
   #undef      LINIF_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (LINIF_STOP_SEC_CONST_BOOLEAN)
   #undef      LINIF_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (LINIF_START_SEC_CONST_8BIT)
   #undef      LINIF_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (LINIF_STOP_SEC_CONST_8BIT)
   #undef      LINIF_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (LINIF_START_SEC_CONST_16BIT)
   #undef      LINIF_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (LINIF_STOP_SEC_CONST_16BIT)
   #undef      LINIF_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (LINIF_START_SEC_CONST_32BIT)
   #undef      LINIF_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (LINIF_STOP_SEC_CONST_32BIT)
   #undef      LINIF_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (LINIF_START_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (LINIF_START_CONFIG_DATA_BOOLEAN)
   #undef      LINIF_START_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (LINIF_STOP_CONFIG_DATA_BOOLEAN)
   #undef      LINIF_STOP_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (LINIF_START_CONFIG_DATA_8BIT)
   #undef      LINIF_START_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (LINIF_STOP_CONFIG_DATA_8BIT)
   #undef      LINIF_STOP_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (LINIF_START_CONFIG_DATA_16BIT)
   #undef      LINIF_START_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (LINIF_STOP_CONFIG_DATA_16BIT)
   #undef      LINIF_STOP_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (LINIF_START_CONFIG_DATA_32BIT)
   #undef      LINIF_START_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (LINIF_STOP_CONFIG_DATA_32BIT)
   #undef      LINIF_STOP_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (LINIF_START_CONFIG_DATA_UNSPECIFIED)
   #undef      LINIF_START_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (LINIF_STOP_CONFIG_DATA_UNSPECIFIED)
   #undef      LINIF_STOP_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (LINIF_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      LINIF_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (LINIF_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      LINIF_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (LINIF_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      LINIF_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (LINIF_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      LINIF_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (LINIF_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      LINIF_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (LINIF_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      LINIF_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (LINIF_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      LINIF_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (LINIF_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      LINIF_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (LINIF_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      LINIF_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (LINIF_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      LINIF_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (LINIF_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      LINIF_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (LINIF_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      LINIF_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (LINIF_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      LINIF_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (LINIF_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      LINIF_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (LINIF_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      LINIF_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (LINIF_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      LINIF_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (LINIF_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      LINIF_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (LINIF_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      LINIF_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (LINIF_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      LINIF_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
/*******************************************************************************
**                      LINSM (LIN State Manager)                          **
*******************************************************************************/

/*
 * LINSM (LIN State Manager)
 */

/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (LINSM_START_SEC_CODE)
   #undef      LINSM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (LINSM_STOP_SEC_CODE)
   #undef      LINSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (LINSM_START_SEC_VAR_BOOLEAN)
   #undef      LINSM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (LINSM_STOP_SEC_VAR_BOOLEAN)
   #undef      LINSM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (LINSM_START_SEC_VAR_8BIT)
   #undef      LINSM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (LINSM_STOP_SEC_VAR_8BIT)
   #undef      LINSM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (LINSM_START_SEC_VAR_16BIT)
   #undef      LINSM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (LINSM_STOP_SEC_VAR_16BIT)
   #undef      LINSM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (LINSM_START_SEC_VAR_32BIT)
   #undef      LINSM_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (LINSM_STOP_SEC_VAR_32BIT)
   #undef      LINSM_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (LINSM_START_SEC_VAR_UNSPECIFIED)
   #undef      LINSM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (LINSM_START_SEC_VAR_FAST_BOOLEAN)
   #undef      LINSM_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (LINSM_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      LINSM_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (LINSM_START_SEC_VAR_FAST_8BIT)
   #undef      LINSM_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (LINSM_STOP_SEC_VAR_FAST_8BIT)
   #undef      LINSM_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (LINSM_START_SEC_VAR_FAST_16BIT)
   #undef      LINSM_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (LINSM_STOP_SEC_VAR_FAST_16BIT)
   #undef      LINSM_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (LINSM_START_SEC_VAR_FAST_32BIT)
   #undef      LINSM_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (LINSM_STOP_SEC_VAR_FAST_32BIT)
   #undef      LINSM_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (LINSM_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      LINSM_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (LINSM_START_SEC_CONST_BOOLEAN)
   #undef      LINSM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (LINSM_STOP_SEC_CONST_BOOLEAN)
   #undef      LINSM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (LINSM_START_SEC_CONST_8BIT)
   #undef      LINSM_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (LINSM_STOP_SEC_CONST_8BIT)
   #undef      LINSM_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (LINSM_START_SEC_CONST_16BIT)
   #undef      LINSM_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (LINSM_STOP_SEC_CONST_16BIT)
   #undef      LINSM_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (LINSM_START_SEC_CONST_32BIT)
   #undef      LINSM_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (LINSM_STOP_SEC_CONST_32BIT)
   #undef      LINSM_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (LINSM_START_SEC_CONST_UNSPECIFIED)
   #undef      LINSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (LINSM_START_CONFIG_DATA_BOOLEAN)
   #undef      LINSM_START_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (LINSM_STOP_CONFIG_DATA_BOOLEAN)
   #undef      LINSM_STOP_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (LINSM_START_CONFIG_DATA_8BIT)
   #undef      LINSM_START_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (LINSM_STOP_CONFIG_DATA_8BIT)
   #undef      LINSM_STOP_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (LINSM_START_CONFIG_DATA_16BIT)
   #undef      LINSM_START_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (LINSM_STOP_CONFIG_DATA_16BIT)
   #undef      LINSM_STOP_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (LINSM_START_CONFIG_DATA_32BIT)
   #undef      LINSM_START_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (LINSM_STOP_CONFIG_DATA_32BIT)
   #undef      LINSM_STOP_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (LINSM_START_CONFIG_DATA_UNSPECIFIED)
   #undef      LINSM_START_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (LINSM_STOP_CONFIG_DATA_UNSPECIFIED)
   #undef      LINSM_STOP_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (LINSM_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      LINSM_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (LINSM_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      LINSM_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (LINSM_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      LINSM_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (LINSM_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      LINSM_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (LINSM_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      LINSM_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (LINSM_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      LINSM_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (LINSM_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      LINSM_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (LINSM_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      LINSM_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (LINSM_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      LINSM_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (LINSM_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      LINSM_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (LINSM_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      LINSM_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (LINSM_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      LINSM_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (LINSM_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      LINSM_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (LINSM_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      LINSM_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (LINSM_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      LINSM_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (LINSM_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      LINSM_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (LINSM_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      LINSM_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (LINSM_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      LINSM_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (LINSM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      LINSM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*             LINNM (LIN Network Manager)                                    */
/* -------------------------------------------------------------------------- */
#elif defined (LINNM_START_SEC_VAR_8BIT)
  #undef      LINNM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (LINNM_STOP_SEC_VAR_8BIT)
  #undef      LINNM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (LINNM_START_SEC_VAR_FAST_8BIT)
  #undef      LINNM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (LINNM_STOP_SEC_VAR_FAST_8BIT)
  #undef      LINNM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (LINNM_START_SEC_VAR_16BIT)
  #undef      LINNM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (LINNM_STOP_SEC_VAR_16BIT)
  #undef      LINNM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (LINNM_START_SEC_VAR_32BIT)
  #undef      LINNM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (LINNM_STOP_SEC_VAR_32BIT)
  #undef      LINNM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (LINNM_START_SEC_VAR_UNSPECIFIED)
  #undef      LINNM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (LINNM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      LINNM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (LINNM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      LINNM_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".LINNM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (LINNM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      LINNM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (LINNM_START_SEC_CONST_8BIT)
  #undef      LINNM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (LINNM_STOP_SEC_CONST_8BIT)
  #undef      LINNM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (LINNM_START_SEC_CONST_16BIT)
  #undef      LINNM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (LINNM_STOP_SEC_CONST_16BIT)
  #undef      LINNM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (LINNM_START_SEC_CONST_UNSPECIFIED)
  #undef      LINNM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (LINNM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      LINNM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINNM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      LINNM_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".LINNM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (LINNM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      LINNM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (LINNM_START_SEC_PUBLIC_CODE)
  #undef      LINNM_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".LINNM_PUBLIC_CODE_ROM"*/
#elif defined (LINNM_STOP_SEC_PUBLIC_CODE)
  #undef      LINNM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (LINNM_START_SEC_PRIVATE_CODE)
  #undef      LINNM_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".LINNM_PRIVATE_CODE_ROM"*/
#elif defined (LINNM_STOP_SEC_PRIVATE_CODE)
  #undef      LINNM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             MEMIF (Memory Interface)                                       */
/* -------------------------------------------------------------------------- */
#elif defined (MEMIF_START_SEC_VAR_8BIT)
  #undef      MEMIF_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (MEMIF_STOP_SEC_VAR_8BIT)
  #undef      MEMIF_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (MEMIF_START_SEC_VAR_FAST_8BIT)
  #undef      MEMIF_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (MEMIF_STOP_SEC_VAR_FAST_8BIT)
  #undef      MEMIF_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (MEMIF_START_SEC_VAR_16BIT)
  #undef      MEMIF_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (MEMIF_STOP_SEC_VAR_16BIT)
  #undef      MEMIF_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (MEMIF_START_SEC_VAR_32BIT)
  #undef      MEMIF_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (MEMIF_STOP_SEC_VAR_32BIT)
  #undef      MEMIF_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (MEMIF_START_SEC_VAR_UNSPECIFIED)
  #undef      MEMIF_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (MEMIF_STOP_SEC_VAR_UNSPECIFIED)
  #undef      MEMIF_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (MEMIF_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      MEMIF_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".MEMIF_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (MEMIF_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      MEMIF_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (MEMIF_START_SEC_CONST_8BIT)
  #undef      MEMIF_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (MEMIF_STOP_SEC_CONST_8BIT)
  #undef      MEMIF_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (MEMIF_START_SEC_CONST_16BIT)
  #undef      MEMIF_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (MEMIF_STOP_SEC_CONST_16BIT)
  #undef      MEMIF_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (MEMIF_START_SEC_CONST_UNSPECIFIED)
  #undef      MEMIF_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (MEMIF_STOP_SEC_CONST_UNSPECIFIED)
  #undef      MEMIF_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (MEMIF_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      MEMIF_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".MEMIF_CFG_CONST_ROM_UNSPEC"*/
#elif defined (MEMIF_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      MEMIF_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (MEMIF_START_SEC_PUBLIC_CODE)
  #undef      MEMIF_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".MEMIF_PUBLIC_CODE_ROM"*/
#elif defined (MEMIF_STOP_SEC_PUBLIC_CODE)
  #undef      MEMIF_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (MEMIF_START_SEC_PRIVATE_CODE)
  #undef      MEMIF_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".MEMIF_PRIVATE_CODE_ROM"*/
#elif defined (MEMIF_STOP_SEC_PRIVATE_CODE)
  #undef      MEMIF_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
  
  
  
  
  /*******************************************************************************
**                      NMEXT (Network Management Extension)                  **
*******************************************************************************/

/*
 * NMEXT (Network Management Extension) 
 */

/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (NMEXT_START_SEC_CODE)
   #undef      NMEXT_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (NMEXT_STOP_SEC_CODE)
   #undef      NMEXT_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (NMEXT_START_SEC_VAR_BOOLEAN)
   #undef      NMEXT_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (NMEXT_STOP_SEC_VAR_BOOLEAN)
   #undef      NMEXT_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (NMEXT_START_SEC_VAR_8BIT)
   #undef      NMEXT_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (NMEXT_STOP_SEC_VAR_8BIT)
   #undef      NMEXT_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (NMEXT_START_SEC_VAR_16BIT)
   #undef      NMEXT_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (NMEXT_STOP_SEC_VAR_16BIT)
   #undef      NMEXT_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (NMEXT_START_SEC_VAR_32BIT)
   #undef      NMEXT_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (NMEXT_STOP_SEC_VAR_32BIT)
   #undef      NMEXT_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (NMEXT_START_SEC_VAR_UNSPECIFIED)
   #undef      NMEXT_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (NMEXT_STOP_SEC_VAR_UNSPECIFIED)
   #undef      NMEXT_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (NMEXT_START_SEC_VAR_FAST_BOOLEAN)
   #undef      NMEXT_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (NMEXT_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      NMEXT_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (NMEXT_START_SEC_VAR_FAST_8BIT)
   #undef      NMEXT_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (NMEXT_STOP_SEC_VAR_FAST_8BIT)
   #undef      NMEXT_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (NMEXT_START_SEC_VAR_FAST_16BIT)
   #undef      NMEXT_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (NMEXT_STOP_SEC_VAR_FAST_16BIT)
   #undef      NMEXT_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (NMEXT_START_SEC_VAR_FAST_32BIT)
   #undef      NMEXT_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (NMEXT_STOP_SEC_VAR_FAST_32BIT)
   #undef      NMEXT_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (NMEXT_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      NMEXT_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (NMEXT_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      NMEXT_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (NMEXT_START_SEC_CONST_BOOLEAN)
   #undef      NMEXT_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (NMEXT_STOP_SEC_CONST_BOOLEAN)
   #undef      NMEXT_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (NMEXT_START_SEC_CONST_8BIT)
   #undef      NMEXT_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (NMEXT_STOP_SEC_CONST_8BIT)
   #undef      NMEXT_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (NMEXT_START_SEC_CONST_16BIT)
   #undef      NMEXT_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (NMEXT_STOP_SEC_CONST_16BIT)
   #undef      NMEXT_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (NMEXT_START_SEC_CONST_32BIT)
   #undef      NMEXT_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (NMEXT_STOP_SEC_CONST_32BIT)
   #undef      NMEXT_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (NMEXT_START_SEC_CONST_UNSPECIFIED)
   #undef      NMEXT_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (NMEXT_STOP_SEC_CONST_UNSPECIFIED)
   #undef      NMEXT_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (NMEXT_START_CONFIG_DATA_BOOLEAN)
   #undef      NMEXT_START_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (NMEXT_STOP_CONFIG_DATA_BOOLEAN)
   #undef      NMEXT_STOP_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (NMEXT_START_CONFIG_DATA_8BIT)
   #undef      NMEXT_START_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (NMEXT_STOP_CONFIG_DATA_8BIT)
   #undef      NMEXT_STOP_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (NMEXT_START_CONFIG_DATA_16BIT)
   #undef      NMEXT_START_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (NMEXT_STOP_CONFIG_DATA_16BIT)
   #undef      NMEXT_STOP_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (NMEXT_START_CONFIG_DATA_32BIT)
   #undef      NMEXT_START_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (NMEXT_STOP_CONFIG_DATA_32BIT)
   #undef      NMEXT_STOP_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (NMEXT_START_CONFIG_DATA_UNSPECIFIED)
   #undef      NMEXT_START_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (NMEXT_STOP_CONFIG_DATA_UNSPECIFIED)
   #undef      NMEXT_STOP_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED


/* -------------------------------------------------------------------------- */
/*             NM (Generic Network Manager)                                   */
/* -------------------------------------------------------------------------- */
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (NM_START_SEC_CODE)
   #undef      NM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (NM_STOP_SEC_CODE)
   #undef      NM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (NM_START_SEC_VAR_BOOLEAN)
   #undef      NM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (NM_STOP_SEC_VAR_BOOLEAN)
   #undef      NM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (NM_START_SEC_VAR_8BIT)
   #undef      NM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (NM_STOP_SEC_VAR_8BIT)
   #undef      NM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (NM_START_SEC_VAR_16BIT)
   #undef      NM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (NM_STOP_SEC_VAR_16BIT)
   #undef      NM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (NM_START_SEC_VAR_32BIT)
   #undef      NM_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (NM_STOP_SEC_VAR_32BIT)
   #undef      NM_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (NM_START_SEC_VAR_UNSPECIFIED)
   #undef      NM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (NM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      NM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (NM_START_SEC_VAR_FAST_BOOLEAN)
   #undef      NM_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (NM_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      NM_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (NM_START_SEC_VAR_FAST_8BIT)
   #undef      NM_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (NM_STOP_SEC_VAR_FAST_8BIT)
   #undef      NM_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (NM_START_SEC_VAR_FAST_16BIT)
   #undef      NM_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (NM_STOP_SEC_VAR_FAST_16BIT)
   #undef      NM_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (NM_START_SEC_VAR_FAST_32BIT)
   #undef      NM_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (NM_STOP_SEC_VAR_FAST_32BIT)
   #undef      NM_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (NM_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      NM_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (NM_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      NM_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (NM_START_SEC_CONST_BOOLEAN)
   #undef      NM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (NM_STOP_SEC_CONST_BOOLEAN)
   #undef      NM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (NM_START_SEC_CONST_8BIT)
   #undef      NM_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (NM_STOP_SEC_CONST_8BIT)
   #undef      NM_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (NM_START_SEC_CONST_16BIT)
   #undef      NM_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (NM_STOP_SEC_CONST_16BIT)
   #undef      NM_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (NM_START_SEC_CONST_32BIT)
   #undef      NM_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (NM_STOP_SEC_CONST_32BIT)
   #undef      NM_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (NM_START_SEC_CONST_UNSPECIFIED)
   #undef      NM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (NM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      NM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (NM_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      NM_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (NM_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      NM_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (NM_START_SEC_CONFIG_DATA_8BIT)
   #undef      NM_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (NM_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      NM_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (NM_START_SEC_CONFIG_DATA_16BIT)
   #undef      NM_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (NM_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      NM_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (NM_START_SEC_CONFIG_DATA_32BIT)
   #undef      NM_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (NM_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      NM_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (NM_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      NM_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (NM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      NM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (NM_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      NM_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (NM_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      NM_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (NM_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      NM_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (NM_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      NM_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (NM_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      NM_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (NM_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      NM_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (NM_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      NM_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (NM_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      NM_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (NM_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      NM_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (NM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      NM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (NM_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      NM_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (NM_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      NM_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (NM_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      NM_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (NM_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      NM_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (NM_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      NM_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (NM_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      NM_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (NM_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      NM_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (NM_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      NM_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (NM_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      NM_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (NM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      NM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             NVM (NVRAM Manager)                                            */
/* -------------------------------------------------------------------------- */
#elif defined (NVM_START_SEC_VAR_8BIT)
  #undef      NVM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (NVM_STOP_SEC_VAR_8BIT)
  #undef      NVM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (NVM_START_SEC_VAR_FAST_8BIT)
  #undef      NVM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (NVM_STOP_SEC_VAR_FAST_8BIT)
  #undef      NVM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (NVM_START_SEC_VAR_16BIT)
  #undef      NVM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (NVM_STOP_SEC_VAR_16BIT)
  #undef      NVM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (NVM_START_SEC_VAR_32BIT)
  #undef      NVM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (NVM_STOP_SEC_VAR_32BIT)
  #undef      NVM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (NVM_START_SEC_VAR_UNSPECIFIED)
  #undef      NVM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (NVM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      NVM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (NVM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      NVM_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".NVM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (NVM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      NVM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (NVM_START_SEC_CONST_8BIT)
  #undef      NVM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (NVM_STOP_SEC_CONST_8BIT)
  #undef      NVM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (NVM_START_SEC_CONST_16BIT)
  #undef      NVM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (NVM_STOP_SEC_CONST_16BIT)
  #undef      NVM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (NVM_START_SEC_CONST_UNSPECIFIED)
  #undef      NVM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (NVM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      NVM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (NVM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      NVM_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".NVM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (NVM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      NVM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (NVM_START_SEC_PUBLIC_CODE)
  #undef      NVM_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".NVM_PUBLIC_CODE_ROM"*/
#elif defined (NVM_STOP_SEC_PUBLIC_CODE)
  #undef      NVM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (NVM_START_SEC_PRIVATE_CODE)
  #undef      NVM_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".NVM_PRIVATE_CODE_ROM"*/
#elif defined (NVM_STOP_SEC_PRIVATE_CODE)
  #undef      NVM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/*
 * OS (Operating System)
 */

/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (OS_STOP_SEC_PRIVATE_CODE)
   #ifdef OS_START_SEC_PRIVATE_CODE
      #undef OS_START_SEC_PRIVATE_CODE
      #undef OS_SECTION_STARTED
      #undef OS_STOP_SEC_PRIVATE_CODE
	  #define DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: OS_STOP_SEC_PRIVATE_CODE has not been previously started."
   #endif
#elif defined (OS_START_SEC_PRIVATE_CODE)
   #ifndef OS_SECTION_STARTED
      #define OS_SECTION_STARTED
	  #define DEFAULT_START_SEC_CODE
   #else
      #error "MemMap.h: OS_START_SEC_PRIVATE_CODE has already been started."
   #endif

#elif defined (OS_STOP_SEC_PUBLIC_CODE)
   #ifdef OS_START_SEC_PUBLIC_CODE
      #undef OS_START_SEC_PUBLIC_CODE
      #undef OS_SECTION_STARTED
      #undef OS_STOP_SEC_PUBLIC_CODE
	  #define DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: OS_STOP_SEC_PUBLIC_CODE has not been previously started."
   #endif
#elif defined (OS_START_SEC_PUBLIC_CODE)
   #ifndef OS_SECTION_STARTED
      #define OS_SECTION_STARTED
	  #define DEFAULT_START_SEC_CODE
   #else
      #error "MemMap.h: OS_START_SEC_PUBLIC_CODE has already been started."
   #endif
#elif defined (OS_STOP_SEC_CODE)
   #ifdef OS_START_SEC_CODE
      #undef OS_START_SEC_CODE
      #undef OS_SECTION_STARTED
      #undef OS_STOP_SEC_CODE
	  #define DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: OS_STOP_SEC_CODE has not been previously started."
   #endif
#elif defined (OS_START_SEC_CODE)
   #ifndef OS_SECTION_STARTED
      #define OS_SECTION_STARTED
	  #define DEFAULT_START_SEC_CODE
   #else
      #error "MemMap.h: OS_START_SEC_CODE has already been started."
   #endif

#elif defined (OS_STOP_SEC_CODE_ISR)
   #ifdef OS_START_SEC_CODE_ISR
      #undef OS_START_SEC_CODE_ISR
      #undef OS_SECTION_STARTED
      #undef OS_STOP_SEC_CODE_ISR
	  #define DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: OS_STOP_SEC_CODE_ISR has not been previously started."
   #endif
#elif defined (OS_START_SEC_CODE_ISR)
   #ifndef OS_SECTION_STARTED
      #define OS_SECTION_STARTED
	  #define DEFAULT_START_SEC_CODE
   #else
      #error "MemMap.h: OS_START_SEC_CODE_ISR has already been started."
   #endif
#elif defined (OS_STOP_SEC_VAR_NOINIT)
   #ifdef OS_START_SEC_VAR_NOINIT
      #undef OS_START_SEC_VAR_NOINIT
      #undef OS_SECTION_STARTED
      #undef OS_STOP_SEC_VAR_NOINIT
      #define DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: OS_STOP_SEC_VAR_NOINIT has not been previously started."
   #endif
#elif defined (OS_START_SEC_VAR_NOINIT)
   #ifndef OS_SECTION_STARTED
      #define OS_SECTION_STARTED
      #define DEFAULT_START_SEC_CODE
   #else
      #error "MemMap.h: OS_START_SEC_VAR_NOINIT has already been started."
   #endif

#elif defined (OS_STOP_SEC_VAR_INIT)
   #ifdef OS_START_SEC_VAR_INIT
      #undef OS_START_SEC_VAR_INIT
      #undef OS_SECTION_STARTED
      #undef OS_STOP_SEC_VAR_INIT
      #define DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: OS_STOP_SEC_VAR_INIT has not been previously started."
   #endif
#elif defined (OS_START_SEC_VAR_INIT)
   #ifndef OS_SECTION_STARTED
      #define OS_SECTION_STARTED
      #define DEFAULT_START_SEC_CODE
   #else
      #error "MemMap.h: OS_START_SEC_VAR_INIT has already been started."
   #endif

#elif defined (OS_STOP_SEC_CONST)
   #ifdef OS_START_SEC_CONST
      #undef OS_START_SEC_CONST
      #undef OS_SECTION_STARTED
      #undef OS_STOP_SEC_CONST
      #define DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: OS_STOP_SEC_CONST has not been previously started."
   #endif
#elif defined (OS_START_SEC_CONST)
   #ifndef OS_SECTION_STARTED
      #define OS_SECTION_STARTED
      #define DEFAULT_START_SEC_CODE
   #else
      #error "MemMap.h: OS_START_SEC_CONST has already been started."
   #endif
   
#elif defined (OS_STOP_SEC_CONFIG)
   #ifdef OS_START_SEC_CONFIG
      #undef OS_START_SEC_CONFIG
      #undef OS_SECTION_STARTED
      #undef OS_STOP_SEC_CONFIG
      #define DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: OS_STOP_SEC_CONFIG has not been previously started."
   #endif
#elif defined (OS_START_SEC_CONFIG)
   #ifndef OS_SECTION_STARTED
      #define OS_SECTION_STARTED
      #define DEFAULT_START_SEC_CODE
   #else
      #error "MemMap.h: OS_START_SEC_CONFIG has already been started."
   #endif
/* -------------------------------------------------------------------------- */
/*             SCHM (BSW Scheduler)                                           */
/* -------------------------------------------------------------------------- */
#elif defined (SCHM_START_SEC_VAR_8BIT)
  #undef      SCHM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (SCHM_STOP_SEC_VAR_8BIT)
  #undef      SCHM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (SCHM_START_SEC_VAR_FAST_8BIT)
  #undef      SCHM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (SCHM_STOP_SEC_VAR_FAST_8BIT)
  #undef      SCHM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (SCHM_START_SEC_VAR_16BIT)
  #undef      SCHM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (SCHM_STOP_SEC_VAR_16BIT)
  #undef      SCHM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (SCHM_START_SEC_VAR_32BIT)
  #undef      SCHM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (SCHM_STOP_SEC_VAR_32BIT)
  #undef      SCHM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (SCHM_START_SEC_VAR_UNSPECIFIED)
  #undef      SCHM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (SCHM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      SCHM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (SCHM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      SCHM_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".SCHM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (SCHM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      SCHM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (SCHM_START_SEC_CONST_8BIT)
  #undef      SCHM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (SCHM_STOP_SEC_CONST_8BIT)
  #undef      SCHM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (SCHM_START_SEC_CONST_16BIT)
  #undef      SCHM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (SCHM_STOP_SEC_CONST_16BIT)
  #undef      SCHM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (SCHM_START_SEC_CONST_UNSPECIFIED)
  #undef      SCHM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (SCHM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      SCHM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (SCHM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      SCHM_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".SCHM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (SCHM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      SCHM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (SCHM_START_SEC_PUBLIC_CODE)
  #undef      SCHM_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".SCHM_PUBLIC_CODE_ROM"*/
#elif defined (SCHM_STOP_SEC_PUBLIC_CODE)
  #undef      SCHM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (SCHM_START_SEC_PRIVATE_CODE)
  #undef      SCHM_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".SCHM_PRIVATE_CODE_ROM"*/
#elif defined (SCHM_STOP_SEC_PRIVATE_CODE)
  #undef      SCHM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             WDGIF (WDG Interface)                                          */
/* -------------------------------------------------------------------------- */
#elif defined (WDGIF_START_SEC_VAR_8BIT)
  #undef      WDGIF_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (WDGIF_STOP_SEC_VAR_8BIT)
  #undef      WDGIF_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (WDGIF_START_SEC_VAR_FAST_8BIT)
  #undef      WDGIF_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (WDGIF_STOP_SEC_VAR_FAST_8BIT)
  #undef      WDGIF_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (WDGIF_START_SEC_VAR_16BIT)
  #undef      WDGIF_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (WDGIF_STOP_SEC_VAR_16BIT)
  #undef      WDGIF_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (WDGIF_START_SEC_VAR_32BIT)
  #undef      WDGIF_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (WDGIF_STOP_SEC_VAR_32BIT)
  #undef      WDGIF_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (WDGIF_START_SEC_VAR_UNSPECIFIED)
  #undef      WDGIF_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (WDGIF_STOP_SEC_VAR_UNSPECIFIED)
  #undef      WDGIF_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (WDGIF_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      WDGIF_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".WDGIF_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (WDGIF_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      WDGIF_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (WDGIF_START_SEC_CONST_8BIT)
  #undef      WDGIF_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (WDGIF_STOP_SEC_CONST_8BIT)
  #undef      WDGIF_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (WDGIF_START_SEC_CONST_16BIT)
  #undef      WDGIF_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (WDGIF_STOP_SEC_CONST_16BIT)
  #undef      WDGIF_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (WDGIF_START_SEC_CONST_UNSPECIFIED)
  #undef      WDGIF_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDGIF_STOP_SEC_CONST_UNSPECIFIED)
  #undef      WDGIF_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDGIF_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      WDGIF_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".WDGIF_CFG_CONST_ROM_UNSPEC"*/
#elif defined (WDGIF_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      WDGIF_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDGIF_START_SEC_PUBLIC_CODE)
  #undef      WDGIF_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".WDGIF_PUBLIC_CODE_ROM"*/
#elif defined (WDGIF_STOP_SEC_PUBLIC_CODE)
  #undef      WDGIF_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (WDGIF_START_SEC_PRIVATE_CODE)
  #undef      WDGIF_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".WDGIF_PRIVATE_CODE_ROM"*/
#elif defined (WDGIF_STOP_SEC_PRIVATE_CODE)
  #undef      WDGIF_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE
/* -------------------------------------------------------------------------- */
/*             WDGM (Watchdog Manager)                                        */
/* -------------------------------------------------------------------------- */
#elif defined (WDGM_START_SEC_VAR_8BIT)
  #undef      WDGM_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (WDGM_STOP_SEC_VAR_8BIT)
  #undef      WDGM_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (WDGM_START_SEC_VAR_FAST_8BIT)
  #undef      WDGM_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (WDGM_STOP_SEC_VAR_FAST_8BIT)
  #undef      WDGM_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (WDGM_START_SEC_VAR_16BIT)
  #undef      WDGM_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (WDGM_STOP_SEC_VAR_16BIT)
  #undef      WDGM_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (WDGM_START_SEC_VAR_32BIT)
  #undef      WDGM_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (WDGM_STOP_SEC_VAR_32BIT)
  #undef      WDGM_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (WDGM_START_SEC_VAR_UNSPECIFIED)
  #undef      WDGM_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (WDGM_STOP_SEC_VAR_UNSPECIFIED)
  #undef      WDGM_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (WDGM_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      WDGM_START_SEC_CONFIG_VAR_UNSPECIFIED
    /*#pragma ghs section sbss=".WDGM_CONFIG_RAM_UNSPECIFIED"*/
#elif defined (WDGM_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      WDGM_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (WDGM_START_SEC_CONST_8BIT)
  #undef      WDGM_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (WDGM_STOP_SEC_CONST_8BIT)
  #undef      WDGM_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (WDGM_START_SEC_CONST_16BIT)
  #undef      WDGM_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (WDGM_STOP_SEC_CONST_16BIT)
  #undef      WDGM_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (WDGM_START_SEC_CONST_UNSPECIFIED)
  #undef      WDGM_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (WDGM_STOP_SEC_CONST_UNSPECIFIED)
  #undef      WDGM_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDGM_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      WDGM_START_SEC_CONFIG_CONST_UNSPECIFIED
    /*#pragma ghs section rosdata=".WDGM_CFG_CONST_ROM_UNSPEC"*/
#elif defined (WDGM_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      WDGM_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (WDGM_START_SEC_PUBLIC_CODE)
  #undef      WDGM_START_SEC_PUBLIC_CODE
    /*#pragma ghs section text=".WDGM_PUBLIC_CODE_ROM"*/
#elif defined (WDGM_STOP_SEC_PUBLIC_CODE)
  #undef      WDGM_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (WDGM_START_SEC_PRIVATE_CODE)
  #undef      WDGM_START_SEC_PRIVATE_CODE
    /*#pragma ghs section text=".WDGM_PRIVATE_CODE_ROM"*/
#elif defined (WDGM_STOP_SEC_PRIVATE_CODE)
  #undef      WDGM_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

/* -------------------------------------------------------------------------- */
/*            PDUR (PDU Router)                                               */
/* -------------------------------------------------------------------------- */
 
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (PDUR_START_SEC_CODE)
   #undef      PDUR_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (PDUR_STOP_SEC_CODE)
   #undef      PDUR_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (PDUR_START_SEC_VAR_BOOLEAN)
   #undef      PDUR_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (PDUR_STOP_SEC_VAR_BOOLEAN)
   #undef      PDUR_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (PDUR_START_SEC_VAR_8BIT)
   #undef      PDUR_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (PDUR_STOP_SEC_VAR_8BIT)
   #undef      PDUR_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (PDUR_START_SEC_VAR_16BIT)
   #undef      PDUR_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (PDUR_STOP_SEC_VAR_16BIT)
   #undef      PDUR_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (PDUR_START_SEC_VAR_32BIT)
   #undef      PDUR_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (PDUR_STOP_SEC_VAR_32BIT)
   #undef      PDUR_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (PDUR_START_SEC_VAR_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_VAR_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (PDUR_START_SEC_CONST_BOOLEAN)
   #undef      PDUR_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (PDUR_STOP_SEC_CONST_BOOLEAN)
   #undef      PDUR_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (PDUR_START_SEC_CONST_8BIT)
   #undef      PDUR_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (PDUR_STOP_SEC_CONST_8BIT)
   #undef      PDUR_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (PDUR_START_SEC_CONST_16BIT)
   #undef      PDUR_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (PDUR_STOP_SEC_CONST_16BIT)
   #undef      PDUR_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (PDUR_START_SEC_CONST_32BIT)
   #undef      PDUR_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (PDUR_STOP_SEC_CONST_32BIT)
   #undef      PDUR_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (PDUR_START_SEC_CONST_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONST_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (PDUR_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      PDUR_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (PDUR_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      PDUR_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (PDUR_START_SEC_CONFIG_DATA_8BIT)
   #undef      PDUR_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (PDUR_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      PDUR_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (PDUR_START_SEC_CONFIG_DATA_16BIT)
   #undef      PDUR_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (PDUR_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      PDUR_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (PDUR_START_SEC_CONFIG_DATA_32BIT)
   #undef      PDUR_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (PDUR_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      PDUR_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (PDUR_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED


/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (PDUR_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      PDUR_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (PDUR_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      PDUR_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (PDUR_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      PDUR_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (PDUR_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      PDUR_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (PDUR_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      PDUR_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (PDUR_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      PDUR_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (PDUR_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      PDUR_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (PDUR_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      PDUR_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (PDUR_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      PDUR_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (PDUR_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      PDUR_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (PDUR_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      PDUR_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (PDUR_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      PDUR_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (PDUR_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      PDUR_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (PDUR_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      PDUR_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (PDUR_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      PDUR_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (PDUR_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      PDUR_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (PDUR_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      PDUR_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (PDUR_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      PDUR_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (PDUR_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      PDUR_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*            BswM (BSW Mode Manager)                                         */
/* -------------------------------------------------------------------------- */
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (BSWM_START_SEC_CODE)
   #undef      BSWM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (BSWM_STOP_SEC_CODE)
   #undef      BSWM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE
/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (BSWM_START_SEC_VAR_BOOLEAN)
   #undef      BSWM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (BSWM_STOP_SEC_VAR_BOOLEAN)
   #undef      BSWM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN   
   
#elif defined (BSWM_START_SEC_VAR_8BIT)
   #undef      BSWM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (BSWM_STOP_SEC_VAR_8BIT)
   #undef      BSWM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT  

#elif defined (BSWM_START_SEC_VAR_16BIT)
   #undef      BSWM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (BSWM_STOP_SEC_VAR_16BIT)
   #undef      BSWM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT    

#elif defined (BSWM_START_SEC_VAR_NOINIT_UNSPECIFIED)
   #undef      BSWM_START_SEC_VAR_NOINIT_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED
#elif defined (BSWM_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
   #undef      BSWM_STOP_SEC_VAR_NOINIT_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED    

/* -------------------------------------------------------------------------- */
/*            Com (Communication)                                               */
/* -------------------------------------------------------------------------- */
/*
 * COM (Communication)
 */
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (COM_START_SEC_CODE)
   #undef      COM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (COM_STOP_SEC_CODE)
   #undef      COM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (COM_START_SEC_VAR_UNSPECIFIED)
   #undef      COM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (COM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      COM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED
/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (COM_START_SEC_CONST_UNSPECIFIED)
   #undef      COM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (COM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      COM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (COM_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      COM_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (COM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      COM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (COM_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      COM_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (COM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      COM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             FRTRCV (FlexRay Tranceiver Driver)                             */
/* -------------------------------------------------------------------------- */
#elif defined (FRTRCV_START_SEC_VAR_8BIT)
  #undef      FRTRCV_START_SEC_VAR_8BIT
  #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FRTRCV_STOP_SEC_VAR_8BIT)
  #undef      FRTRCV_STOP_SEC_VAR_8BIT
  #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (FRTRCV_START_SEC_VAR_FAST_8BIT)
  #undef      FRTRCV_START_SEC_VAR_FAST_8BIT
  #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (FRTRCV_STOP_SEC_VAR_FAST_8BIT)
  #undef      FRTRCV_STOP_SEC_VAR_FAST_8BIT
  #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (FRTRCV_START_SEC_VAR_16BIT)
  #undef      FRTRCV_START_SEC_VAR_16BIT
  #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (FRTRCV_STOP_SEC_VAR_16BIT)
  #undef      FRTRCV_STOP_SEC_VAR_16BIT
  #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (FRTRCV_START_SEC_VAR_32BIT)
  #undef      FRTRCV_START_SEC_VAR_32BIT
  #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (FRTRCV_STOP_SEC_VAR_32BIT)
  #undef      FRTRCV_STOP_SEC_VAR_32BIT
  #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (FRTRCV_START_SEC_VAR_UNSPECIFIED)
  #undef      FRTRCV_START_SEC_VAR_UNSPECIFIED
  #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FRTRCV_STOP_SEC_VAR_UNSPECIFIED)
  #undef      FRTRCV_STOP_SEC_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (FRTRCV_START_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      FRTRCV_START_SEC_CONFIG_VAR_UNSPECIFIED
#elif defined (FRTRCV_STOP_SEC_CONFIG_VAR_UNSPECIFIED)
  #undef      FRTRCV_STOP_SEC_CONFIG_VAR_UNSPECIFIED
  #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

#elif defined (FRTRCV_START_SEC_CONST_8BIT)
  #undef      FRTRCV_START_SEC_CONST_8BIT
  #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (FRTRCV_STOP_SEC_CONST_8BIT)
  #undef      FRTRCV_STOP_SEC_CONST_8BIT
  #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (FRTRCV_START_SEC_CONST_16BIT)
  #undef      FRTRCV_START_SEC_CONST_16BIT
  #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (FRTRCV_STOP_SEC_CONST_16BIT)
  #undef      FRTRCV_STOP_SEC_CONST_16BIT
  #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (FRTRCV_START_SEC_CONST_32BIT)
  #undef      FRTRCV_START_SEC_CONST_32BIT
  #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (FRTRCV_STOP_SEC_CONST_32BIT)
  #undef      FRTRCV_STOP_SEC_CONST_32BIT
  #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (FRTRCV_START_SEC_CONST_UNSPECIFIED)
  #undef      FRTRCV_START_SEC_CONST_UNSPECIFIED
  #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRTRCV_STOP_SEC_CONST_UNSPECIFIED)
  #undef      FRTRCV_STOP_SEC_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTRCV_START_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      FRTRCV_START_SEC_CONFIG_CONST_UNSPECIFIED
#elif defined (FRTRCV_STOP_SEC_CONFIG_CONST_UNSPECIFIED)
  #undef      FRTRCV_STOP_SEC_CONFIG_CONST_UNSPECIFIED
  #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

#elif defined (FRTRCV_START_SEC_PUBLIC_CODE)
  #undef      FRTRCV_START_SEC_PUBLIC_CODE
#elif defined (FRTRCV_STOP_SEC_PUBLIC_CODE)
  #undef      FRTRCV_STOP_SEC_PUBLIC_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (FRTRCV_START_SEC_PRIVATE_CODE)
  #undef      FRTRCV_START_SEC_PRIVATE_CODE
#elif defined (FRTRCV_STOP_SEC_PRIVATE_CODE)
  #undef      FRTRCV_STOP_SEC_PRIVATE_CODE
  #define DEFAULT_STOP_SEC_CODE

#elif defined (FRTRCV_START_SEC_CODE)
  #undef      FRTRCV_START_SEC_CODE
  #define     DEFAULT_START_SEC_CODE
#elif defined (FRTRCV_STOP_SEC_CODE)
  #undef      FRTRCV_STOP_SEC_CODE
  #define DEFAULT_STOP_SEC_CODE
  
/* -------------------------------------------------------------------------- */
/*             FRSM (Flexray State Manager)                                   */
/* -------------------------------------------------------------------------- */
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (FRSM_START_SEC_CODE)
   #undef      FRSM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FRSM_STOP_SEC_CODE)
   #undef      FRSM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE 

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (FRSM_START_SEC_VAR_BOOLEAN)
   #undef      FRSM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (FRSM_STOP_SEC_VAR_BOOLEAN)
   #undef      FRSM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (FRSM_START_SEC_VAR_8BIT)
   #undef      FRSM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FRSM_STOP_SEC_VAR_8BIT)
   #undef      FRSM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (FRSM_START_SEC_VAR_16BIT)
   #undef      FRSM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (FRSM_STOP_SEC_VAR_16BIT)
   #undef      FRSM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (FRSM_START_SEC_VAR_32BIT)
   #undef      FRSM_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (FRSM_STOP_SEC_VAR_32BIT)
   #undef      FRSM_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (FRSM_START_SEC_VAR_UNSPECIFIED)
   #undef      FRSM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED 

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (FRSM_START_SEC_VAR_FAST_BOOLEAN)
   #undef      FRSM_START_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_START_SEC_VAR_FAST_BOOLEAN
#elif defined (FRSM_STOP_SEC_VAR_FAST_BOOLEAN)
   #undef      FRSM_STOP_SEC_VAR_FAST_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN

#elif defined (FRSM_START_SEC_VAR_FAST_8BIT)
   #undef      FRSM_START_SEC_VAR_FAST_8BIT
   #define DEFAULT_START_SEC_VAR_FAST_8BIT
#elif defined (FRSM_STOP_SEC_VAR_FAST_8BIT)
   #undef      FRSM_STOP_SEC_VAR_FAST_8BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_8BIT

#elif defined (FRSM_START_SEC_VAR_FAST_16BIT)
   #undef      FRSM_START_SEC_VAR_FAST_16BIT
   #define DEFAULT_START_SEC_VAR_FAST_16BIT
#elif defined (FRSM_STOP_SEC_VAR_FAST_16BIT)
   #undef      FRSM_STOP_SEC_VAR_FAST_16BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_16BIT

#elif defined (FRSM_START_SEC_VAR_FAST_32BIT)
   #undef      FRSM_START_SEC_VAR_FAST_32BIT
   #define DEFAULT_START_SEC_VAR_FAST_32BIT
#elif defined (FRSM_STOP_SEC_VAR_FAST_32BIT)
   #undef      FRSM_STOP_SEC_VAR_FAST_32BIT
   #define DEFAULT_STOP_SEC_VAR_FAST_32BIT

#elif defined (FRSM_START_SEC_VAR_FAST_UNSPECIFIED)
   #undef      FRSM_START_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_VAR_FAST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (FRSM_START_SEC_CONST_BOOLEAN)
   #undef      FRSM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (FRSM_STOP_SEC_CONST_BOOLEAN)
   #undef      FRSM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (FRSM_START_SEC_CONST_8BIT)
   #undef      FRSM_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (FRSM_STOP_SEC_CONST_8BIT)
   #undef      FRSM_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (FRSM_START_SEC_CONST_16BIT)
   #undef      FRSM_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (FRSM_STOP_SEC_CONST_16BIT)
   #undef      FRSM_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (FRSM_START_SEC_CONST_32BIT)
   #undef      FRSM_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (FRSM_STOP_SEC_CONST_32BIT)
   #undef      FRSM_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (FRSM_START_SEC_CONST_UNSPECIFIED)
   #undef      FRSM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (FRSM_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      FRSM_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (FRSM_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      FRSM_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (FRSM_START_SEC_CONFIG_DATA_8BIT)
   #undef      FRSM_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (FRSM_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      FRSM_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (FRSM_START_SEC_CONFIG_DATA_16BIT)
   #undef      FRSM_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (FRSM_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      FRSM_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (FRSM_START_SEC_CONFIG_DATA_32BIT)
   #undef      FRSM_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (FRSM_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      FRSM_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (FRSM_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      FRSM_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (FRSM_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      FRSM_START_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
#elif defined (FRSM_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #undef      FRSM_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN

#elif defined (FRSM_START_SEC_CONST_POSTBUILD_8BIT)
   #undef      FRSM_START_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
#elif defined (FRSM_STOP_SEC_CONST_POSTBUILD_8BIT)
   #undef      FRSM_STOP_SEC_CONST_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT

#elif defined (FRSM_START_SEC_CONST_POSTBUILD_16BIT)
   #undef      FRSM_START_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
#elif defined (FRSM_STOP_SEC_CONST_POSTBUILD_16BIT)
   #undef      FRSM_STOP_SEC_CONST_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT

#elif defined (FRSM_START_SEC_CONST_POSTBUILD_32BIT)
   #undef      FRSM_START_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
#elif defined (FRSM_STOP_SEC_CONST_POSTBUILD_32BIT)
   #undef      FRSM_STOP_SEC_CONST_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT

#elif defined (FRSM_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      FRSM_START_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (FRSM_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      FRSM_START_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
#elif defined (FRSM_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #undef      FRSM_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN

#elif defined (FRSM_START_SEC_VAR_POSTBUILD_8BIT)
   #undef      FRSM_START_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
#elif defined (FRSM_STOP_SEC_VAR_POSTBUILD_8BIT)
   #undef      FRSM_STOP_SEC_VAR_POSTBUILD_8BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT

#elif defined (FRSM_START_SEC_VAR_POSTBUILD_16BIT)
   #undef      FRSM_START_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
#elif defined (FRSM_STOP_SEC_VAR_POSTBUILD_16BIT)
   #undef      FRSM_STOP_SEC_VAR_POSTBUILD_16BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT

#elif defined (FRSM_START_SEC_VAR_POSTBUILD_32BIT)
   #undef      FRSM_START_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
#elif defined (FRSM_STOP_SEC_VAR_POSTBUILD_32BIT)
   #undef      FRSM_STOP_SEC_VAR_POSTBUILD_32BIT
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT

#elif defined (FRSM_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      FRSM_START_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
#elif defined (FRSM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #undef      FRSM_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED

/* -------------------------------------------------------------------------- */
/*             STBM (Synchronized TimeBase Manager                            */
/* -------------------------------------------------------------------------- */
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (STBM_START_SEC_CODE)
   #undef      STBM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (STBM_STOP_SEC_CODE)
   #undef      STBM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (STBM_START_SEC_VAR_BOOLEAN)
   #undef      STBM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (STBM_STOP_SEC_VAR_BOOLEAN)
   #undef      STBM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (STBM_START_SEC_VAR_8BIT)
   #undef      STBM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (STBM_STOP_SEC_VAR_8BIT)
   #undef      STBM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (STBM_START_SEC_VAR_16BIT)
   #undef      STBM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (STBM_STOP_SEC_VAR_16BIT)
   #undef      STBM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (STBM_START_SEC_VAR_32BIT)
   #undef      STBM_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (STBM_STOP_SEC_VAR_32BIT)
   #undef      STBM_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (STBM_START_SEC_VAR_UNSPECIFIED)
   #undef      STBM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (STBM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      STBM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (STBM_START_SEC_CONST_BOOLEAN)
   #undef      STBM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (STBM_STOP_SEC_CONST_BOOLEAN)
   #undef      STBM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (STBM_START_SEC_CONST_8BIT)
   #undef      STBM_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (STBM_STOP_SEC_CONST_8BIT)
   #undef      STBM_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (STBM_START_SEC_CONST_16BIT)
   #undef      STBM_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (STBM_STOP_SEC_CONST_16BIT)
   #undef      STBM_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (STBM_START_SEC_CONST_32BIT)
   #undef      STBM_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (STBM_STOP_SEC_CONST_32BIT)
   #undef      STBM_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (STBM_START_SEC_CONST_UNSPECIFIED)
   #undef      STBM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (STBM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      STBM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (STBM_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      STBM_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (STBM_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      STBM_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (STBM_START_SEC_CONFIG_DATA_8BIT)
   #undef      STBM_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (STBM_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      STBM_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (STBM_START_SEC_CONFIG_DATA_16BIT)
   #undef      STBM_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (STBM_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      STBM_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (STBM_START_SEC_CONFIG_DATA_32BIT)
   #undef      STBM_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (STBM_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      STBM_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (STBM_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      STBM_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (STBM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      STBM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED
/* -------------------------------------------------------------------------- */
/*             FIM (Synchronized TimeBase Manager                            */
/* -------------------------------------------------------------------------- */
/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (FIM_START_SEC_CODE)
   #undef      FIM_START_SEC_CODE
   #define DEFAULT_START_SEC_CODE
#elif defined (FIM_STOP_SEC_CODE)
   #undef      FIM_STOP_SEC_CODE
   #define DEFAULT_STOP_SEC_CODE

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (FIM_START_SEC_VAR_BOOLEAN)
   #undef      FIM_START_SEC_VAR_BOOLEAN
   #define DEFAULT_START_SEC_VAR_BOOLEAN
#elif defined (FIM_STOP_SEC_VAR_BOOLEAN)
   #undef      FIM_STOP_SEC_VAR_BOOLEAN
   #define DEFAULT_STOP_SEC_VAR_BOOLEAN

#elif defined (FIM_START_SEC_VAR_8BIT)
   #undef      FIM_START_SEC_VAR_8BIT
   #define DEFAULT_START_SEC_VAR_8BIT
#elif defined (FIM_STOP_SEC_VAR_8BIT)
   #undef      FIM_STOP_SEC_VAR_8BIT
   #define DEFAULT_STOP_SEC_VAR_8BIT

#elif defined (FIM_START_SEC_VAR_16BIT)
   #undef      FIM_START_SEC_VAR_16BIT
   #define DEFAULT_START_SEC_VAR_16BIT
#elif defined (FIM_STOP_SEC_VAR_16BIT)
   #undef      FIM_STOP_SEC_VAR_16BIT
   #define DEFAULT_STOP_SEC_VAR_16BIT

#elif defined (FIM_START_SEC_VAR_32BIT)
   #undef      FIM_START_SEC_VAR_32BIT
   #define DEFAULT_START_SEC_VAR_32BIT
#elif defined (FIM_STOP_SEC_VAR_32BIT)
   #undef      FIM_STOP_SEC_VAR_32BIT
   #define DEFAULT_STOP_SEC_VAR_32BIT

#elif defined (FIM_START_SEC_VAR_UNSPECIFIED)
   #undef      FIM_START_SEC_VAR_UNSPECIFIED
   #define DEFAULT_START_SEC_VAR_UNSPECIFIED
#elif defined (FIM_STOP_SEC_VAR_UNSPECIFIED)
   #undef      FIM_STOP_SEC_VAR_UNSPECIFIED
   #define DEFAULT_STOP_SEC_VAR_UNSPECIFIED

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (FIM_START_SEC_CONST_BOOLEAN)
   #undef      FIM_START_SEC_CONST_BOOLEAN
   #define DEFAULT_START_SEC_CONST_BOOLEAN
#elif defined (FIM_STOP_SEC_CONST_BOOLEAN)
   #undef      FIM_STOP_SEC_CONST_BOOLEAN
   #define DEFAULT_STOP_SEC_CONST_BOOLEAN

#elif defined (FIM_START_SEC_CONST_8BIT)
   #undef      FIM_START_SEC_CONST_8BIT
   #define DEFAULT_START_SEC_CONST_8BIT
#elif defined (FIM_STOP_SEC_CONST_8BIT)
   #undef      FIM_STOP_SEC_CONST_8BIT
   #define DEFAULT_STOP_SEC_CONST_8BIT

#elif defined (FIM_START_SEC_CONST_16BIT)
   #undef      FIM_START_SEC_CONST_16BIT
   #define DEFAULT_START_SEC_CONST_16BIT
#elif defined (FIM_STOP_SEC_CONST_16BIT)
   #undef      FIM_STOP_SEC_CONST_16BIT
   #define DEFAULT_STOP_SEC_CONST_16BIT

#elif defined (FIM_START_SEC_CONST_32BIT)
   #undef      FIM_START_SEC_CONST_32BIT
   #define DEFAULT_START_SEC_CONST_32BIT
#elif defined (FIM_STOP_SEC_CONST_32BIT)
   #undef      FIM_STOP_SEC_CONST_32BIT
   #define DEFAULT_STOP_SEC_CONST_32BIT

#elif defined (FIM_START_SEC_CONST_UNSPECIFIED)
   #undef      FIM_START_SEC_CONST_UNSPECIFIED
   #define DEFAULT_START_SEC_CONST_UNSPECIFIED
#elif defined (FIM_STOP_SEC_CONST_UNSPECIFIED)
   #undef      FIM_STOP_SEC_CONST_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONST_UNSPECIFIED

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (FIM_START_SEC_CONFIG_DATA_BOOLEAN)
   #undef      FIM_START_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
#elif defined (FIM_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #undef      FIM_STOP_SEC_CONFIG_DATA_BOOLEAN
   #define DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN

#elif defined (FIM_START_SEC_CONFIG_DATA_8BIT)
   #undef      FIM_START_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_8BIT
#elif defined (FIM_STOP_SEC_CONFIG_DATA_8BIT)
   #undef      FIM_STOP_SEC_CONFIG_DATA_8BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_8BIT

#elif defined (FIM_START_SEC_CONFIG_DATA_16BIT)
   #undef      FIM_START_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_16BIT
#elif defined (FIM_STOP_SEC_CONFIG_DATA_16BIT)
   #undef      FIM_STOP_SEC_CONFIG_DATA_16BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_16BIT

#elif defined (FIM_START_SEC_CONFIG_DATA_32BIT)
   #undef      FIM_START_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_START_SEC_CONFIG_DATA_32BIT
#elif defined (FIM_STOP_SEC_CONFIG_DATA_32BIT)
   #undef      FIM_STOP_SEC_CONFIG_DATA_32BIT
   #define DEFAULT_STOP_SEC_CONFIG_DATA_32BIT

#elif defined (FIM_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      FIM_START_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
#elif defined (FIM_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #undef      FIM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #define DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED
/* ---------------------------------------------------------------------------*/
/* End of module section mapping                                              */
/* ---------------------------------------------------------------------------*/
#else
#endif  /* START_WITH_IF */
/*******************************************************************************
**                      Default section mapping                               **
*******************************************************************************/
/* general start of #elif chain whith #if                                     */
#if defined (START_WITH_IF)
/* -------------------------------------------------------------------------- */
/* RAM variables initialized from ROM on reset                                */
/* -------------------------------------------------------------------------- */

/*
 * CODE section
 * To be used for mapping code to application block, boot block, external flash, etc.
 */
#elif defined (DEFAULT_STOP_SEC_CODE)
   #ifdef DEFAULT_START_SEC_CODE
      #undef DEFAULT_START_SEC_CODE
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CODE
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CODE has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CODE)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CODE has already been started."
   #endif

/*
 * VAR section
 * To be used for global or static variables that are initialized with values after every reset.
 */
#elif defined (DEFAULT_STOP_SEC_VAR_BOOLEAN)
   #ifdef DEFAULT_START_SEC_VAR_BOOLEAN
      #undef DEFAULT_START_SEC_VAR_BOOLEAN
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_BOOLEAN
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_BOOLEAN has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_BOOLEAN)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_BOOLEAN has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_8BIT)
   #ifdef DEFAULT_START_SEC_VAR_8BIT
      #undef DEFAULT_START_SEC_VAR_8BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_8BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_8BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_8BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_8BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_16BIT)
   #ifdef DEFAULT_START_SEC_VAR_16BIT
      #undef DEFAULT_START_SEC_VAR_16BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_16BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_16BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_16BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_16BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_32BIT)
   #ifdef DEFAULT_START_SEC_VAR_32BIT
      #undef DEFAULT_START_SEC_VAR_32BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_32BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_32BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_32BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_32BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_UNSPECIFIED)
   #ifdef DEFAULT_START_SEC_VAR_UNSPECIFIED
      #undef DEFAULT_START_SEC_VAR_UNSPECIFIED
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_UNSPECIFIED
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_UNSPECIFIED has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_UNSPECIFIED)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_UNSPECIFIED has already been started."
   #endif

/* IMPORTANT: this section is vendor specific addition to enable the Dem module to build 
   correctly, it is expected to be removed in future releases*/
#elif defined (DEFAULT_STOP_SEC_VAR_NVRAM)
   #ifdef DEFAULT_START_SEC_VAR_NVRAM
      #undef DEFAULT_START_SEC_VAR_NVRAM
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_NVRAM
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_NVRAM has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_NVRAM)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_NVRAM has already been started."
   #endif

/*
 * VAR_FAST section
 * To be used for all global or static variables that have least one of the following properties:
 *   * accessed bitwise
 *   * frequently used
 *   * high number of accesses in source code
 */
#elif defined (DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN)
   #ifdef DEFAULT_START_SEC_VAR_FAST_BOOLEAN
      #undef DEFAULT_START_SEC_VAR_FAST_BOOLEAN
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_FAST_BOOLEAN has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_FAST_BOOLEAN)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_FAST_BOOLEAN has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_FAST_8BIT)
   #ifdef DEFAULT_START_SEC_VAR_FAST_8BIT
      #undef DEFAULT_START_SEC_VAR_FAST_8BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_FAST_8BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_FAST_8BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_FAST_8BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_FAST_8BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_FAST_16BIT)
   #ifdef DEFAULT_START_SEC_VAR_FAST_16BIT
      #undef DEFAULT_START_SEC_VAR_FAST_16BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_FAST_16BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_FAST_16BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_FAST_16BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_FAST_16BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_FAST_32BIT)
   #ifdef DEFAULT_START_SEC_VAR_FAST_32BIT
      #undef DEFAULT_START_SEC_VAR_FAST_32BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_FAST_32BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_FAST_32BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_FAST_32BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_FAST_32BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED)
   #ifdef DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
      #undef DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_FAST_UNSPECIFIED has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_FAST_UNSPECIFIED has already been started."
   #endif

/*
 * VAR_NOINIT section
 * To be used for RAM buffers of variables saved in non volatile memory.
  */
#elif defined (DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED)
   #ifdef DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED
      #undef DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_NOINIT_UNSPECIFIED has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_NOINIT_UNSPECIFIED has already been started."
   #endif

/*
 * CONST section
 * To be used for global or static constants.
 */
#elif defined (DEFAULT_STOP_SEC_CONST_BOOLEAN)
   #ifdef DEFAULT_START_SEC_CONST_BOOLEAN
      #undef DEFAULT_START_SEC_CONST_BOOLEAN
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_BOOLEAN
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_BOOLEAN has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_BOOLEAN)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_BOOLEAN has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONST_8BIT)
   #ifdef DEFAULT_START_SEC_CONST_8BIT
      #undef DEFAULT_START_SEC_CONST_8BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_8BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_8BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_8BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_8BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONST_16BIT)
   #ifdef DEFAULT_START_SEC_CONST_16BIT
      #undef DEFAULT_START_SEC_CONST_16BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_16BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_16BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_16BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_16BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONST_32BIT)
   #ifdef DEFAULT_START_SEC_CONST_32BIT
      #undef DEFAULT_START_SEC_CONST_32BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_32BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_32BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_32BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_32BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONST_UNSPECIFIED)
   #ifdef DEFAULT_START_SEC_CONST_UNSPECIFIED
      #undef DEFAULT_START_SEC_CONST_UNSPECIFIED
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_UNSPECIFIED
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_UNSPECIFIED has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_UNSPECIFIED)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_UNSPECIFIED has already been started."
   #endif

/*
 * CONFIG_DATA section
 * Constants with attributes that show that they reside in one segment for module configuration.
 */
#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN)
   #ifdef DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
      #undef DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONFIG_DATA_BOOLEAN has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONFIG_DATA_BOOLEAN has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_8BIT)
   #ifdef DEFAULT_START_SEC_CONFIG_DATA_8BIT
      #undef DEFAULT_START_SEC_CONFIG_DATA_8BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONFIG_DATA_8BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONFIG_DATA_8BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONFIG_DATA_8BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONFIG_DATA_8BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_16BIT)
   #ifdef DEFAULT_START_SEC_CONFIG_DATA_16BIT
      #undef DEFAULT_START_SEC_CONFIG_DATA_16BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONFIG_DATA_16BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONFIG_DATA_16BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONFIG_DATA_16BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONFIG_DATA_16BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_32BIT)
   #ifdef DEFAULT_START_SEC_CONFIG_DATA_32BIT
      #undef DEFAULT_START_SEC_CONFIG_DATA_32BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONFIG_DATA_32BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONFIG_DATA_32BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONFIG_DATA_32BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONFIG_DATA_32BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED)
   #ifdef DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
      #undef DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONFIG_DATA_UNSPECIFIED has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONFIG_DATA_UNSPECIFIED has already been started."
   #endif

/*
 * CONST_POSTBUILD section
 * To be used for global or static constants that resides in the postbuild area.
 */
#elif defined (DEFAULT_STOP_SEC_CONST_POSTBUILD)
   #ifdef DEFAULT_START_SEC_CONST_POSTBUILD
      #undef DEFAULT_START_SEC_CONST_POSTBUILD
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_POSTBUILD
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_POSTBUILD has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_POSTBUILD)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_POSTBUILD has already been started."
   #endif

 
 
 #elif defined (DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN)
   #ifdef DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
      #undef DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_POSTBUILD_BOOLEAN has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_POSTBUILD_BOOLEAN has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT)
   #ifdef DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
      #undef DEFAULT_START_SEC_CONST_POSTBUILD_8BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_POSTBUILD_8BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_POSTBUILD_8BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_POSTBUILD_8BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT)
   #ifdef DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
      #undef DEFAULT_START_SEC_CONST_POSTBUILD_16BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_POSTBUILD_16BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_POSTBUILD_16BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_POSTBUILD_16BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT)
   #ifdef DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
      #undef DEFAULT_START_SEC_CONST_POSTBUILD_32BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_POSTBUILD_32BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_POSTBUILD_32BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_POSTBUILD_32BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #ifdef DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
      #undef DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_CONST_POSTBUILD_UNSPECIFIED has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_CONST_POSTBUILD_UNSPECIFIED has already been started."
   #endif

/*
 * VAR_POSTBUILD section
 * To be used for global or static variables that are initialized with values after every reset that resides in the postbuild area.
 */
#elif defined (DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN)
   #ifdef DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
      #undef DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_POSTBUILD_BOOLEAN has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_POSTBUILD_BOOLEAN has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT)
   #ifdef DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
      #undef DEFAULT_START_SEC_VAR_POSTBUILD_8BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_POSTBUILD_8BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_POSTBUILD_8BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_POSTBUILD_8BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT)
   #ifdef DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
      #undef DEFAULT_START_SEC_VAR_POSTBUILD_16BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_POSTBUILD_16BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_POSTBUILD_16BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_POSTBUILD_16BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT)
   #ifdef DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
      #undef DEFAULT_START_SEC_VAR_POSTBUILD_32BIT
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_POSTBUILD_32BIT has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_POSTBUILD_32BIT)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_POSTBUILD_32BIT has already been started."
   #endif

#elif defined (DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #ifdef DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
      #undef DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED
      #undef SECTION_STARTED
      #undef DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED
   #else
      #error "MemMap.h: DEFAULT_STOP_SEC_VAR_POSTBUILD_UNSPECIFIED has not been previously started."
   #endif
#elif defined (DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED)
   #ifndef SECTION_STARTED
      #define SECTION_STARTED
   #else
      #error "MemMap.h: DEFAULT_START_SEC_VAR_POSTBUILD_UNSPECIFIED has already been started."
   #endif


/* -------------------------------------------------------------------------- */
/* End of default section mapping                                             */
/* -------------------------------------------------------------------------- */
#else
#endif
/*\}*/  /* Close for the doxygen group Common */

/*****************************************************************************/
/* Public types                                                              */
/*****************************************************************************/

/*****************************************************************************/
/* Public constant & variable prototypes                                     */
/*****************************************************************************/

/*****************************************************************************/
/* Public API function prototypes                                            */
/*****************************************************************************/

/**
 * MISRA violation (rule 87): Exception allowed; construct is required
 * per AUTOSAR Memory Mapping.  This header file does not contain the
 * typical construct to prevent multiple inclusion.  This is intentional.
 * It is necessary to satisfy the requirements for MemMap.h usage.
 */

