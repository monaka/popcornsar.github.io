
#include "Rte_swc1.h"

void f1()
{
    SInt8 data = 1;
    

    Rte_Write_senderPort_data1(data);
}

