#include <Rte_Main.h>

void main(void)
{
	(void)Rte_Start();
	
/*	(void)TaskMainOsTask1();
	(void)TaskMainOsTask2();*/
	(void)TaskMainOsTask_T_CyclicSendFunc();
	
	(void)Rte_Stop();
	
	return;
}
