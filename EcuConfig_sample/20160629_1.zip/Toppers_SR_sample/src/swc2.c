
#include "Rte_swc2.h"

void f2()
{
	SInt8 data = 0;

	Rte_Read_swc2_receiverPort_data1(&data);
        
}
